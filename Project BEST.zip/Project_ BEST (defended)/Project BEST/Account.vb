﻿Imports MySql.Data.MySqlClient
Imports System.Reflection.MethodBase

Public Class Account

    Dim reader As MySqlDataReader
    Dim DBConnection As New MySqlConnection(LoginForm.ConnectionString)
    Dim cmd As MySqlCommand

    Dim accID As Integer

    Public Sub ResetManageAccountForm()
        txtAccountName.Clear()
        txtUsername.Clear()
        txtPassword.Clear()
        txtConfirmPass.Clear()
        cboDept.SelectedIndex = -1
    End Sub

    Public Sub LoadAccountTable()
        Try
            dgvAccount.Rows.Clear()

            Dim accountNotEmpty As Boolean = True
            cmd = New MySqlCommand("SELECT COUNT(*) AS RowCount FROM account WHERE acc_type!='default';", DBConnection)
            DBConnection.Open()
            reader = cmd.ExecuteReader
            reader.Read()
            If reader.GetString("RowCount") = 0 Then
                accountNotEmpty = False
            End If
            DBConnection.Close()

            If accountNotEmpty Then
                cmd = New MySqlCommand("SELECT account.acc_id, account.acc_name, account.acc_user, account.acc_pass, department.dept_code FROM account JOIN department ON account.dept_id=department.dept_id WHERE acc_type!='default';", DBConnection)
                DBConnection.Open()
                reader = cmd.ExecuteReader
                While reader.Read
                    dgvAccount.Rows.Add(
                        reader.GetString("acc_id"),
                        reader.GetString("acc_name"),
                        reader.GetString("acc_user"),
                        reader.GetString("acc_pass"),
                        reader.GetString("dept_code")
                        )
                End While
                DBConnection.Close()
            Else
                dgvAccount.Rows.Add("--No Data--", "--No Data--", "--No Data--", "--No Data--", "--No Data--")
            End If

            dgvAccount.ClearSelection()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod.Name)
        Finally
            DBConnection.Dispose()
        End Try
    End Sub

    Public Sub LoadDeptCboData()
        Try
            cboDept.Items.Clear()
            cmd = New MySqlCommand("SELECT dept_code FROM department;", DBConnection)
            DBConnection.Open()
            reader = cmd.ExecuteReader
            While reader.Read
                cboDept.Items.Add(reader.GetString("dept_code"))
            End While
            DBConnection.Close()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod.Name)
        Finally
            DBConnection.Dispose()
        End Try
    End Sub

    Private Sub Account_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadDeptCboData()
        LoadAccountTable()
    End Sub

    Private Sub btnAddEdit_Click(sender As Object, e As EventArgs) Handles btnAddEdit.Click
        txtAccountName.Text = IbaPa.getRidOfFckinWhiteSpaces(txtAccountName.Text)
        txtUsername.Text = IbaPa.getRidOfFckinWhiteSpaces(txtUsername.Text)

        If txtAccountName.TextLength > 0 And
                txtUsername.TextLength > 0 And
                txtPassword.TextLength > 0 And
                txtConfirmPass.TextLength > 0 And
                cboDept.SelectedIndex > -1 Then
            If InputValidation.isAllAlpha(txtAccountName.Text) Then
                If Not IsNumeric(txtUsername) Then
                    If txtPassword.Text = txtConfirmPass.Text Then
                        If btnAddEdit.Text = "Add" Then
                            Try
                                Dim accountNotExist As Boolean = True
                                cmd = New MySqlCommand("SELECT COUNT(*) AS RowCount FROM account WHERE acc_name='" & txtAccountName.Text & "';", DBConnection)
                                DBConnection.Open()
                                reader = cmd.ExecuteReader
                                reader.Read()
                                If reader.GetString("RowCount") > 0 Then
                                    accountNotExist = False
                                End If
                                DBConnection.Close()

                                If accountNotExist Then
                                    Dim usernameNotExist As Boolean = True
                                    cmd = New MySqlCommand("SELECT COUNT(*) AS RowCount FROM account WHERE acc_user='" & txtUsername.Text & "';", DBConnection)
                                    DBConnection.Open()
                                    reader = cmd.ExecuteReader
                                    reader.Read()
                                    If reader.GetString("RowCount") > 0 Then
                                        usernameNotExist = False
                                    End If
                                    DBConnection.Close()

                                    If usernameNotExist Then
                                        Dim deptID As Integer
                                        cmd = New MySqlCommand("SELECT dept_id FROM department WHERE dept_code='" & cboDept.SelectedItem & "';", DBConnection)
                                        DBConnection.Open()
                                        reader = cmd.ExecuteReader
                                        reader.Read()
                                        deptID = reader.GetString("dept_id")
                                        DBConnection.Close()

                                        cmd = New MySqlCommand("INSERT INTO account (acc_name, acc_user, acc_pass, acc_type, dept_id) VALUES (@AccountName, @Username, @Password, @AccountType, @DeptID);", DBConnection)
                                        With cmd.Parameters
                                            .AddWithValue("@AccountName", txtAccountName.Text)
                                            .AddWithValue("@Username", txtUsername.Text)
                                            .AddWithValue("@Password", txtPassword.Text)
                                            .AddWithValue("@AccountType", "Regular")
                                            .AddWithValue("@DeptID", deptID)
                                        End With
                                        DBConnection.Open()
                                        cmd.ExecuteReader()
                                        DBConnection.Close()

                                        LoadAccountTable()

                                        For i As Integer = 0 To dgvAccount.RowCount - 1
                                            If dgvAccount.Rows(i).Cells(1).Value = txtAccountName.Text Then
                                                dgvAccount.Rows(i).Selected = True
                                                dgvAccount.FirstDisplayedScrollingRowIndex = i
                                                Exit For
                                            End If
                                        Next

                                        ResetManageAccountForm()
                                    Else
                                        MsgBox("Username is already taken", MsgBoxStyle.Exclamation)
                                        txtUsername.SelectAll()
                                    End If
                                Else
                                    MsgBox("Account Name is already taken", MsgBoxStyle.Exclamation)
                                    txtAccountName.SelectAll()
                                End If
                            Catch ex As Exception
                                MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod.Name)
                            Finally
                                DBConnection.Dispose()
                            End Try
                        ElseIf btnAddEdit.Text = "Edit" Then
                            Try
                                Dim accountNotExist As Boolean = True
                                cmd = New MySqlCommand("SELECT COUNT(*) AS RowCount FROM account WHERE acc_name='" & txtAccountName.Text & "' AND acc_id!=" & accID & ";", DBConnection)
                                DBConnection.Open()
                                reader = cmd.ExecuteReader
                                reader.Read()
                                If reader.GetString("RowCount") > 0 Then
                                    accountNotExist = False
                                End If
                                DBConnection.Close()

                                If accountNotExist Then
                                    Dim usernameNotExist As Boolean = True
                                    cmd = New MySqlCommand("SELECT COUNT(*) AS RowCount FROM account WHERE acc_user='" & txtUsername.Text & "' AND acc_id!=" & accID & ";", DBConnection)
                                    DBConnection.Open()
                                    reader = cmd.ExecuteReader
                                    reader.Read()
                                    If reader.GetString("RowCount") > 0 Then
                                        usernameNotExist = False
                                    End If
                                    DBConnection.Close()

                                    If usernameNotExist Then
                                        cmd = New MySqlCommand("UPDATE account SET acc_name=@AccountName, acc_user=@Username, acc_pass=@Password WHERE acc_id=" & accID & ";", DBConnection)
                                        With cmd.Parameters
                                            .AddWithValue("@AccountName", txtAccountName.Text)
                                            .AddWithValue("@Username", txtUsername.Text)
                                            .AddWithValue("@Password", txtPassword.Text)
                                        End With
                                        DBConnection.Open()
                                        cmd.ExecuteReader()
                                        DBConnection.Close()

                                        LoadAccountTable()

                                        btnAddEdit.Text = "Add"

                                        For i As Integer = 0 To dgvAccount.RowCount - 1
                                            If dgvAccount.Rows(i).Cells(1).Value = txtAccountName.Text Then
                                                dgvAccount.Rows(i).Selected = True
                                                dgvAccount.FirstDisplayedScrollingRowIndex = i
                                                Exit For
                                            End If
                                        Next

                                        ResetManageAccountForm()
                                    Else
                                        MsgBox("Username is already taken", MsgBoxStyle.Exclamation)
                                    End If
                                Else
                                    MsgBox("Account Name is already taken", MsgBoxStyle.Exclamation)
                                End If
                            Catch ex As Exception
                                MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod.Name)
                            Finally
                                DBConnection.Dispose()
                            End Try
                        End If
                    Else
                        MsgBox("Password does not match", MsgBoxStyle.Exclamation)
                        txtPassword.SelectAll()
                    End If
                Else
                    MsgBox("Username must not start with number", MsgBoxStyle.Exclamation)
                    txtUsername.SelectAll()
                End If
            Else
                MsgBox(My.Resources.strInvalidInput & vbCrLf & My.Resources.strAllAlpha & " in Account Name")
                txtAccountName.SelectAll()
            End If
        Else
            MsgBox(My.Resources.strRequired, MsgBoxStyle.Exclamation, GetCurrentMethod.Name)
            If txtAccountName.TextLength = 0 Then
                txtAccountName.Select()
            ElseIf txtUsername.TextLength = 0 Then
                txtUsername.Select()
            ElseIf txtPassword.TextLength = 0 Then
                txtPassword.Select()
            ElseIf txtConfirmPass.TextLength = 0 Then
                txtConfirmPass.Select()
            ElseIf cboDept.SelectedIndex > -1 Then
                cboDept.Select()
            End If
        End If
    End Sub

    Private Sub dgvAccount_CellFormatting(sender As Object, e As DataGridViewCellFormattingEventArgs) Handles dgvAccount.CellFormatting
        If dgvAccount.Columns(e.ColumnIndex).HeaderText.Equals("PASSWORD") Then
            If (Not e.Value Is Nothing) Then
                e.Value = New String("●", e.Value.ToString.Length)
            End If
        End If
    End Sub

    Private Sub dgvAccount_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvAccount.CellDoubleClick
        btnAddEdit.Text = "Edit"
        accID = dgvAccount.Rows(e.RowIndex).Cells(0).Value

        txtAccountName.Text = dgvAccount.Rows(e.RowIndex).Cells(1).Value
        txtUsername.Text = dgvAccount.Rows(e.RowIndex).Cells(2).Value
        txtPassword.Text = dgvAccount.Rows(e.RowIndex).Cells(3).Value
        txtConfirmPass.Text = dgvAccount.Rows(e.RowIndex).Cells(3).Value
        cboDept.SelectedItem = dgvAccount.Rows(e.RowIndex).Cells(4).Value

        cboDept.Enabled = False
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Try
            If dgvAccount.SelectedRows.Count > 0 Then
                If dgvAccount.CurrentRow.Cells(0).Value <> "--No Data--" Then
                    IbaPa.DeleteRow(dgvAccount, 0, 1, "account", "acc_id")
                    LoadAccountTable()
                    ResetManageAccountForm()
                    btnAddEdit.Text = "Add"
                End If
            Else
                MsgBox("Please select a row")
            End If
            grpAccountsInputs.Focus()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, GetCurrentMethod().Name)
        End Try
    End Sub

    Private Sub Account_Click(sender As Object, e As EventArgs) Handles MyBase.Click, grpAccountsInputs.Click
        btnAddEdit.Text = "Add"

        ResetManageAccountForm()

        cboDept.Enabled = True
    End Sub

    Private Sub Account_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        Me.Dispose()
    End Sub

    Private Sub txtAccountName_GotFocus(sender As Object, e As EventArgs) Handles txtAccountName.GotFocus
        txtAccountName.SelectAll()
    End Sub

    Private Sub txtUsername_GotFocus(sender As Object, e As EventArgs) Handles txtUsername.GotFocus
        txtUsername.SelectAll()
    End Sub

    Private Sub txtPassword_GotFocus(sender As Object, e As EventArgs) Handles txtPassword.GotFocus
        txtPassword.SelectAll()
    End Sub

    Private Sub txtConfirmPass_GotFocus(sender As Object, e As EventArgs) Handles txtConfirmPass.GotFocus
        txtConfirmPass.SelectAll()
    End Sub
End Class