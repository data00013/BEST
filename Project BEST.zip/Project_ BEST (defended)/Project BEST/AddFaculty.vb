﻿Imports MySql.Data.MySqlClient
Imports System.IO
'Imports System.Globalization
'Imports System.Drawing.Imaging
Imports System.Reflection.MethodBase
Imports System.Text

Public Class AddFaculty
    Dim reader As MySqlDataReader
    Dim DBConnection As New MySqlConnection(LoginForm.ConnectionString)
    Dim cmd As MySqlCommand

    Public Sub ResetAddingForm()
        picFaculty.Image = My.Resources.NoImage
        txtLname.Clear()
        txtFname.Clear()
        txtMname.Clear()
        txtName.Clear()
        txtContact.Text = "09"
        txtEmail.Clear()
        chkFulltime.Checked = False
    End Sub

    Private Sub AddingForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        picFaculty.Image = My.Resources.NoImage
        Me.Text = "Add Faculty - " & If(LoginForm.accType = "Default", "Admin Account", LoginForm.dept_code & " Department")

        IbaPa.LoadCbotData(cboDept, "department", "dept_code")

        If LoginForm.accType = "Default" Then
            cboDept.Enabled = True
            reqDept.Visible = True
        Else
            cboDept.SelectedItem = LoginForm.dept_code
            cboDept.Enabled = False
            reqDept.Visible = False
        End If

        ResetAddingForm()
    End Sub

    Public Sub InsertToFaculty(ByRef deptID As Integer)
        Dim contact As String = txtContact.Text

        'Name Concatenation / Fullname
        Dim fullname As String = txtLname.Text & ", " & txtFname.Text & If(txtMname.TextLength > 0, " " & txtMname.Text, "")

        'Nickname
        If txtName.TextLength = 0 Then
            txtName.Text = fullname
        End If

        Dim image As Image = picFaculty.Image
        Dim ms As New MemoryStream

        'Function MakeItSmall para lahat ng picture na iuupload 120x120 pixels (pinakamalaki na yan)
        picFaculty.Image = IbaPa.MakeItSmall(picFaculty.Image)
        picFaculty.Image.Save(ms, Imaging.ImageFormat.Jpeg)

        cmd = New MySqlCommand(
            "INSERT INTO faculty (fac_pic, fac_fullName, fac_altName, fac_lname, fac_fname, fac_mname, fac_type, fac_contact, fac_email,  fac_notifRead, dept_id)
            VALUES (@Image, @FullName, @Nickname, @LastName, @FirstName, @MiddleName, @Type, @Contact,@Email, @Notif, @Department);",
            DBConnection)
        With cmd.Parameters
            .AddWithValue("@Image", ms.GetBuffer)
            .AddWithValue("@FullName", fullname)
            .AddWithValue("@Nickname", txtName.Text)
            .AddWithValue("@LastName", txtLname.Text)
            .AddWithValue("@FirstName", txtFname.Text)
            .AddWithValue("@MiddleName", If(txtMname.TextLength = 0, DBNull.Value, txtMname.Text))
            .AddWithValue("@Type", If(chkFulltime.Checked = True, 1, 0))
            .AddWithValue("@Contact", "+63" & contact.Substring(1, 10))
            .AddWithValue("@Email", If(txtEmail.TextLength = 0, DBNull.Value, txtEmail.Text))
            .AddWithValue("@Notif", 0)
            .AddWithValue("@Department", deptID)
        End With
        Try
            DBConnection.Open()
            cmd.ExecuteReader()
            DBConnection.Close()

            DeptWindow.LoadFacultyTable()
            For i As Integer = 0 To DeptWindow.dgvFaculty.RowCount - 1
                If DeptWindow.dgvFaculty.Rows(i).Cells(4).Value = fullname Then
                    DeptWindow.dgvFaculty.Rows(i).Selected = True
                    DeptWindow.dgvFaculty.FirstDisplayedScrollingRowIndex = i
                    Exit For
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod.Name)
        Finally
            DBConnection.Dispose()
        End Try
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Try
            txtLname.Text = IbaPa.getRidOfFckinWhiteSpaces(txtLname.Text)
            txtFname.Text = IbaPa.getRidOfFckinWhiteSpaces(txtFname.Text)
            txtMname.Text = IbaPa.getRidOfFckinWhiteSpaces(txtMname.Text)
            txtName.Text = IbaPa.getRidOfFckinWhiteSpaces(txtName.Text)
            txtEmail.Text = IbaPa.getRidOfFckinWhiteSpaces(txtEmail.Text)

            '  *** Input Valivation ***
            'Profile Picture, Middle Name, Nickname and E-mail
            'Name must start in capital letter and not contain numbers and special charaters
            'Contact Number must be 11 digits
            If txtLname.TextLength > 0 And txtFname.TextLength > 0 And txtContact.Text.Length = 11 And cboDept.SelectedIndex > -1 Then
                '1st IF checks if required fields are not empty

                If InputValidation.isAllAlpha(txtLname.Text & txtFname.Text & txtMname.Text & txtName.Text) Then
                    '2nd IF checks if the name contains numbers or special characters

                    If InputValidation.ContainsSpecialChars(txtEmail.Text) Or txtEmail.Text.Length = 0 Then
                        '3rd IF checks if email is a valid E-mail

                        'name duplication
                        Dim facNameNotExist As Boolean = False
                        cmd = New MySqlCommand(
                            "SELECT COUNT(*) AS RowCheck FROM faculty 
                            WHERE fac_lname='" & txtLname.Text & "' AND fac_fname='" & txtFname.Text & "'" & If(txtMname.TextLength = 0, "", " AND fac_mname='" & txtMname.Text & "'") & ";", DBConnection)
                        DBConnection.Open()
                        reader = cmd.ExecuteReader
                        reader.Read()
                        If reader.GetString("RowCheck") = 0 Then
                            facNameNotExist = True
                        End If
                        DBConnection.Close()

                        If facNameNotExist Then
                            InsertToFaculty(IbaPa.getTheFckinID("department", "dept_id", "dept_code", cboDept.SelectedItem))
                        Else
                            MsgBox("Failed to Insert" & vbCrLf & "Sorry! " & txtFname.Text & " " & If(txtMname.TextLength > 0, txtMname.Text.Substring(0, 1) & ".", "") & " " & txtLname.Text & " exist in the database" & vbCrLf & "Please try again", MsgBoxStyle.Exclamation)
                        End If
                        ResetAddingForm()
                    Else
                        MsgBox("Invalid E-mail" & vbCrLf & "Try Again", MsgBoxStyle.Exclamation, GetCurrentMethod.Name)
                    End If
                Else
                    MsgBox("Invalid Input" & vbCrLf & "Name must NOT contain numbers or special characters", MsgBoxStyle.Exclamation)
                End If
            Else
                MsgBox("Please fill all fields", MsgBoxStyle.Exclamation)
                If cboDept.SelectedIndex - 1 Then
                    cboDept.Select()
                ElseIf txtLname.TextLength = 0 Then
                    txtLname.SelectAll()
                ElseIf txtFname.TextLength = 0 Then
                    txtFname.SelectAll()
                ElseIf txtMname.TextLength = 0 Then
                    txtMname.SelectAll()
                ElseIf txtContact.Text.Length = 0 Then
                    txtContact.SelectAll()
                End If
            End If

            txtLname.Select()
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            DBConnection.Dispose()
        End Try
    End Sub

    Private Sub picFaculty_Click(sender As Object, e As EventArgs) Handles picFaculty.Click
        Try
            uploadPic.Filter = ("All Images |*.png; *.jpg; *.jpeg; ")
            'uploadPic.Filter = "JPEG|*.jpeg|JPG|*.jpg|PNG|*.png"
            uploadPic.FilterIndex = 4
            uploadPic.FileName = ""
            uploadPic.Title = "Select Profile Picture"
            If uploadPic.ShowDialog() = DialogResult.OK Then
                picFaculty.Image = Image.FromFile(uploadPic.FileName)
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, GetCurrentMethod.Name)
        End Try
    End Sub

    Private Sub txtLname_Click(sender As Object, e As EventArgs) Handles txtLname.GotFocus
        txtLname.SelectAll()
    End Sub

    Private Sub txtFname_Click(sender As Object, e As EventArgs) Handles txtFname.GotFocus
        txtFname.SelectAll()
    End Sub

    Private Sub txtMname_Click(sender As Object, e As EventArgs) Handles txtMname.GotFocus
        txtMname.SelectAll()
    End Sub

    Private Sub txtName_Click(sender As Object, e As EventArgs) Handles txtName.GotFocus
        txtName.SelectAll()
    End Sub

    Private Sub txtContact_Click(sender As Object, e As EventArgs) Handles txtContact.GotFocus
        txtContact.SelectionStart = 3
        txtContact.SelectionLength = txtContact.TextLength
    End Sub

    Private Sub txtEmail_Click(sender As Object, e As EventArgs) Handles txtEmail.GotFocus
        txtEmail.SelectAll()
    End Sub


    'This Lost Focus Events make input data in proper cases
    Private Sub txtLname_LostFocus(sender As Object, e As EventArgs) Handles txtLname.LostFocus
        txtLname.Text = StrConv(txtLname.Text, VbStrConv.ProperCase)
    End Sub

    Private Sub txtFname_LostFocus(sender As Object, e As EventArgs) Handles txtFname.LostFocus
        txtFname.Text = StrConv(txtFname.Text, VbStrConv.ProperCase)
    End Sub

    Private Sub txtMname_LostFocus(sender As Object, e As EventArgs) Handles txtMname.LostFocus
        txtMname.Text = StrConv(txtMname.Text, VbStrConv.ProperCase)
    End Sub

    Private Sub txtName_LostFocus(sender As Object, e As EventArgs) Handles txtName.LostFocus
        txtName.Text = StrConv(txtName.Text, VbStrConv.ProperCase)
    End Sub

    Private Sub AddFaculty_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        Me.Dispose()
    End Sub
End Class