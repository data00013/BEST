﻿Imports MySql.Data.MySqlClient
Imports System.Reflection.MethodBase

Public Class AddSubject

    Dim cmd As MySqlCommand
    Dim reader As MySqlDataReader
    Dim DBconnection As New MySqlConnection(LoginForm.ConnectionString)

    Dim deptID As Integer

    Private Sub AddSubject_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Text = "Add Subject - " & If(LoginForm.accType = "Default", "Admin Account", LoginForm.dept_code & " Department")
        txtSubjDuration.TextAlign = HorizontalAlignment.Center

        txtSubjCode.Clear()
        txtSubjDesc.Clear()
        txtSubjDuration.Value = 90
        rdb1Sem.Select()
        If DeptWindow.chk2ndSem.Checked = True Then
            rdb2Sem.Select()
        End If

        IbaPa.LoadCbotData(cboDept, "department", "dept_code")

        If LoginForm.accType = "Default" Then
            cboDept.Enabled = True
            rdbMinor.Enabled = True
        Else
            cboDept.Enabled = False

            cboDept.SelectedItem = LoginForm.dept_code

            If LoginForm.dept_code = "CEAS" Then
                rdbMinor.Enabled = True
            Else
                rdbMinor.Enabled = False
            End If
        End If
    End Sub

    Public Sub ResetAddingSubject()
        txtSubjCode.Clear()
        txtSubjDesc.Clear()
        txtSubjDuration.Value = txtSubjDuration.Minimum
    End Sub

    Public Sub AddSubject(ByRef yearLevel As Integer, ByRef semester As Integer, ByRef subjectType As Integer, ByRef deptID As Integer)
        Try
            cmd = New MySqlCommand(
                "INSERT INTO subject (subj_code, subj_desc, subj_year, subj_sem, subj_type, subj_duration, dept_id)
                VALUES (@SubjectCode, @Description, @YearLevel, @Semester, @SubjectType, @Duration, @Department);",
                DBconnection)
            With cmd.Parameters
                .AddWithValue("@SubjectCode", txtSubjCode.Text)
                .AddWithValue("@Description", txtSubjDesc.Text)
                .AddWithValue("@YearLevel", yearLevel)
                .AddWithValue("@Semester", semester)
                .AddWithValue("@SubjectType", subjectType)
                .AddWithValue("@Duration", txtSubjDuration.Value)
                .AddWithValue("@Department", deptID)
            End With
            DBconnection.Open()
            cmd.ExecuteReader()
            DBconnection.Close()

            DeptWindow.LoadSubjectTable()

            For i As Integer = 0 To DeptWindow.dgvSubjects.RowCount - 1
                If DeptWindow.dgvSubjects.Rows(i).Cells(2).Value = txtSubjCode.Text Then
                    DeptWindow.dgvSubjects.Rows(i).Selected = True
                    DeptWindow.dgvSubjects.FirstDisplayedScrollingRowIndex = i
                    Exit For
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod.Name)
        Finally
            DBconnection.Dispose()
        End Try
    End Sub

    Private Sub btnAddSubject_Click(sender As Object, e As EventArgs) Handles btnAddSubject.Click
        Try
            txtSubjCode.Text = IbaPa.getRidOfFckinWhiteSpaces(txtSubjCode.Text)
            txtSubjDesc.Text = IbaPa.getRidOfFckinWhiteSpaces(txtSubjDesc.Text)

            Dim lvl As Integer = Nothing
            Dim sem As Integer = Nothing
            Dim type As Integer = Nothing

            'this is for Year Level radio buttons
            If rdb1Yr.Checked Then
                lvl = 1
            ElseIf rdb2Yr.Checked Then
                lvl = 2
            ElseIf rdb3Yr.Checked Then
                lvl = 3
            ElseIf rdb4Yr.Checked Then
                lvl = 4
            ElseIf rdb5Yr.Checked Then
                lvl = 5
            End If

            'this is for Semester radio buttons
            If rdb1Sem.Checked Then
                sem = 1
            ElseIf rdb2Sem.Checked Then
                sem = 2
            End If

            'this is for Subject Type radio buttons
            If rdbMinor.Checked Then
                type = 1 'Gen Ed
            ElseIf rdbMajor.Checked Then
                type = 2 'Prof Ed
            End If

            txtSubjCode.Text = IbaPa.getRidOfFckinWhiteSpaces(txtSubjCode.Text)
            txtSubjDesc.Text = IbaPa.getRidOfFckinWhiteSpaces(txtSubjDesc.Text)

            'bunch of condition for the Input Validation
            'this checks if the user gave the required data
            If Not IsNothing(lvl) And
                Not IsNothing(sem) And
                Not IsNothing(type) And
                txtSubjCode.TextLength > 0 And
                txtSubjDesc.TextLength > 0 And
                txtSubjDuration.Value > 0 And
                cboDept.SelectedIndex > -1 Then

                'this checks if the input dont start in number
                If Not IsNumeric(txtSubjCode.Text) And
                    Not IsNumeric(txtSubjDesc.Text) Then

                    'this checks if the input has special characters
                    If Not InputValidation.ContainsSpecialChars(txtSubjCode.Text) And
                        Not InputValidation.ContainsSpecialChars(txtSubjDesc.Text) Then
                        Dim subjectNotExist As Boolean = False
                        cmd = New MySqlCommand("SELECT COUNT(*) AS RowCheck FROM subject WHERE subj_code='" & txtSubjCode.Text & "' OR subj_desc='" & txtSubjDesc.Text & "';", DBconnection)
                        DBconnection.Open()
                        reader = cmd.ExecuteReader
                        reader.Read()
                        If reader.GetString("RowCheck") = 0 Then
                            subjectNotExist = True
                        End If
                        DBconnection.Close()

                        Try
                            If LoginForm.accType = "Default" Then
                                cmd = New MySqlCommand("SELECT dept_id FROM department WHERE dept_code='" & cboDept.SelectedItem & "';", DBconnection)
                                DBconnection.Open()
                                reader = cmd.ExecuteReader
                                reader.Read()
                                deptID = reader.GetString("dept_id")
                                DBconnection.Close()
                            End If
                        Catch ex As Exception
                            MsgBox(ex.Message)
                        Finally
                            DBconnection.Dispose()
                        End Try

                        If subjectNotExist Then
                            AddSubject(lvl, sem, type, IbaPa.getTheFckinID("department", "dept_id", "dept_code", cboDept.SelectedItem))
                        Else
                            MsgBox("Failed to Insert" & vbCrLf & "Sorry! You entered data that already exist in the database. It is either " & txtSubjCode.Text & " or " & txtSubjDesc.Text & vbCrLf & "Please try again", MsgBoxStyle.Exclamation)
                        End If
                        txtSubjCode.Select()
                    Else
                        MsgBox("Invalid Input" & vbCrLf & "Special characters are not allowed", MsgBoxStyle.Exclamation)
                        ResetAddingSubject()
                    End If
                Else
                    MsgBox("Sorry! You can't use numbers as first character in Subject Code and Description" & vbCrLf & "Please try again", MsgBoxStyle.Exclamation)
                    ResetAddingSubject()
                End If
            Else
                MsgBox("Please fill all fields", MsgBoxStyle.Exclamation)
                ResetAddingSubject()
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod.Name)
        End Try
    End Sub

    Private Sub txtSubjCode_GotFocus(sender As Object, e As EventArgs) Handles txtSubjCode.GotFocus
        txtSubjCode.SelectAll()
    End Sub

    Private Sub txtSubjName_GotFocus(sender As Object, e As EventArgs) Handles txtSubjDesc.GotFocus
        txtSubjDesc.SelectAll()
    End Sub

    Private Sub cboDept_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboDept.SelectedIndexChanged
        If cboDept.SelectedItem = "CEAS" Then
            rdbMinor.Enabled = True
        Else
            rdbMinor.Enabled = False
            rdbMajor.Checked = True
        End If
    End Sub

    Private Sub AddSubject_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        Me.Dispose()
    End Sub
End Class