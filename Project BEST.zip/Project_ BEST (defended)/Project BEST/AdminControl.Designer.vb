﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AdminControl
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(AdminControl))
        Me.btnSchedule = New System.Windows.Forms.Button()
        Me.btnDepartment = New System.Windows.Forms.Button()
        Me.btnRoom = New System.Windows.Forms.Button()
        Me.btnAccount = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnSchedule
        '
        Me.btnSchedule.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnSchedule.BackgroundImage = Global.Project_BEST.My.Resources.Resources.btnSchedule
        Me.btnSchedule.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnSchedule.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnSchedule.Location = New System.Drawing.Point(175, 174)
        Me.btnSchedule.Name = "btnSchedule"
        Me.btnSchedule.Size = New System.Drawing.Size(160, 160)
        Me.btnSchedule.TabIndex = 3
        Me.btnSchedule.UseVisualStyleBackColor = True
        '
        'btnDepartment
        '
        Me.btnDepartment.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnDepartment.BackgroundImage = Global.Project_BEST.My.Resources.Resources.btnDepartment
        Me.btnDepartment.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnDepartment.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnDepartment.Location = New System.Drawing.Point(175, 8)
        Me.btnDepartment.Name = "btnDepartment"
        Me.btnDepartment.Size = New System.Drawing.Size(160, 160)
        Me.btnDepartment.TabIndex = 1
        Me.btnDepartment.UseVisualStyleBackColor = True
        '
        'btnRoom
        '
        Me.btnRoom.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnRoom.BackgroundImage = Global.Project_BEST.My.Resources.Resources.btnRoom
        Me.btnRoom.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnRoom.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnRoom.Location = New System.Drawing.Point(9, 174)
        Me.btnRoom.Name = "btnRoom"
        Me.btnRoom.Size = New System.Drawing.Size(160, 160)
        Me.btnRoom.TabIndex = 2
        Me.btnRoom.UseVisualStyleBackColor = True
        '
        'btnAccount
        '
        Me.btnAccount.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnAccount.BackgroundImage = Global.Project_BEST.My.Resources.Resources.btnAccount
        Me.btnAccount.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnAccount.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnAccount.Location = New System.Drawing.Point(9, 8)
        Me.btnAccount.Name = "btnAccount"
        Me.btnAccount.Size = New System.Drawing.Size(160, 160)
        Me.btnAccount.TabIndex = 0
        Me.btnAccount.UseVisualStyleBackColor = True
        '
        'AdminControl
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(345, 343)
        Me.Controls.Add(Me.btnSchedule)
        Me.Controls.Add(Me.btnDepartment)
        Me.Controls.Add(Me.btnRoom)
        Me.Controls.Add(Me.btnAccount)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "AdminControl"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "AdminControl"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnAccount As Button
    Friend WithEvents btnDepartment As Button
    Friend WithEvents btnRoom As Button
    Friend WithEvents btnSchedule As Button
End Class
