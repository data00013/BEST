﻿Public Class AdminControl
    Private Sub AdminControl_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        btnSchedule.Select()
    End Sub

    Private Sub btnRoom_Click(sender As Object, e As EventArgs) Handles btnRoom.Click
        Room.ShowDialog()
    End Sub

    Private Sub AdminControl_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        If Application.OpenForms.Count = 0 Then
            LoginForm.Show()
        End If
    End Sub

    Private Sub btnDepartment_Click(sender As Object, e As EventArgs) Handles btnDepartment.Click
        Department.ShowDialog()
    End Sub

    Private Sub btnAccount_Click(sender As Object, e As EventArgs) Handles btnAccount.Click
        Account.ShowDialog()
    End Sub

    Private Sub btnSchedule_Click(sender As Object, e As EventArgs) Handles btnSchedule.Click
        DeptWindow.Show()
        Me.Close()
    End Sub
End Class