﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ClassEnroll
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.cboSubjCode = New System.Windows.Forms.ComboBox()
        Me.cboCourse = New System.Windows.Forms.ComboBox()
        Me.cboSection = New System.Windows.Forms.ComboBox()
        Me.btnSaveEdit = New System.Windows.Forms.Button()
        Me.lblSubjCode = New System.Windows.Forms.Label()
        Me.lblCourse = New System.Windows.Forms.Label()
        Me.lblSection = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblSubjDesc = New System.Windows.Forms.Label()
        Me.cboYearLevel = New System.Windows.Forms.ComboBox()
        Me.lblYearLevel = New System.Windows.Forms.Label()
        Me.btnClearInputs = New System.Windows.Forms.Button()
        Me.grpInfo = New System.Windows.Forms.GroupBox()
        Me.cboProf = New System.Windows.Forms.ComboBox()
        Me.lblProf = New System.Windows.Forms.Label()
        Me.btnDeleteClass = New System.Windows.Forms.Button()
        Me.dgvClass = New System.Windows.Forms.DataGridView()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.grpInfo.SuspendLayout()
        CType(Me.dgvClass, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'cboSubjCode
        '
        Me.cboSubjCode.DropDownHeight = 150
        Me.cboSubjCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboSubjCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboSubjCode.FormattingEnabled = True
        Me.cboSubjCode.IntegralHeight = False
        Me.cboSubjCode.Location = New System.Drawing.Point(106, 12)
        Me.cboSubjCode.Name = "cboSubjCode"
        Me.cboSubjCode.Size = New System.Drawing.Size(204, 24)
        Me.cboSubjCode.TabIndex = 5
        '
        'cboCourse
        '
        Me.cboCourse.DropDownHeight = 150
        Me.cboCourse.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboCourse.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboCourse.FormattingEnabled = True
        Me.cboCourse.IntegralHeight = False
        Me.cboCourse.Location = New System.Drawing.Point(128, 36)
        Me.cboCourse.Name = "cboCourse"
        Me.cboCourse.Size = New System.Drawing.Size(131, 24)
        Me.cboCourse.TabIndex = 0
        '
        'cboSection
        '
        Me.cboSection.DropDownHeight = 150
        Me.cboSection.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboSection.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboSection.FormattingEnabled = True
        Me.cboSection.IntegralHeight = False
        Me.cboSection.Items.AddRange(New Object() {"A", "B", "C", "D"})
        Me.cboSection.Location = New System.Drawing.Point(128, 67)
        Me.cboSection.Name = "cboSection"
        Me.cboSection.Size = New System.Drawing.Size(131, 24)
        Me.cboSection.TabIndex = 1
        '
        'btnSaveEdit
        '
        Me.btnSaveEdit.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.btnSaveEdit.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSaveEdit.Location = New System.Drawing.Point(37, 161)
        Me.btnSaveEdit.Name = "btnSaveEdit"
        Me.btnSaveEdit.Size = New System.Drawing.Size(99, 34)
        Me.btnSaveEdit.TabIndex = 4
        Me.btnSaveEdit.Text = "Enroll"
        Me.btnSaveEdit.UseVisualStyleBackColor = True
        '
        'lblSubjCode
        '
        Me.lblSubjCode.AutoSize = True
        Me.lblSubjCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSubjCode.Location = New System.Drawing.Point(13, 15)
        Me.lblSubjCode.Name = "lblSubjCode"
        Me.lblSubjCode.Size = New System.Drawing.Size(89, 16)
        Me.lblSubjCode.TabIndex = 4
        Me.lblSubjCode.Text = "Subject Code"
        '
        'lblCourse
        '
        Me.lblCourse.AutoSize = True
        Me.lblCourse.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCourse.Location = New System.Drawing.Point(35, 39)
        Me.lblCourse.Name = "lblCourse"
        Me.lblCourse.Size = New System.Drawing.Size(54, 16)
        Me.lblCourse.TabIndex = 4
        Me.lblCourse.Text = "Course:"
        '
        'lblSection
        '
        Me.lblSection.AutoSize = True
        Me.lblSection.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSection.Location = New System.Drawing.Point(35, 70)
        Me.lblSection.Name = "lblSection"
        Me.lblSection.Size = New System.Drawing.Size(56, 16)
        Me.lblSection.TabIndex = 4
        Me.lblSection.Text = "Section:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(13, 46)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(82, 16)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Description: "
        '
        'lblSubjDesc
        '
        Me.lblSubjDesc.AutoSize = True
        Me.lblSubjDesc.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSubjDesc.Location = New System.Drawing.Point(90, 46)
        Me.lblSubjDesc.MaximumSize = New System.Drawing.Size(220, 50)
        Me.lblSubjDesc.MinimumSize = New System.Drawing.Size(220, 50)
        Me.lblSubjDesc.Name = "lblSubjDesc"
        Me.lblSubjDesc.Size = New System.Drawing.Size(220, 50)
        Me.lblSubjDesc.TabIndex = 5
        '
        'cboYearLevel
        '
        Me.cboYearLevel.DropDownHeight = 150
        Me.cboYearLevel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboYearLevel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboYearLevel.FormattingEnabled = True
        Me.cboYearLevel.IntegralHeight = False
        Me.cboYearLevel.Items.AddRange(New Object() {"1st Year", "2nd Year", "3rd Year", "4th Year", "5th Year"})
        Me.cboYearLevel.Location = New System.Drawing.Point(128, 97)
        Me.cboYearLevel.Name = "cboYearLevel"
        Me.cboYearLevel.Size = New System.Drawing.Size(131, 24)
        Me.cboYearLevel.TabIndex = 2
        '
        'lblYearLevel
        '
        Me.lblYearLevel.AutoSize = True
        Me.lblYearLevel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblYearLevel.Location = New System.Drawing.Point(35, 100)
        Me.lblYearLevel.Name = "lblYearLevel"
        Me.lblYearLevel.Size = New System.Drawing.Size(76, 16)
        Me.lblYearLevel.TabIndex = 4
        Me.lblYearLevel.Text = "Year Level:"
        '
        'btnClearInputs
        '
        Me.btnClearInputs.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.btnClearInputs.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClearInputs.Location = New System.Drawing.Point(159, 161)
        Me.btnClearInputs.Name = "btnClearInputs"
        Me.btnClearInputs.Size = New System.Drawing.Size(99, 34)
        Me.btnClearInputs.TabIndex = 6
        Me.btnClearInputs.TabStop = False
        Me.btnClearInputs.Text = "Reset"
        Me.btnClearInputs.UseVisualStyleBackColor = True
        '
        'grpInfo
        '
        Me.grpInfo.BackColor = System.Drawing.SystemColors.ControlLight
        Me.grpInfo.Controls.Add(Me.cboCourse)
        Me.grpInfo.Controls.Add(Me.cboSection)
        Me.grpInfo.Controls.Add(Me.cboProf)
        Me.grpInfo.Controls.Add(Me.lblProf)
        Me.grpInfo.Controls.Add(Me.cboYearLevel)
        Me.grpInfo.Controls.Add(Me.lblYearLevel)
        Me.grpInfo.Controls.Add(Me.btnSaveEdit)
        Me.grpInfo.Controls.Add(Me.lblSection)
        Me.grpInfo.Controls.Add(Me.btnClearInputs)
        Me.grpInfo.Controls.Add(Me.lblCourse)
        Me.grpInfo.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpInfo.Location = New System.Drawing.Point(16, 82)
        Me.grpInfo.Name = "grpInfo"
        Me.grpInfo.Size = New System.Drawing.Size(294, 209)
        Me.grpInfo.TabIndex = 6
        Me.grpInfo.TabStop = False
        Me.grpInfo.Text = "Add Class"
        '
        'cboProf
        '
        Me.cboProf.DropDownHeight = 150
        Me.cboProf.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboProf.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboProf.FormattingEnabled = True
        Me.cboProf.IntegralHeight = False
        Me.cboProf.Location = New System.Drawing.Point(128, 127)
        Me.cboProf.Name = "cboProf"
        Me.cboProf.Size = New System.Drawing.Size(131, 24)
        Me.cboProf.TabIndex = 3
        '
        'lblProf
        '
        Me.lblProf.AutoSize = True
        Me.lblProf.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblProf.Location = New System.Drawing.Point(35, 130)
        Me.lblProf.Name = "lblProf"
        Me.lblProf.Size = New System.Drawing.Size(69, 16)
        Me.lblProf.TabIndex = 4
        Me.lblProf.Text = "Professor:"
        '
        'btnDeleteClass
        '
        Me.btnDeleteClass.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnDeleteClass.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDeleteClass.Location = New System.Drawing.Point(687, 276)
        Me.btnDeleteClass.Name = "btnDeleteClass"
        Me.btnDeleteClass.Size = New System.Drawing.Size(101, 37)
        Me.btnDeleteClass.TabIndex = 8
        Me.btnDeleteClass.TabStop = False
        Me.btnDeleteClass.Text = "Delete Class"
        Me.btnDeleteClass.UseVisualStyleBackColor = True
        '
        'dgvClass
        '
        Me.dgvClass.AllowUserToAddRows = False
        Me.dgvClass.AllowUserToDeleteRows = False
        Me.dgvClass.AllowUserToResizeColumns = False
        Me.dgvClass.AllowUserToResizeRows = False
        Me.dgvClass.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgvClass.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvClass.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgvClass.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvClass.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.dgvClass.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvClass.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Column3, Me.Column4, Me.Column2, Me.Column6})
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvClass.DefaultCellStyle = DataGridViewCellStyle3
        Me.dgvClass.Location = New System.Drawing.Point(317, 15)
        Me.dgvClass.Margin = New System.Windows.Forms.Padding(4)
        Me.dgvClass.Name = "dgvClass"
        Me.dgvClass.RowHeadersVisible = False
        Me.dgvClass.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvClass.Size = New System.Drawing.Size(494, 254)
        Me.dgvClass.TabIndex = 7
        Me.dgvClass.TabStop = False
        '
        'Column1
        '
        Me.Column1.HeaderText = "ID"
        Me.Column1.Name = "Column1"
        Me.Column1.Visible = False
        '
        'Column3
        '
        Me.Column3.HeaderText = "COURSE"
        Me.Column3.Name = "Column3"
        Me.Column3.ReadOnly = True
        '
        'Column4
        '
        Me.Column4.HeaderText = "SUBJECT"
        Me.Column4.Name = "Column4"
        Me.Column4.ReadOnly = True
        '
        'Column2
        '
        Me.Column2.HeaderText = "SECTION"
        Me.Column2.Name = "Column2"
        Me.Column2.ReadOnly = True
        '
        'Column6
        '
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.Padding = New System.Windows.Forms.Padding(10, 0, 10, 0)
        Me.Column6.DefaultCellStyle = DataGridViewCellStyle2
        Me.Column6.FillWeight = 200.0!
        Me.Column6.HeaderText = "PROFESSOR"
        Me.Column6.Name = "Column6"
        Me.Column6.ReadOnly = True
        '
        'ClassEnroll
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(824, 325)
        Me.Controls.Add(Me.btnDeleteClass)
        Me.Controls.Add(Me.dgvClass)
        Me.Controls.Add(Me.grpInfo)
        Me.Controls.Add(Me.lblSubjDesc)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblSubjCode)
        Me.Controls.Add(Me.cboSubjCode)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "ClassEnroll"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Class"
        Me.grpInfo.ResumeLayout(False)
        Me.grpInfo.PerformLayout()
        CType(Me.dgvClass, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents cboSubjCode As ComboBox
    Friend WithEvents cboCourse As ComboBox
    Friend WithEvents cboSection As ComboBox
    Friend WithEvents btnSaveEdit As Button
    Friend WithEvents lblSubjCode As Label
    Friend WithEvents lblCourse As Label
    Friend WithEvents lblSection As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents lblSubjDesc As Label
    Friend WithEvents cboYearLevel As ComboBox
    Friend WithEvents lblYearLevel As Label
    Friend WithEvents btnClearInputs As Button
    Friend WithEvents grpInfo As GroupBox
    Friend WithEvents btnDeleteClass As Button
    Friend WithEvents dgvClass As DataGridView
    Friend WithEvents cboProf As ComboBox
    Friend WithEvents lblProf As Label
    Friend WithEvents Column1 As DataGridViewTextBoxColumn
    Friend WithEvents Column3 As DataGridViewTextBoxColumn
    Friend WithEvents Column4 As DataGridViewTextBoxColumn
    Friend WithEvents Column2 As DataGridViewTextBoxColumn
    Friend WithEvents Column6 As DataGridViewTextBoxColumn
End Class
