﻿Imports MySql.Data.MySqlClient
Imports System.Reflection.MethodBase

Public Class ClassEnroll

    Dim reader As MySqlDataReader
    Dim DBconnection As New MySqlConnection(LoginForm.ConnectionString)
    Dim cmd As MySqlCommand

    Dim classID As Integer = Nothing

    Private Sub LoadClassTable()
        dgvClass.Rows.Clear()

        Try
            Dim classNotEmpty As Boolean = True
            cmd = New MySqlCommand(
                "SELECT COUNT(*) AS RowCount
                FROM class
                JOIN subject ON class.subj_id=subject.subj_id
                WHERE subject.subj_code='" & cboSubjCode.SelectedItem & "';", DBconnection)
            DBconnection.Open()
            reader = cmd.ExecuteReader
            reader.Read()
            If reader.GetString("RowCount") = 0 Then
                classNotEmpty = False
            End If
            DBconnection.Close()

            If classNotEmpty Then
                cmd = New MySqlCommand(
                    "SELECT class.class_id, course.crs_code, subject.subj_code, section.sec_name, faculty.fac_altName
                    FROM class
                    JOIN course ON class.crs_id=course.crs_id
                    JOIN subject ON class.subj_id=subject.subj_id
                    JOIN section ON class.sec_id=section.sec_id
                    JOIN faculty ON class.fac_id=faculty.fac_id
                    WHERE subject.subj_code='" & cboSubjCode.SelectedItem & "';",
                    DBconnection)

                DBconnection.Open()
                reader = cmd.ExecuteReader
                While reader.Read
                    dgvClass.Rows.Add(reader.GetString("class_id"), reader.GetString("crs_code"), reader.GetString("subj_code"), reader.GetString("sec_name"), reader.GetString("fac_altName"))
                End While
                DBconnection.Close()
            Else
                dgvClass.Rows.Add("--No Data--", "--No Data--", "--No Data--", "--No Data--", "--No Data--")
            End If
            dgvClass.ClearSelection()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod.Name)
        Finally
            DBconnection.Dispose()
        End Try
    End Sub

    Public Sub ResetAddClassField()
        btnSaveEdit.Text = "Enroll"
        cboCourse.SelectedIndex = -1
        cboSection.SelectedIndex = -1
        cboYearLevel.SelectedIndex = -1
        cboProf.SelectedIndex = -1
    End Sub

    Public Sub LoadCboCourseData()
        Try
            cboCourse.Items.Clear()
            cmd = New MySqlCommand("SELECT crs_code FROM course ORDER BY dept_id, crs_code;", DBconnection)
            DBconnection.Open()
            reader = cmd.ExecuteReader
            While reader.Read
                cboCourse.Items.Add(reader.GetString("crs_code"))
            End While
            DBconnection.Close()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod.Name)
        Finally
            DBconnection.Dispose()
        End Try
    End Sub

    Public Sub LoadCboProfData(ByRef deptID As Integer)
        Try
            cboProf.Items.Clear()
            cmd = New MySqlCommand("SELECT faculty.fac_fullName FROM faculty JOIN department ON faculty.dept_id=department.dept_id WHERE department.dept_id=" & deptID & " ORDER BY faculty.fac_fullName;", DBconnection)
            DBconnection.Open()
            reader = cmd.ExecuteReader
            While reader.Read
                cboProf.Items.Add(reader.GetString("fac_fullName"))
            End While
            DBconnection.Close()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod.Name)
        Finally
            DBconnection.Dispose()
        End Try
    End Sub

    Public Sub LoadCboSubjectData()
        Try
            cmd = New MySqlCommand("SELECT subj_code FROM subject WHERE subj_sem=" & DeptWindow.sem & If(LoginForm.accType = "Default", "", " And dept_id=" & LoginForm.dept_id) & " ORDER BY subject.subj_code;", DBconnection)
            DBconnection.Open()
            reader = cmd.ExecuteReader
            While reader.Read
                cboSubjCode.Items.Add(reader.GetString("subj_code"))
            End While
            DBconnection.Close()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod.Name)
        Finally
            DBconnection.Dispose()
        End Try
    End Sub

    Private Sub ClassEnroll_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            LoadCboSubjectData()
            LoadCboCourseData()
            cboSubjCode.SelectedItem = DeptWindow.subjCode
            LoadCboProfData(IbaPa.getTheFckinID("subject", "dept_id", "subj_code", cboSubjCode.SelectedItem))
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod.Name)
        Finally
            DBconnection.Dispose()
        End Try
    End Sub

    Private Sub frmSimple_Dispose(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        Me.Dispose()
    End Sub

    Private Sub cboSubjCode_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboSubjCode.SelectedIndexChanged
        Try
            If cboSubjCode.SelectedIndex >= 0 Then
                Dim deptID As Integer

                ResetAddClassField()

                cmd = New MySqlCommand("SELECT subj_desc, dept_id FROM subject WHERE subj_code='" & cboSubjCode.SelectedItem & "';", DBconnection)
                DBconnection.Open()
                reader = cmd.ExecuteReader
                reader.Read()
                lblSubjDesc.Text = reader.GetString("subj_desc")
                deptID = reader.GetString("dept_id")
                DBconnection.Close()

                LoadClassTable()
                LoadCboProfData(deptID)
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod.Name)
        End Try
    End Sub

    Private Sub btnSaveEdit_Click(sender As Object, e As EventArgs) Handles btnSaveEdit.Click
        If cboSubjCode.SelectedIndex >= 0 And
            cboCourse.SelectedIndex >= 0 And
            cboSection.SelectedIndex >= 0 And
            cboYearLevel.SelectedIndex >= 0 Then

            Try
                If btnSaveEdit.Text = "Enroll" Then
                    Dim courseID, sectionID, subjectID, facID As Integer
                    Dim checkifSubjectExist As Integer
                    courseID = getCourseID(cboCourse.SelectedItem)
                    sectionID = getSectionID(cboSection.SelectedItem, cboCourse.SelectedItem, cboYearLevel.SelectedIndex + 1)
                    subjectID = getSubjectID(cboSubjCode.SelectedItem)
                    facID = getFacultyID(cboProf.SelectedItem)

                    cmd = New MySqlCommand("SELECT COUNT(*) AS RowCount FROM class WHERE subj_id=" & subjectID & " AND sec_id=" & sectionID & ";", DBconnection)
                    DBconnection.Open()
                    reader = cmd.ExecuteReader
                    reader.Read()
                    checkifSubjectExist = reader.GetString("RowCount")
                    DBconnection.Close()

                    If checkifSubjectExist = 0 Then
                        cmd = New MySqlCommand("INSERT INTO class (crs_id, subj_id, sec_id, fac_id) VALUES (@Course, @Subject, @Section, @Faculty)", DBconnection)
                        With cmd.Parameters
                            .AddWithValue("@Course", courseID)
                            .AddWithValue("@Subject", subjectID)
                            .AddWithValue("@Section", sectionID)
                            .AddWithValue("@Faculty", facID)
                        End With
                        DBconnection.Open()
                        cmd.ExecuteReader()
                        DBconnection.Close()
                        DeptWindow.LoadSubjectTable()
                        LoadClassTable()
                    Else
                        MsgBox("It is already in the class table", MsgBoxStyle.Exclamation)
                    End If
                ElseIf btnSaveEdit.Text = "Edit" Then
                    If Not IsNothing(classID) Then
                        Dim courseID, sectionID, subjectID, facID As Integer
                        Dim checkifSubjectExist As Integer
                        courseID = getCourseID(cboCourse.SelectedItem)
                        sectionID = getSectionID(cboSection.SelectedItem, cboCourse.SelectedItem, cboYearLevel.SelectedIndex + 1)
                        subjectID = getSubjectID(cboSubjCode.SelectedItem)
                        facID = getFacultyID(cboProf.SelectedItem)

                        cmd = New MySqlCommand("SELECT COUNT(*) AS RowCount FROM class WHERE subj_id=" & subjectID & " AND sec_id=" & sectionID & " AND class_id!=" & classID & " ;", DBconnection)
                        DBconnection.Open()
                        reader = cmd.ExecuteReader
                        reader.Read()
                        checkifSubjectExist = reader.GetString("RowCount")
                        DBconnection.Close()

                        If checkifSubjectExist = 0 Then
                            cmd = New MySqlCommand("UPDATE class SET crs_id=@Course, subj_id=@Subject, sec_id=@Section, fac_id=@Faculty WHERE class_id=@ClassID;", DBconnection)
                            With cmd.Parameters
                                .AddWithValue("@Course", courseID)
                                .AddWithValue("@Subject", subjectID)
                                .AddWithValue("@Section", sectionID)
                                .AddWithValue("@Faculty", facID)
                                .AddWithValue("@ClassID", classID)
                            End With
                            DBconnection.Open()
                            cmd.ExecuteReader()
                            DBconnection.Close()
                            DeptWindow.LoadSubjectTable()
                            LoadClassTable()

                            ResetAddClassField()
                        Else
                            MsgBox("It is already in the class table", MsgBoxStyle.Exclamation)
                        End If
                    End If
                End If
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod.Name)
            Finally
                DBconnection.Dispose()
            End Try
        Else
            MsgBox("Please fill all fields", MsgBoxStyle.Exclamation)
        End If
    End Sub

    Private Sub btnDeleteClass_Click(sender As Object, e As EventArgs) Handles btnDeleteClass.Click
        Try
            If dgvClass.SelectedRows.Count > 0 Then
                If dgvClass.CurrentRow.Cells(0).Value <> "--No Data--" Then
                    IbaPa.DeleteRow(dgvClass, 0, 3, "class", "class_id")
                    LoadClassTable()
                    DeptWindow.LoadSubjectTable()
                    ResetAddClassField()
                End If
            Else
                MsgBox("Please select a row")
            End If
            grpInfo.Focus()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, GetCurrentMethod().Name)
        End Try
    End Sub

    Private Function getSubjectID(ByVal subjectCode As String) As Integer
        Dim returnVal As Integer

        Try
            cmd = New MySqlCommand("SELECT subj_id FROM subject WHERE subj_code='" & subjectCode & "';", DBconnection)
            DBconnection.Open()
            reader = cmd.ExecuteReader
            reader.Read()
            returnVal = reader.GetString("subj_id")
            DBconnection.Close()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod.Name)
        Finally
            DBconnection.Dispose()
        End Try

        Return returnVal
    End Function

    Private Function getCourseID(ByVal course As String) As Integer
        Dim id As Integer
        Try
            cmd = New MySqlCommand(
                "SELECT crs_id 
                FROM course 
                WHERE crs_code = '" & course & "';",
                DBconnection)
            DBconnection.Open()
            reader = cmd.ExecuteReader()
            reader.Read()
            id = reader.GetString("crs_id")
            DBconnection.Close()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod.Name)
        Finally
            DBconnection.Dispose()
        End Try
        Return id
    End Function

    Private Function getSectionID(ByVal section As String, ByVal course As String, ByVal YearLevel As String) As Integer
        Dim id As Integer = Nothing
        Dim sectionName, courseID As String
        Dim check As Boolean = False

        Try
            cmd = New MySqlCommand("SELECT * FROM course WHERE crs_code = '" & course & "';", DBconnection)
            DBconnection.Open()
            reader = cmd.ExecuteReader
            reader.Read()
            sectionName = reader.GetString("crs_initial") & YearLevel & section
            courseID = reader.GetString("crs_id")
            DBconnection.Close()

            'this will tell you if that section already exist
            cmd = New MySqlCommand("SELECT COUNT(*) AS 'RowCount' FROM section WHERE sec_name = '" & sectionName & "';", DBconnection)
            DBconnection.Open()
            reader = cmd.ExecuteReader
            reader.Read()
            'Take Note: variable check is False as the default value
            'if section does not exist RowCount result will be zero 
            'therefore the condition is not satisfied and check will stay False
            If reader.GetString("RowCount") > 0 Then
                check = True
            End If
            DBconnection.Close()

            If check = True Then
                'if section exist it will just get the ID
                cmd = New MySqlCommand("SELECT sec_id FROM section WHERE sec_name = '" & sectionName & "';", DBconnection)
                DBconnection.Open()
                reader = cmd.ExecuteReader
                reader.Read()
                id = reader.GetString("sec_id")
                DBconnection.Close()
            Else
                'if section does NOT EXIST 
                'it will insert the section First
                'then get the ID
                cmd = New MySqlCommand("INSERT INTO section (sec_name, crs_id) VALUES ('" & sectionName & "', '" & courseID & "');", DBconnection)
                DBconnection.Open()
                cmd.ExecuteReader()
                id = cmd.LastInsertedId
                DBconnection.Close()
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod.Name)
        Finally
            DBconnection.Dispose()
        End Try
        Return id
    End Function

    Private Function getFacultyID(ByVal facName As String) As Integer
        Dim returnVal As Integer

        Try
            cmd = New MySqlCommand("SELECT fac_id FROM faculty WHERE fac_fullName='" & facName & "';", DBconnection)
            DBconnection.Open()
            reader = cmd.ExecuteReader
            reader.Read()
            returnVal = reader.GetString("fac_id")
            DBconnection.Close()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod.Name)
        Finally
            DBconnection.Dispose()
        End Try

        Return returnVal
    End Function

    Private Sub btnClearInputs_Click(sender As Object, e As EventArgs) Handles btnClearInputs.Click
        ResetAddClassField()
    End Sub

    Private Sub dgvClass_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvClass.CellDoubleClick
        If e.RowIndex > -1 Then
            Dim section As String = dgvClass.CurrentRow.Cells(3).Value
            Dim crsInitial As String = section.Substring(0, section.Length - 2)
            Dim sectionChar As String = section.Substring(section.Length - 1, 1)
            Dim yearlvl As String = ""

            Select Case section.Substring(section.Length - 2, 1)
                Case 1
                    yearlvl = "1st Year"
                Case 2
                    yearlvl = "2nd Year"
                Case 3
                    yearlvl = "3rd Year"
                Case 4
                    yearlvl = "4th Year"
                Case 5
                    yearlvl = "5th Year"
                Case Else
                    yearlvl = "Error!" & vbCrLf & "Year Level: " & section.Substring(section.Length - 2, 1)
            End Select

            cboCourse.SelectedItem = IbaPa.RetriveThis_AsString("course", "crs_code", "crs_initial", crsInitial)
            cboSection.SelectedItem = sectionChar
            cboYearLevel.SelectedItem = yearlvl
            cboProf.SelectedItem = IbaPa.RetriveThis_AsString("faculty", "fac_fullName", "fac_altName", dgvClass.CurrentRow.Cells(4).Value)

            If cboCourse.SelectedIndex > -1 And
                cboSection.SelectedIndex > -1 And
                cboYearLevel.SelectedIndex > -1 And
                cboProf.SelectedIndex > -1 Then
                btnSaveEdit.Text = "Edit"
                classID = dgvClass.CurrentRow.Cells(0).Value
            End If
        End If
    End Sub

    Private Sub ClassEnroll_Click(sender As Object, e As EventArgs) Handles MyBase.Click, grpInfo.Click, lblSubjDesc.Click
        dgvClass.ClearSelection()
        ResetAddClassField()
    End Sub
End Class