﻿Imports MySql.Data.MySqlClient
Imports System.Reflection.MethodBase

Public Class Course

    Dim reader As MySqlDataReader
    Dim DBconnection As New MySqlConnection(LoginForm.ConnectionString)
    Dim cmd As MySqlCommand

    Dim crsID As Integer = Nothing

    Sub ResetInputs()
        'btnAddEdit.Text = "Add"
        txtCrsCode.Clear()
        txtCrsInitial.Clear()
        txtCrsName.Clear()
        If LoginForm.accType = "Default" Then
            cboDept.SelectedIndex = -1
        End If
    End Sub

    Sub LoadCourseTable()
        Try
            dgvCourse.Rows.Clear()

            Dim deptNotEmpty As Boolean
            cmd = New MySqlCommand("SELECT COUNT(*) AS RowCount FROM course" & If(LoginForm.accType = "Default", "", " WHERE dept_id='" & LoginForm.dept_id & "'") & ";", DBconnection)
            DBconnection.Open()
            reader = cmd.ExecuteReader
            reader.Read()
            deptNotEmpty = If(reader.GetString("RowCount") = 0, False, True)
            DBconnection.Close()

            If deptNotEmpty Then
                cmd = New MySqlCommand("SELECT crs_id, crs_code, crs_initial, crs_name, dept_code FROM course JOIN department ON course.dept_id=department.dept_id" & If(LoginForm.accType = "Default", "", " WHERE department.dept_id='" & LoginForm.dept_id & "'") & ";", DBconnection)
                DBconnection.Open()
                reader = cmd.ExecuteReader
                While reader.Read
                    dgvCourse.Rows.Add(
                        reader.GetString("crs_id"),
                        reader.GetString("crs_code"),
                        reader.GetString("crs_name"),
                        reader.GetString("dept_code"),
                        reader.GetString("crs_initial"))
                End While
                DBconnection.Close()
            Else
                dgvCourse.Rows.Add("--No Data--", "--No Data--", "--No Data--", "--No Data--", "--No Data--")
            End If

            dgvCourse.ClearSelection()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod.Name)
        Finally
            DBconnection.Dispose()
        End Try
    End Sub

    Private Sub Course_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        IbaPa.LoadCbotData(cboDept, "department", "dept_code")

        If LoginForm.accType = "Default" Then
            cboDept.Enabled = True
        Else
            cboDept.Enabled = False
            cboDept.SelectedItem = LoginForm.dept_code
        End If


        LoadCourseTable()
    End Sub

    Private Sub btnAddEdit_Click(sender As Object, e As EventArgs) Handles btnAddEdit.Click
        txtCrsCode.Text = IbaPa.getRidOfFckinWhiteSpaces(txtCrsCode.Text)
        txtCrsInitial.Text = IbaPa.getRidOfFckinWhiteSpaces(txtCrsInitial.Text)
        txtCrsName.Text = IbaPa.getRidOfFckinWhiteSpaces(txtCrsName.Text)

        If txtCrsCode.TextLength > 0 And
            txtCrsInitial.TextLength > 0 And
            txtCrsName.TextLength > 0 And
            cboDept.SelectedIndex > -1 Then
            If InputValidation.isAllAlpha(txtCrsCode.Text) And InputValidation.isAllAlpha(txtCrsInitial.Text) And InputValidation.isAllAlpha(txtCrsName.Text) Then
                Try
                    Dim deptID As Integer

                    cmd = New MySqlCommand("SELECT dept_id FROM department WHERE dept_code='" & cboDept.SelectedItem & "';", DBconnection)
                    DBconnection.Open()
                    reader = cmd.ExecuteReader
                    reader.Read()
                    deptID = reader.GetString("dept_id")
                    DBconnection.Close()
                    If btnAddEdit.Text = "Add" Then
                        Dim crsNotExist As Boolean

                        cmd = New MySqlCommand("SELECT COUNT(*) AS RowCount FROM course WHERE crs_code='" & txtCrsCode.Text & "' OR crs_initial='" & txtCrsInitial.Text & "' OR crs_name='" & txtCrsName.Text & "';", DBconnection)
                        DBconnection.Open()
                        reader = cmd.ExecuteReader
                        reader.Read()
                        crsNotExist = If(reader.GetString("RowCount") = 0, True, False)
                        DBconnection.Close()

                        If crsNotExist Then
                            cmd = New MySqlCommand("INSERT INTO course (crs_code, crs_initial, crs_name, dept_id) VALUES (@CourseCode, @CourseInitial, @CourseName, @Department);", DBconnection)
                            With cmd.Parameters
                                .AddWithValue("@CourseCode", txtCrsCode.Text)
                                .AddWithValue("@CourseInitial", txtCrsInitial.Text)
                                .AddWithValue("@CourseName", txtCrsName.Text)
                                .AddWithValue("@Department", deptID)
                            End With
                            DBconnection.Open()
                            cmd.ExecuteReader()
                            DBconnection.Close()

                            LoadCourseTable()

                            txtCrsCode.Clear()
                            txtCrsInitial.Clear()
                            txtCrsName.Clear()

                            For i As Integer = 0 To dgvCourse.RowCount - 1
                                If dgvCourse.Rows(i).Cells(1).Value = txtCrsCode.Text Then
                                    dgvCourse.Rows(i).Selected = True
                                    dgvCourse.FirstDisplayedScrollingRowIndex = i
                                End If
                            Next
                        Else
                            MsgBox(My.Resources.strAlreadyExist, MsgBoxStyle.Exclamation)
                        End If
                    ElseIf btnAddEdit.Text = "Edit" Then
                        Dim crsNotExist As Boolean

                        cmd = New MySqlCommand("SELECT COUNT(*) AS RowCount FROM course WHERE (crs_code='" & txtCrsCode.Text & "' OR crs_initial='" & txtCrsInitial.Text & "' OR crs_name='" & txtCrsName.Text & "') AND crs_id != " & crsID & ";", DBconnection)
                        DBconnection.Open()
                        reader = cmd.ExecuteReader
                        reader.Read()
                        crsNotExist = If(reader.GetString("RowCount") = 0, True, False)
                        DBconnection.Close()

                        If crsNotExist Then
                            cmd = New MySqlCommand("UPDATE course SET crs_code=@CourseCode, crs_initial=@CourseInitial, crs_name=@CourseName, dept_id=@Department WHERE crs_id=" & crsID & ";", DBconnection)
                            With cmd.Parameters
                                .AddWithValue("@CourseCode", txtCrsCode.Text)
                                .AddWithValue("@CourseInitial", txtCrsInitial.Text)
                                .AddWithValue("@CourseName", txtCrsName.Text)
                                .AddWithValue("@Department", deptID)
                            End With
                            DBconnection.Open()
                            cmd.ExecuteReader()
                            DBconnection.Close()

                            LoadCourseTable()
                            btnAddEdit.Text = "Add"

                            For i As Integer = 0 To dgvCourse.RowCount - 1
                                If dgvCourse.Rows(i).Cells(1).Value = txtCrsCode.Text Then
                                    dgvCourse.Rows(i).Selected = True
                                    dgvCourse.FirstDisplayedScrollingRowIndex = i
                                End If
                            Next
                        Else
                            MsgBox(My.Resources.strAlreadyExist, MsgBoxStyle.Exclamation)
                        End If

                        ResetInputs()
                    End If
                Catch ex As Exception
                    MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod.Name)
                Finally
                    DBconnection.Dispose()
                End Try
            Else
                MsgBox(My.Resources.strAllAlpha, MsgBoxStyle.Exclamation)
            End If
        Else
            MsgBox(My.Resources.strRequired, MsgBoxStyle.Exclamation, GetCurrentMethod.Name)
            If cboDept.SelectedIndex > -1 Then
                cboDept.Select()
            ElseIf txtCrsCode.TextLength = 0 Then
                txtCrsCode.SelectAll()
            ElseIf txtCrsInitial.TextLength = 0 Then
                txtCrsInitial.SelectAll()
            ElseIf txtCrsName.TextLength = 0 Then
                txtCrsName.SelectAll()
            End If
        End If
    End Sub

    Private Sub dgvCourse_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvCourse.CellDoubleClick
        If e.RowIndex > -1 Then
            btnAddEdit.Text = "Edit"
            crsID = dgvCourse.CurrentRow.Cells(0).Value
            txtCrsCode.Text = dgvCourse.CurrentRow.Cells(1).Value
            txtCrsInitial.Text = dgvCourse.CurrentRow.Cells(4).Value
            txtCrsName.Text = dgvCourse.CurrentRow.Cells(2).Value
            cboDept.SelectedItem = dgvCourse.CurrentRow.Cells(3).Value
        End If
    End Sub

    Private Sub Course_Click(sender As Object, e As EventArgs) Handles MyBase.Click, grpCrsInputs.Click
        ResetInputs()
        btnAddEdit.Text = "Add"
        dgvCourse.ClearSelection()
    End Sub

    Private Sub Course_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        Me.Dispose()
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Try
            If dgvCourse.SelectedRows.Count > 0 Then
                If dgvCourse.CurrentRow.Cells(0).Value <> "--No Data--" Then
                    IbaPa.DeleteRow(dgvCourse, 0, 1, "course", "crs_id")
                    LoadCourseTable()
                    ResetInputs()
                    btnAddEdit.Text = "Add"
                End If
            Else
                MsgBox("Please select a row")
            End If
            grpCrsInputs.Focus()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, GetCurrentMethod().Name)
        End Try
    End Sub
End Class