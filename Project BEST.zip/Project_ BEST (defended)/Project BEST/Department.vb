﻿Imports MySql.Data.MySqlClient
Imports System.Reflection.MethodBase

Public Class Department

    Dim reader As MySqlDataReader
    Dim DBconnection As New MySqlConnection(LoginForm.ConnectionString)
    Dim cmd As MySqlCommand

    Dim deptID As Integer

    Public Sub ResetManageDepartmentForm()
        txtDeptCode.Clear()
        txtDeptName.Clear()
    End Sub

    Public Sub LoadDepartmentTable()
        Try
            dgvDept.Rows.Clear()

            Dim deptNotEmpty As Boolean = True
            cmd = New MySqlCommand("SELECT COUNT(*) AS RowCount FROM department;", DBconnection)
            DBconnection.Open()
            reader = cmd.ExecuteReader
            reader.Read()
            If reader.GetString("RowCount") = 0 Then
                deptNotEmpty = False
            End If
            DBconnection.Close()

            If deptNotEmpty Then
                cmd = New MySqlCommand("SELECT dept_id, dept_code, dept_name FROM department;", DBconnection)
                DBconnection.Open()
                reader = cmd.ExecuteReader
                While reader.Read
                    dgvDept.Rows.Add(reader.GetString("dept_id"), reader.GetString("dept_code"), reader.GetString("dept_name"))
                End While
                DBconnection.Close()
            Else
                dgvDept.Rows.Add("--No Data--", "--No Data--", "--No Data--")
            End If

            dgvDept.ClearSelection()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod.Name)
        Finally
            DBconnection.Close()
        End Try
    End Sub

    Private Sub Department_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadDepartmentTable()
    End Sub

    Private Sub btnAddEdit_Click(sender As Object, e As EventArgs) Handles btnAddEdit.Click
        txtDeptCode.Text = IbaPa.getRidOfFckinWhiteSpaces(txtDeptCode.Text)
        txtDeptName.Text = IbaPa.getRidOfFckinWhiteSpaces(txtDeptName.Text)

        If btnAddEdit.Text = "Add" Then
            If txtDeptCode.TextLength > 0 And txtDeptName.TextLength > 0 Then
                If Not InputValidation.ContainsSpecialChars(txtDeptCode.Text) And InputValidation.isAlphaWithComma(txtDeptName.Text) Then
                    Try
                        Dim deptNotExist As Boolean = True

                        cmd = New MySqlCommand("SELECT COUNT(*) RowCount FROM department WHERE dept_code='" & txtDeptCode.Text & "' OR dept_name='" & txtDeptName.Text & "';", DBconnection)
                        DBconnection.Open()
                        reader = cmd.ExecuteReader
                        reader.Read()
                        If reader.GetString("RowCount") > 0 Then
                            deptNotExist = False
                        End If
                        DBconnection.Close()

                        If deptNotExist Then
                            Dim deptIDLastInsertKey As Integer
                            cmd = New MySqlCommand("INSERT INTO department (dept_code, dept_name) VALUES ('" & txtDeptCode.Text & "', '" & txtDeptName.Text & "');", DBconnection)
                            DBconnection.Open()
                            cmd.ExecuteReader()
                            deptIDLastInsertKey = cmd.LastInsertedId
                            DBconnection.Close()

                            cmd = New MySqlCommand("UPDATE department SET dept_proctoringPref='" & deptIDLastInsertKey & "' WHERE dept_id=" & deptIDLastInsertKey & ";", DBconnection)
                            DBconnection.Open()
                            cmd.ExecuteReader()
                            DBconnection.Close()

                            LoadDepartmentTable()

                            For i As Integer = 0 To dgvDept.RowCount - 1
                                If dgvDept.Rows(i).Cells(1).Value = txtDeptCode.Text Then
                                    dgvDept.Rows(i).Selected = True
                                    dgvDept.FirstDisplayedScrollingRowIndex = i
                                End If
                            Next
                        Else
                            MsgBox(My.Resources.strAlreadyExist, MsgBoxStyle.Exclamation)
                            txtDeptCode.Select()
                        End If

                        ResetManageDepartmentForm()
                    Catch ex As Exception
                        MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod.Name)
                    Finally
                        DBconnection.Dispose()
                    End Try
                Else
                    MsgBox(My.Resources.strAllAlpha, MsgBoxStyle.Exclamation)
                End If
            Else
                MsgBox(My.Resources.strRequired, MsgBoxStyle.Exclamation)
                If txtDeptCode.TextLength = 0 Then
                    txtDeptCode.Select()
                ElseIf txtDeptName.TextLength = 0 Then
                    txtDeptName.Select()
                End If
            End If
        ElseIf btnAddEdit.Text = "Edit" Then
            If txtDeptCode.TextLength > 0 And txtDeptName.TextLength > 0 Then
                If Not InputValidation.ContainsSpecialChars(txtDeptCode.Text) And InputValidation.isAlphaWithComma(txtDeptName.Text) Then
                    Try
                        Dim deptNotExist As Boolean = True

                        cmd = New MySqlCommand("SELECT COUNT(*) RowCount FROM department WHERE (dept_code='" & txtDeptCode.Text & "' OR dept_name='" & txtDeptName.Text & "') AND dept_id!=" & deptID & ";", DBconnection)
                        DBconnection.Open()
                        reader = cmd.ExecuteReader
                        reader.Read()
                        If reader.GetString("RowCount") > 0 Then
                            deptNotExist = False
                        End If
                        DBconnection.Close()

                        If deptNotExist Then
                            cmd = New MySqlCommand("UPDATE department SET dept_code='" & txtDeptCode.Text & "', dept_name='" & txtDeptName.Text & "' WHERE dept_id=" & deptID & ";", DBconnection)
                            DBconnection.Open()
                            cmd.ExecuteReader()
                            DBconnection.Close()

                            LoadDepartmentTable()

                            For i As Integer = 0 To dgvDept.RowCount - 1
                                If dgvDept.Rows(i).Cells(0).Value = deptID Then
                                    dgvDept.Rows(i).Selected = True
                                    dgvDept.FirstDisplayedScrollingRowIndex = i
                                    Exit For
                                End If
                            Next
                            btnAddEdit.Text = "Add"
                        Else
                            MsgBox(My.Resources.strAlreadyExist, MsgBoxStyle.Exclamation)
                            txtDeptCode.Select()
                        End If

                        ResetManageDepartmentForm()
                    Catch ex As Exception
                        MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod.Name)
                    Finally
                        DBconnection.Dispose()
                    End Try
                Else
                    MsgBox(My.Resources.strAllAlpha, MsgBoxStyle.Exclamation)
                    If InputValidation.ContainsSpecialChars(txtDeptCode.Text) Then
                        txtDeptCode.SelectAll()
                    ElseIf Not InputValidation.isAllAlpha(txtDeptName.Text) Then
                        txtDeptName.SelectAll()
                    End If
                End If
            Else
                MsgBox(My.Resources.strRequired, MsgBoxStyle.Exclamation)
                If txtDeptCode.TextLength = 0 Then
                    txtDeptCode.Select()
                ElseIf txtDeptName.TextLength = 0 Then
                    txtDeptName.Select()
                End If
            End If
        End If
    End Sub

    Private Sub txtDeptName_LostFocus(sender As Object, e As EventArgs) Handles txtDeptName.LostFocus
        txtDeptName.Text = StrConv(txtDeptName.Text, VbStrConv.ProperCase)
    End Sub

    Private Sub txtDeptCode_GotFocus(sender As Object, e As EventArgs) Handles txtDeptCode.GotFocus
        txtDeptCode.SelectAll()
    End Sub

    Private Sub txtDeptName_GotFocus(sender As Object, e As EventArgs) Handles txtDeptName.GotFocus
        txtDeptName.SelectAll()
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Try
            If dgvDept.SelectedRows.Count > 0 Then
                If dgvDept.CurrentRow.Cells(0).Value <> "--No Data--" Then
                    IbaPa.DeleteRow(dgvDept, 0, 1, "department", "dept_id")
                    LoadDepartmentTable()
                    ResetManageDepartmentForm()
                    btnAddEdit.Text = "Add"
                End If
            Else
                MsgBox("Please select a row")
            End If
            grpDeptInputs.Focus()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, GetCurrentMethod().Name)
        End Try
    End Sub

    Private Sub Department_Click(sender As Object, e As EventArgs) Handles MyBase.Click, grpDeptInputs.Click
        dgvDept.ClearSelection()
        btnAddEdit.Text = "Add"
        txtDeptCode.Clear()
        txtDeptName.Clear()
    End Sub

    Private Sub dgvDept_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvDept.CellDoubleClick
        deptID = dgvDept.Rows(e.RowIndex).Cells(0).Value

        btnAddEdit.Text = "Edit"
        txtDeptCode.Text = dgvDept.Rows(e.RowIndex).Cells(1).Value
        txtDeptName.Text = dgvDept.Rows(e.RowIndex).Cells(2).Value
    End Sub

    Private Sub Department_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        Me.Dispose()
    End Sub
End Class