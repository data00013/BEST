﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class DeptWindow
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle14 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle15 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle16 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle17 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle18 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle19 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(DeptWindow))
        Me.TabControl = New System.Windows.Forms.TabControl()
        Me.btnProctoringNotif = New System.Windows.Forms.TabPage()
        Me.btnAllPartTime = New System.Windows.Forms.Button()
        Me.btnAllFulltime = New System.Windows.Forms.Button()
        Me.btnRefreshFacultyTable = New System.Windows.Forms.Button()
        Me.chkCheckAllFaculty = New System.Windows.Forms.CheckBox()
        Me.btnDelFaculty = New System.Windows.Forms.Button()
        Me.btnEditFaculty = New System.Windows.Forms.Button()
        Me.btnAddFaculty = New System.Windows.Forms.Button()
        Me.grpInfo = New System.Windows.Forms.GroupBox()
        Me.picFaculty = New System.Windows.Forms.PictureBox()
        Me.lblFacType = New System.Windows.Forms.Label()
        Me.lblName = New System.Windows.Forms.Label()
        Me.lblEmail = New System.Windows.Forms.Label()
        Me.lblDept = New System.Windows.Forms.Label()
        Me.lblContact = New System.Windows.Forms.Label()
        Me.dgvFaculty = New System.Windows.Forms.DataGridView()
        Me.tabSubject = New System.Windows.Forms.TabPage()
        Me.btnProfEd = New System.Windows.Forms.Button()
        Me.btnGenEd = New System.Windows.Forms.Button()
        Me.btnCourse = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtSearch = New System.Windows.Forms.TextBox()
        Me.chkCheckAllSubject = New System.Windows.Forms.CheckBox()
        Me.btnDelSubj = New System.Windows.Forms.Button()
        Me.btnEditSubj = New System.Windows.Forms.Button()
        Me.btnClass = New System.Windows.Forms.Button()
        Me.btnAddSubj = New System.Windows.Forms.Button()
        Me.chk2ndSem = New System.Windows.Forms.CheckBox()
        Me.chk1stSem = New System.Windows.Forms.CheckBox()
        Me.dgvSubjects = New System.Windows.Forms.DataGridView()
        Me.tabSched = New System.Windows.Forms.TabPage()
        Me.panelSched = New System.Windows.Forms.Panel()
        Me.btnGenerateSchedule = New System.Windows.Forms.Button()
        Me.dgvGeneratedSched = New System.Windows.Forms.DataGridView()
        Me.Column7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnChangeProctorPref = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnRooms = New System.Windows.Forms.Button()
        Me.btnDeleteSched = New System.Windows.Forms.Button()
        Me.btnRefresh = New System.Windows.Forms.Button()
        Me.btnImageSched = New System.Windows.Forms.Button()
        Me.btnPdfSched = New System.Windows.Forms.Button()
        Me.Faculty_chkbox = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.Faculty_facID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Faculty_facName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Faculty_dept = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column11 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewCheckBoxColumn1 = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.ID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column10 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column12 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TabControl.SuspendLayout()
        Me.btnProctoringNotif.SuspendLayout()
        Me.grpInfo.SuspendLayout()
        CType(Me.picFaculty, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgvFaculty, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tabSubject.SuspendLayout()
        CType(Me.dgvSubjects, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tabSched.SuspendLayout()
        Me.panelSched.SuspendLayout()
        CType(Me.dgvGeneratedSched, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl
        '
        Me.TabControl.Appearance = System.Windows.Forms.TabAppearance.FlatButtons
        Me.TabControl.Controls.Add(Me.btnProctoringNotif)
        Me.TabControl.Controls.Add(Me.tabSubject)
        Me.TabControl.Controls.Add(Me.tabSched)
        Me.TabControl.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.TabControl.ItemSize = New System.Drawing.Size(175, 50)
        Me.TabControl.Location = New System.Drawing.Point(0, 0)
        Me.TabControl.Multiline = True
        Me.TabControl.Name = "TabControl"
        Me.TabControl.Padding = New System.Drawing.Point(35, 3)
        Me.TabControl.SelectedIndex = 0
        Me.TabControl.Size = New System.Drawing.Size(1081, 469)
        Me.TabControl.SizeMode = System.Windows.Forms.TabSizeMode.Fixed
        Me.TabControl.TabIndex = 0
        Me.TabControl.TabStop = False
        '
        'btnProctoringNotif
        '
        Me.btnProctoringNotif.Controls.Add(Me.btnAllPartTime)
        Me.btnProctoringNotif.Controls.Add(Me.btnAllFulltime)
        Me.btnProctoringNotif.Controls.Add(Me.btnRefreshFacultyTable)
        Me.btnProctoringNotif.Controls.Add(Me.chkCheckAllFaculty)
        Me.btnProctoringNotif.Controls.Add(Me.btnDelFaculty)
        Me.btnProctoringNotif.Controls.Add(Me.btnEditFaculty)
        Me.btnProctoringNotif.Controls.Add(Me.btnAddFaculty)
        Me.btnProctoringNotif.Controls.Add(Me.grpInfo)
        Me.btnProctoringNotif.Controls.Add(Me.dgvFaculty)
        Me.btnProctoringNotif.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnProctoringNotif.Location = New System.Drawing.Point(4, 54)
        Me.btnProctoringNotif.Name = "btnProctoringNotif"
        Me.btnProctoringNotif.Padding = New System.Windows.Forms.Padding(3)
        Me.btnProctoringNotif.Size = New System.Drawing.Size(1073, 411)
        Me.btnProctoringNotif.TabIndex = 0
        Me.btnProctoringNotif.Text = "Faculty"
        Me.btnProctoringNotif.UseVisualStyleBackColor = True
        '
        'btnAllPartTime
        '
        Me.btnAllPartTime.Location = New System.Drawing.Point(590, 16)
        Me.btnAllPartTime.Name = "btnAllPartTime"
        Me.btnAllPartTime.Size = New System.Drawing.Size(100, 25)
        Me.btnAllPartTime.TabIndex = 8
        Me.btnAllPartTime.TabStop = False
        Me.btnAllPartTime.Text = "All Pa&rt-time"
        Me.btnAllPartTime.UseVisualStyleBackColor = True
        '
        'btnAllFulltime
        '
        Me.btnAllFulltime.Location = New System.Drawing.Point(480, 16)
        Me.btnAllFulltime.Name = "btnAllFulltime"
        Me.btnAllFulltime.Size = New System.Drawing.Size(100, 25)
        Me.btnAllFulltime.TabIndex = 7
        Me.btnAllFulltime.TabStop = False
        Me.btnAllFulltime.Text = "All Fu&ll-time"
        Me.btnAllFulltime.UseVisualStyleBackColor = True
        '
        'btnRefreshFacultyTable
        '
        Me.btnRefreshFacultyTable.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnRefreshFacultyTable.Location = New System.Drawing.Point(951, 48)
        Me.btnRefreshFacultyTable.Name = "btnRefreshFacultyTable"
        Me.btnRefreshFacultyTable.Size = New System.Drawing.Size(100, 40)
        Me.btnRefreshFacultyTable.TabIndex = 6
        Me.btnRefreshFacultyTable.TabStop = False
        Me.btnRefreshFacultyTable.Text = "Re&fresh"
        Me.btnRefreshFacultyTable.UseVisualStyleBackColor = True
        '
        'chkCheckAllFaculty
        '
        Me.chkCheckAllFaculty.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.chkCheckAllFaculty.AutoSize = True
        Me.chkCheckAllFaculty.Location = New System.Drawing.Point(392, 19)
        Me.chkCheckAllFaculty.MaximumSize = New System.Drawing.Size(100, 0)
        Me.chkCheckAllFaculty.MinimumSize = New System.Drawing.Size(100, 0)
        Me.chkCheckAllFaculty.Name = "chkCheckAllFaculty"
        Me.chkCheckAllFaculty.Size = New System.Drawing.Size(100, 20)
        Me.chkCheckAllFaculty.TabIndex = 5
        Me.chkCheckAllFaculty.TabStop = False
        Me.chkCheckAllFaculty.Text = "C&heck All"
        Me.chkCheckAllFaculty.ThreeState = True
        Me.chkCheckAllFaculty.UseVisualStyleBackColor = True
        '
        'btnDelFaculty
        '
        Me.btnDelFaculty.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnDelFaculty.Location = New System.Drawing.Point(951, 200)
        Me.btnDelFaculty.Name = "btnDelFaculty"
        Me.btnDelFaculty.Size = New System.Drawing.Size(100, 40)
        Me.btnDelFaculty.TabIndex = 4
        Me.btnDelFaculty.TabStop = False
        Me.btnDelFaculty.Text = "&Delete"
        Me.btnDelFaculty.UseVisualStyleBackColor = True
        '
        'btnEditFaculty
        '
        Me.btnEditFaculty.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnEditFaculty.Location = New System.Drawing.Point(951, 154)
        Me.btnEditFaculty.Name = "btnEditFaculty"
        Me.btnEditFaculty.Size = New System.Drawing.Size(100, 40)
        Me.btnEditFaculty.TabIndex = 3
        Me.btnEditFaculty.TabStop = False
        Me.btnEditFaculty.Text = "&Edit"
        Me.btnEditFaculty.UseVisualStyleBackColor = True
        '
        'btnAddFaculty
        '
        Me.btnAddFaculty.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnAddFaculty.Location = New System.Drawing.Point(951, 108)
        Me.btnAddFaculty.Name = "btnAddFaculty"
        Me.btnAddFaculty.Size = New System.Drawing.Size(100, 40)
        Me.btnAddFaculty.TabIndex = 2
        Me.btnAddFaculty.TabStop = False
        Me.btnAddFaculty.Text = "&Add"
        Me.btnAddFaculty.UseVisualStyleBackColor = True
        '
        'grpInfo
        '
        Me.grpInfo.BackColor = System.Drawing.SystemColors.ControlLight
        Me.grpInfo.Controls.Add(Me.picFaculty)
        Me.grpInfo.Controls.Add(Me.lblFacType)
        Me.grpInfo.Controls.Add(Me.lblName)
        Me.grpInfo.Controls.Add(Me.lblEmail)
        Me.grpInfo.Controls.Add(Me.lblDept)
        Me.grpInfo.Controls.Add(Me.lblContact)
        Me.grpInfo.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpInfo.Location = New System.Drawing.Point(59, 22)
        Me.grpInfo.Name = "grpInfo"
        Me.grpInfo.Size = New System.Drawing.Size(257, 325)
        Me.grpInfo.TabIndex = 1
        Me.grpInfo.TabStop = False
        Me.grpInfo.Text = "Information"
        '
        'picFaculty
        '
        Me.picFaculty.Location = New System.Drawing.Point(68, 23)
        Me.picFaculty.Name = "picFaculty"
        Me.picFaculty.Size = New System.Drawing.Size(120, 120)
        Me.picFaculty.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picFaculty.TabIndex = 13
        Me.picFaculty.TabStop = False
        '
        'lblFacType
        '
        Me.lblFacType.AutoSize = True
        Me.lblFacType.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFacType.Location = New System.Drawing.Point(16, 280)
        Me.lblFacType.MaximumSize = New System.Drawing.Size(225, 0)
        Me.lblFacType.MinimumSize = New System.Drawing.Size(225, 0)
        Me.lblFacType.Name = "lblFacType"
        Me.lblFacType.Size = New System.Drawing.Size(225, 16)
        Me.lblFacType.TabIndex = 12
        Me.lblFacType.Text = "Type:"
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblName.Location = New System.Drawing.Point(16, 172)
        Me.lblName.MaximumSize = New System.Drawing.Size(225, 0)
        Me.lblName.MinimumSize = New System.Drawing.Size(225, 0)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(225, 16)
        Me.lblName.TabIndex = 8
        Me.lblName.Text = "Name: "
        '
        'lblEmail
        '
        Me.lblEmail.AutoSize = True
        Me.lblEmail.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEmail.Location = New System.Drawing.Point(16, 253)
        Me.lblEmail.MaximumSize = New System.Drawing.Size(225, 0)
        Me.lblEmail.MinimumSize = New System.Drawing.Size(225, 0)
        Me.lblEmail.Name = "lblEmail"
        Me.lblEmail.Size = New System.Drawing.Size(225, 16)
        Me.lblEmail.TabIndex = 11
        Me.lblEmail.Text = "E-mail Ad.:"
        '
        'lblDept
        '
        Me.lblDept.AutoSize = True
        Me.lblDept.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDept.Location = New System.Drawing.Point(16, 199)
        Me.lblDept.MaximumSize = New System.Drawing.Size(225, 0)
        Me.lblDept.MinimumSize = New System.Drawing.Size(225, 0)
        Me.lblDept.Name = "lblDept"
        Me.lblDept.Size = New System.Drawing.Size(225, 16)
        Me.lblDept.TabIndex = 10
        Me.lblDept.Text = "Department:"
        '
        'lblContact
        '
        Me.lblContact.AutoSize = True
        Me.lblContact.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblContact.Location = New System.Drawing.Point(16, 226)
        Me.lblContact.MaximumSize = New System.Drawing.Size(225, 0)
        Me.lblContact.MinimumSize = New System.Drawing.Size(225, 0)
        Me.lblContact.Name = "lblContact"
        Me.lblContact.Size = New System.Drawing.Size(225, 16)
        Me.lblContact.TabIndex = 10
        Me.lblContact.Text = "Contact No.:"
        '
        'dgvFaculty
        '
        Me.dgvFaculty.AllowUserToAddRows = False
        Me.dgvFaculty.AllowUserToDeleteRows = False
        Me.dgvFaculty.AllowUserToResizeRows = False
        Me.dgvFaculty.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgvFaculty.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvFaculty.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgvFaculty.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.dgvFaculty.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvFaculty.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.dgvFaculty.ColumnHeadersHeight = 40
        Me.dgvFaculty.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.dgvFaculty.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Faculty_chkbox, Me.Faculty_facID, Me.Faculty_facName, Me.Faculty_dept, Me.Column5, Me.Column9, Me.Column8, Me.Column4, Me.Column11})
        Me.dgvFaculty.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter
        Me.dgvFaculty.Location = New System.Drawing.Point(373, 45)
        Me.dgvFaculty.Name = "dgvFaculty"
        Me.dgvFaculty.RowHeadersVisible = False
        Me.dgvFaculty.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        Me.dgvFaculty.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvFaculty.ShowCellToolTips = False
        Me.dgvFaculty.ShowEditingIcon = False
        Me.dgvFaculty.Size = New System.Drawing.Size(552, 360)
        Me.dgvFaculty.StandardTab = True
        Me.dgvFaculty.TabIndex = 0
        Me.dgvFaculty.TabStop = False
        '
        'tabSubject
        '
        Me.tabSubject.Controls.Add(Me.btnProfEd)
        Me.tabSubject.Controls.Add(Me.btnGenEd)
        Me.tabSubject.Controls.Add(Me.btnCourse)
        Me.tabSubject.Controls.Add(Me.Label3)
        Me.tabSubject.Controls.Add(Me.Label1)
        Me.tabSubject.Controls.Add(Me.txtSearch)
        Me.tabSubject.Controls.Add(Me.chkCheckAllSubject)
        Me.tabSubject.Controls.Add(Me.btnDelSubj)
        Me.tabSubject.Controls.Add(Me.btnEditSubj)
        Me.tabSubject.Controls.Add(Me.btnClass)
        Me.tabSubject.Controls.Add(Me.btnAddSubj)
        Me.tabSubject.Controls.Add(Me.chk2ndSem)
        Me.tabSubject.Controls.Add(Me.chk1stSem)
        Me.tabSubject.Controls.Add(Me.dgvSubjects)
        Me.tabSubject.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tabSubject.Location = New System.Drawing.Point(4, 54)
        Me.tabSubject.Name = "tabSubject"
        Me.tabSubject.Padding = New System.Windows.Forms.Padding(3)
        Me.tabSubject.Size = New System.Drawing.Size(1073, 411)
        Me.tabSubject.TabIndex = 1
        Me.tabSubject.Text = "Subject"
        Me.tabSubject.UseVisualStyleBackColor = True
        '
        'btnProfEd
        '
        Me.btnProfEd.Location = New System.Drawing.Point(227, 37)
        Me.btnProfEd.Name = "btnProfEd"
        Me.btnProfEd.Size = New System.Drawing.Size(100, 25)
        Me.btnProfEd.TabIndex = 13
        Me.btnProfEd.TabStop = False
        Me.btnProfEd.Text = "Pr&of Ed"
        Me.btnProfEd.UseVisualStyleBackColor = True
        '
        'btnGenEd
        '
        Me.btnGenEd.Location = New System.Drawing.Point(227, 6)
        Me.btnGenEd.Name = "btnGenEd"
        Me.btnGenEd.Size = New System.Drawing.Size(100, 25)
        Me.btnGenEd.TabIndex = 12
        Me.btnGenEd.TabStop = False
        Me.btnGenEd.Text = "&Gen Ed"
        Me.btnGenEd.UseVisualStyleBackColor = True
        '
        'btnCourse
        '
        Me.btnCourse.Location = New System.Drawing.Point(534, 15)
        Me.btnCourse.Name = "btnCourse"
        Me.btnCourse.Size = New System.Drawing.Size(100, 40)
        Me.btnCourse.TabIndex = 11
        Me.btnCourse.Text = "Co&urse"
        Me.btnCourse.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(118, 7)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(37, 13)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "Show:"
        '
        'Label1
        '
        Me.Label1.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(391, 13)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(44, 13)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "Search:"
        '
        'txtSearch
        '
        Me.txtSearch.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtSearch.Location = New System.Drawing.Point(380, 29)
        Me.txtSearch.Name = "txtSearch"
        Me.txtSearch.Size = New System.Drawing.Size(128, 22)
        Me.txtSearch.TabIndex = 7
        Me.txtSearch.TabStop = False
        '
        'chkCheckAllSubject
        '
        Me.chkCheckAllSubject.AutoSize = True
        Me.chkCheckAllSubject.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkCheckAllSubject.Location = New System.Drawing.Point(15, 24)
        Me.chkCheckAllSubject.Name = "chkCheckAllSubject"
        Me.chkCheckAllSubject.Size = New System.Drawing.Size(71, 17)
        Me.chkCheckAllSubject.TabIndex = 6
        Me.chkCheckAllSubject.TabStop = False
        Me.chkCheckAllSubject.Text = "C&heck All"
        Me.chkCheckAllSubject.UseVisualStyleBackColor = True
        '
        'btnDelSubj
        '
        Me.btnDelSubj.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnDelSubj.Location = New System.Drawing.Point(958, 15)
        Me.btnDelSubj.Name = "btnDelSubj"
        Me.btnDelSubj.Size = New System.Drawing.Size(100, 40)
        Me.btnDelSubj.TabIndex = 5
        Me.btnDelSubj.TabStop = False
        Me.btnDelSubj.Text = "&Delete"
        Me.btnDelSubj.UseVisualStyleBackColor = True
        '
        'btnEditSubj
        '
        Me.btnEditSubj.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnEditSubj.Location = New System.Drawing.Point(852, 15)
        Me.btnEditSubj.Name = "btnEditSubj"
        Me.btnEditSubj.Size = New System.Drawing.Size(100, 40)
        Me.btnEditSubj.TabIndex = 4
        Me.btnEditSubj.TabStop = False
        Me.btnEditSubj.Text = "&Edit"
        Me.btnEditSubj.UseVisualStyleBackColor = True
        '
        'btnClass
        '
        Me.btnClass.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnClass.Location = New System.Drawing.Point(640, 15)
        Me.btnClass.Name = "btnClass"
        Me.btnClass.Size = New System.Drawing.Size(100, 40)
        Me.btnClass.TabIndex = 3
        Me.btnClass.TabStop = False
        Me.btnClass.Text = "&Class"
        Me.btnClass.UseVisualStyleBackColor = True
        '
        'btnAddSubj
        '
        Me.btnAddSubj.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnAddSubj.Location = New System.Drawing.Point(746, 15)
        Me.btnAddSubj.Name = "btnAddSubj"
        Me.btnAddSubj.Size = New System.Drawing.Size(100, 40)
        Me.btnAddSubj.TabIndex = 3
        Me.btnAddSubj.TabStop = False
        Me.btnAddSubj.Text = "&Add"
        Me.btnAddSubj.UseVisualStyleBackColor = True
        '
        'chk2ndSem
        '
        Me.chk2ndSem.AutoSize = True
        Me.chk2ndSem.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk2ndSem.Location = New System.Drawing.Point(103, 44)
        Me.chk2ndSem.Name = "chk2ndSem"
        Me.chk2ndSem.Size = New System.Drawing.Size(91, 17)
        Me.chk2ndSem.TabIndex = 2
        Me.chk2ndSem.TabStop = False
        Me.chk2ndSem.Text = "&2nd Semester"
        Me.chk2ndSem.UseVisualStyleBackColor = True
        '
        'chk1stSem
        '
        Me.chk1stSem.AutoSize = True
        Me.chk1stSem.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chk1stSem.Location = New System.Drawing.Point(103, 24)
        Me.chk1stSem.Name = "chk1stSem"
        Me.chk1stSem.Size = New System.Drawing.Size(87, 17)
        Me.chk1stSem.TabIndex = 2
        Me.chk1stSem.TabStop = False
        Me.chk1stSem.Text = "&1st Semester"
        Me.chk1stSem.UseVisualStyleBackColor = True
        '
        'dgvSubjects
        '
        Me.dgvSubjects.AllowUserToAddRows = False
        Me.dgvSubjects.AllowUserToDeleteRows = False
        Me.dgvSubjects.AllowUserToResizeRows = False
        Me.dgvSubjects.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgvSubjects.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvSubjects.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgvSubjects.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.dgvSubjects.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable
        Me.dgvSubjects.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvSubjects.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle6
        Me.dgvSubjects.ColumnHeadersHeight = 40
        Me.dgvSubjects.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.dgvSubjects.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewCheckBoxColumn1, Me.ID, Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.Column3, Me.Column1, Me.Column2, Me.Column10, Me.Column12})
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvSubjects.DefaultCellStyle = DataGridViewCellStyle10
        Me.dgvSubjects.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter
        Me.dgvSubjects.Location = New System.Drawing.Point(6, 68)
        Me.dgvSubjects.Name = "dgvSubjects"
        Me.dgvSubjects.RowHeadersVisible = False
        Me.dgvSubjects.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        Me.dgvSubjects.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvSubjects.ShowCellToolTips = False
        Me.dgvSubjects.ShowEditingIcon = False
        Me.dgvSubjects.Size = New System.Drawing.Size(1061, 337)
        Me.dgvSubjects.StandardTab = True
        Me.dgvSubjects.TabIndex = 1
        Me.dgvSubjects.TabStop = False
        '
        'tabSched
        '
        Me.tabSched.BackColor = System.Drawing.Color.White
        Me.tabSched.Controls.Add(Me.panelSched)
        Me.tabSched.Controls.Add(Me.Panel1)
        Me.tabSched.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tabSched.Location = New System.Drawing.Point(4, 54)
        Me.tabSched.Name = "tabSched"
        Me.tabSched.Padding = New System.Windows.Forms.Padding(3)
        Me.tabSched.Size = New System.Drawing.Size(1073, 411)
        Me.tabSched.TabIndex = 2
        Me.tabSched.Text = "Schedule"
        '
        'panelSched
        '
        Me.panelSched.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelSched.BackColor = System.Drawing.SystemColors.Control
        Me.panelSched.Controls.Add(Me.btnGenerateSchedule)
        Me.panelSched.Controls.Add(Me.dgvGeneratedSched)
        Me.panelSched.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.panelSched.Location = New System.Drawing.Point(164, 7)
        Me.panelSched.Name = "panelSched"
        Me.panelSched.Size = New System.Drawing.Size(906, 396)
        Me.panelSched.TabIndex = 0
        '
        'btnGenerateSchedule
        '
        Me.btnGenerateSchedule.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.btnGenerateSchedule.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnGenerateSchedule.Location = New System.Drawing.Point(160, 334)
        Me.btnGenerateSchedule.Name = "btnGenerateSchedule"
        Me.btnGenerateSchedule.Size = New System.Drawing.Size(584, 50)
        Me.btnGenerateSchedule.TabIndex = 14
        Me.btnGenerateSchedule.Text = "Generate &Schedule"
        Me.btnGenerateSchedule.UseVisualStyleBackColor = True
        '
        'dgvGeneratedSched
        '
        Me.dgvGeneratedSched.AllowUserToAddRows = False
        Me.dgvGeneratedSched.AllowUserToDeleteRows = False
        Me.dgvGeneratedSched.AllowUserToResizeColumns = False
        Me.dgvGeneratedSched.AllowUserToResizeRows = False
        DataGridViewCellStyle11.BackColor = System.Drawing.Color.WhiteSmoke
        Me.dgvGeneratedSched.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle11
        Me.dgvGeneratedSched.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgvGeneratedSched.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvGeneratedSched.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgvGeneratedSched.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.dgvGeneratedSched.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvGeneratedSched.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle12
        Me.dgvGeneratedSched.ColumnHeadersHeight = 40
        Me.dgvGeneratedSched.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.dgvGeneratedSched.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column7, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4, Me.DataGridViewTextBoxColumn5, Me.DataGridViewTextBoxColumn6, Me.Column6, Me.DataGridViewTextBoxColumn7})
        Me.dgvGeneratedSched.GridColor = System.Drawing.SystemColors.Control
        Me.dgvGeneratedSched.Location = New System.Drawing.Point(3, 5)
        Me.dgvGeneratedSched.MultiSelect = False
        Me.dgvGeneratedSched.Name = "dgvGeneratedSched"
        Me.dgvGeneratedSched.ReadOnly = True
        Me.dgvGeneratedSched.RowHeadersVisible = False
        Me.dgvGeneratedSched.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        Me.dgvGeneratedSched.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvGeneratedSched.ShowEditingIcon = False
        Me.dgvGeneratedSched.Size = New System.Drawing.Size(898, 323)
        Me.dgvGeneratedSched.StandardTab = True
        Me.dgvGeneratedSched.TabIndex = 13
        '
        'Column7
        '
        DataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.Column7.DefaultCellStyle = DataGridViewCellStyle13
        Me.Column7.FillWeight = 60.0!
        Me.Column7.HeaderText = "DAY"
        Me.Column7.Name = "Column7"
        Me.Column7.ReadOnly = True
        Me.Column7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic
        '
        'DataGridViewTextBoxColumn3
        '
        DataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.DataGridViewTextBoxColumn3.DefaultCellStyle = DataGridViewCellStyle14
        Me.DataGridViewTextBoxColumn3.FillWeight = 120.0!
        Me.DataGridViewTextBoxColumn3.HeaderText = "TIME"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.ReadOnly = True
        Me.DataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic
        '
        'DataGridViewTextBoxColumn4
        '
        DataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.DataGridViewTextBoxColumn4.DefaultCellStyle = DataGridViewCellStyle15
        Me.DataGridViewTextBoxColumn4.HeaderText = "SUBJECT CODE"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.ReadOnly = True
        Me.DataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic
        '
        'DataGridViewTextBoxColumn5
        '
        DataGridViewCellStyle16.Padding = New System.Windows.Forms.Padding(25, 0, 25, 0)
        Me.DataGridViewTextBoxColumn5.DefaultCellStyle = DataGridViewCellStyle16
        Me.DataGridViewTextBoxColumn5.FillWeight = 175.0!
        Me.DataGridViewTextBoxColumn5.HeaderText = "PROFESSOR"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.ReadOnly = True
        Me.DataGridViewTextBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic
        '
        'DataGridViewTextBoxColumn6
        '
        DataGridViewCellStyle17.Padding = New System.Windows.Forms.Padding(25, 0, 25, 0)
        Me.DataGridViewTextBoxColumn6.DefaultCellStyle = DataGridViewCellStyle17
        Me.DataGridViewTextBoxColumn6.FillWeight = 175.0!
        Me.DataGridViewTextBoxColumn6.HeaderText = "PROCTOR"
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        Me.DataGridViewTextBoxColumn6.ReadOnly = True
        Me.DataGridViewTextBoxColumn6.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic
        '
        'Column6
        '
        DataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.Column6.DefaultCellStyle = DataGridViewCellStyle18
        Me.Column6.HeaderText = "SECTION"
        Me.Column6.Name = "Column6"
        Me.Column6.ReadOnly = True
        Me.Column6.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic
        '
        'DataGridViewTextBoxColumn7
        '
        DataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.DataGridViewTextBoxColumn7.DefaultCellStyle = DataGridViewCellStyle19
        Me.DataGridViewTextBoxColumn7.FillWeight = 65.0!
        Me.DataGridViewTextBoxColumn7.HeaderText = "ROOM"
        Me.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7"
        Me.DataGridViewTextBoxColumn7.ReadOnly = True
        Me.DataGridViewTextBoxColumn7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.Control
        Me.Panel1.Controls.Add(Me.btnChangeProctorPref)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.btnRooms)
        Me.Panel1.Controls.Add(Me.btnDeleteSched)
        Me.Panel1.Controls.Add(Me.btnRefresh)
        Me.Panel1.Controls.Add(Me.btnImageSched)
        Me.Panel1.Controls.Add(Me.btnPdfSched)
        Me.Panel1.Location = New System.Drawing.Point(9, 7)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(149, 359)
        Me.Panel1.TabIndex = 0
        '
        'btnChangeProctorPref
        '
        Me.btnChangeProctorPref.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnChangeProctorPref.Location = New System.Drawing.Point(13, 304)
        Me.btnChangeProctorPref.Name = "btnChangeProctorPref"
        Me.btnChangeProctorPref.Size = New System.Drawing.Size(122, 40)
        Me.btnChangeProctorPref.TabIndex = 6
        Me.btnChangeProctorPref.TabStop = False
        Me.btnChangeProctorPref.Text = "&Proctoring Preference"
        Me.btnChangeProctorPref.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(32, 28)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(50, 16)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Option:"
        '
        'btnRooms
        '
        Me.btnRooms.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.btnRooms.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRooms.Location = New System.Drawing.Point(13, 257)
        Me.btnRooms.Name = "btnRooms"
        Me.btnRooms.Size = New System.Drawing.Size(122, 40)
        Me.btnRooms.TabIndex = 4
        Me.btnRooms.TabStop = False
        Me.btnRooms.Text = "&Rooms"
        Me.btnRooms.UseVisualStyleBackColor = True
        '
        'btnDeleteSched
        '
        Me.btnDeleteSched.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.btnDeleteSched.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDeleteSched.Location = New System.Drawing.Point(13, 198)
        Me.btnDeleteSched.Name = "btnDeleteSched"
        Me.btnDeleteSched.Size = New System.Drawing.Size(122, 40)
        Me.btnDeleteSched.TabIndex = 4
        Me.btnDeleteSched.TabStop = False
        Me.btnDeleteSched.Text = "&Delete Schedule"
        Me.btnDeleteSched.UseVisualStyleBackColor = True
        '
        'btnRefresh
        '
        Me.btnRefresh.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.btnRefresh.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRefresh.Location = New System.Drawing.Point(13, 152)
        Me.btnRefresh.Name = "btnRefresh"
        Me.btnRefresh.Size = New System.Drawing.Size(122, 40)
        Me.btnRefresh.TabIndex = 4
        Me.btnRefresh.TabStop = False
        Me.btnRefresh.Text = "Re&fresh"
        Me.btnRefresh.UseVisualStyleBackColor = True
        '
        'btnImageSched
        '
        Me.btnImageSched.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.btnImageSched.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnImageSched.Location = New System.Drawing.Point(13, 93)
        Me.btnImageSched.Name = "btnImageSched"
        Me.btnImageSched.Size = New System.Drawing.Size(122, 40)
        Me.btnImageSched.TabIndex = 4
        Me.btnImageSched.TabStop = False
        Me.btnImageSched.Text = "Export Schedule" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "as &JPEG"
        Me.btnImageSched.UseVisualStyleBackColor = True
        '
        'btnPdfSched
        '
        Me.btnPdfSched.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.btnPdfSched.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPdfSched.Location = New System.Drawing.Point(13, 47)
        Me.btnPdfSched.Name = "btnPdfSched"
        Me.btnPdfSched.Size = New System.Drawing.Size(122, 40)
        Me.btnPdfSched.TabIndex = 4
        Me.btnPdfSched.TabStop = False
        Me.btnPdfSched.Text = "Ge&nerate PDF File"
        Me.btnPdfSched.UseVisualStyleBackColor = True
        '
        'Faculty_chkbox
        '
        Me.Faculty_chkbox.FillWeight = 15.0!
        Me.Faculty_chkbox.HeaderText = ""
        Me.Faculty_chkbox.Name = "Faculty_chkbox"
        Me.Faculty_chkbox.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.Faculty_chkbox.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic
        '
        'Faculty_facID
        '
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.Faculty_facID.DefaultCellStyle = DataGridViewCellStyle2
        Me.Faculty_facID.FillWeight = 30.0!
        Me.Faculty_facID.HeaderText = "ID"
        Me.Faculty_facID.Name = "Faculty_facID"
        Me.Faculty_facID.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic
        Me.Faculty_facID.Visible = False
        '
        'Faculty_facName
        '
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.Padding = New System.Windows.Forms.Padding(20, 0, 20, 0)
        Me.Faculty_facName.DefaultCellStyle = DataGridViewCellStyle3
        Me.Faculty_facName.FillWeight = 90.0!
        Me.Faculty_facName.HeaderText = "NAME"
        Me.Faculty_facName.Name = "Faculty_facName"
        Me.Faculty_facName.ReadOnly = True
        Me.Faculty_facName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic
        '
        'Faculty_dept
        '
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.Faculty_dept.DefaultCellStyle = DataGridViewCellStyle4
        Me.Faculty_dept.FillWeight = 50.76142!
        Me.Faculty_dept.HeaderText = "DEPARTMENT"
        Me.Faculty_dept.Name = "Faculty_dept"
        Me.Faculty_dept.ReadOnly = True
        Me.Faculty_dept.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic
        '
        'Column5
        '
        Me.Column5.HeaderText = "Fullname"
        Me.Column5.Name = "Column5"
        Me.Column5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic
        Me.Column5.Visible = False
        '
        'Column9
        '
        Me.Column9.HeaderText = "TYPE"
        Me.Column9.Name = "Column9"
        Me.Column9.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic
        Me.Column9.Visible = False
        '
        'Column8
        '
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.Column8.DefaultCellStyle = DataGridViewCellStyle5
        Me.Column8.FillWeight = 50.0!
        Me.Column8.HeaderText = "PROCTORING"
        Me.Column8.Name = "Column8"
        Me.Column8.ReadOnly = True
        Me.Column8.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic
        '
        'Column4
        '
        Me.Column4.HeaderText = "Notif"
        Me.Column4.Name = "Column4"
        Me.Column4.Visible = False
        '
        'Column11
        '
        Me.Column11.HeaderText = "DEPT ID"
        Me.Column11.Name = "Column11"
        Me.Column11.Visible = False
        '
        'DataGridViewCheckBoxColumn1
        '
        Me.DataGridViewCheckBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        Me.DataGridViewCheckBoxColumn1.FillWeight = 20.0!
        Me.DataGridViewCheckBoxColumn1.HeaderText = ""
        Me.DataGridViewCheckBoxColumn1.Name = "DataGridViewCheckBoxColumn1"
        Me.DataGridViewCheckBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridViewCheckBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic
        Me.DataGridViewCheckBoxColumn1.Width = 35
        '
        'ID
        '
        Me.ID.HeaderText = "ID"
        Me.ID.Name = "ID"
        Me.ID.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic
        Me.ID.Visible = False
        '
        'DataGridViewTextBoxColumn1
        '
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridViewTextBoxColumn1.DefaultCellStyle = DataGridViewCellStyle7
        Me.DataGridViewTextBoxColumn1.FillWeight = 60.0!
        Me.DataGridViewTextBoxColumn1.HeaderText = "SUBJECT CODE"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        Me.DataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic
        '
        'DataGridViewTextBoxColumn2
        '
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridViewTextBoxColumn2.DefaultCellStyle = DataGridViewCellStyle8
        Me.DataGridViewTextBoxColumn2.FillWeight = 250.0!
        Me.DataGridViewTextBoxColumn2.HeaderText = "DESCRIPTION"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.ReadOnly = True
        Me.DataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic
        '
        'Column3
        '
        Me.Column3.FillWeight = 60.0!
        Me.Column3.HeaderText = "TYPE"
        Me.Column3.Name = "Column3"
        Me.Column3.ReadOnly = True
        Me.Column3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic
        '
        'Column1
        '
        DataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.Column1.DefaultCellStyle = DataGridViewCellStyle9
        Me.Column1.FillWeight = 60.0!
        Me.Column1.HeaderText = "YEAR LEVEL"
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        Me.Column1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic
        '
        'Column2
        '
        Me.Column2.FillWeight = 70.0!
        Me.Column2.HeaderText = "SECTIONS"
        Me.Column2.Name = "Column2"
        Me.Column2.ReadOnly = True
        Me.Column2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic
        '
        'Column10
        '
        Me.Column10.HeaderText = "DEPT ID"
        Me.Column10.Name = "Column10"
        Me.Column10.Visible = False
        '
        'Column12
        '
        Me.Column12.FillWeight = 85.0!
        Me.Column12.HeaderText = "DEPARTMENT"
        Me.Column12.Name = "Column12"
        Me.Column12.ReadOnly = True
        Me.Column12.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic
        '
        'DeptWindow
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1081, 469)
        Me.Controls.Add(Me.TabControl)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MinimumSize = New System.Drawing.Size(1097, 508)
        Me.Name = "DeptWindow"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Deptartment Window"
        Me.TabControl.ResumeLayout(False)
        Me.btnProctoringNotif.ResumeLayout(False)
        Me.btnProctoringNotif.PerformLayout()
        Me.grpInfo.ResumeLayout(False)
        Me.grpInfo.PerformLayout()
        CType(Me.picFaculty, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgvFaculty, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tabSubject.ResumeLayout(False)
        Me.tabSubject.PerformLayout()
        CType(Me.dgvSubjects, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tabSched.ResumeLayout(False)
        Me.panelSched.ResumeLayout(False)
        CType(Me.dgvGeneratedSched, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents TabControl As TabControl
    Friend WithEvents btnProctoringNotif As TabPage
    Friend WithEvents tabSubject As TabPage
    Friend WithEvents dgvFaculty As DataGridView
    Friend WithEvents grpInfo As GroupBox
    Friend WithEvents lblFacType As Label
    Friend WithEvents lblName As Label
    Friend WithEvents lblEmail As Label
    Friend WithEvents lblContact As Label
    Friend WithEvents btnDelFaculty As Button
    Friend WithEvents btnEditFaculty As Button
    Friend WithEvents btnAddFaculty As Button
    Friend WithEvents dgvSubjects As DataGridView
    Friend WithEvents chk2ndSem As CheckBox
    Friend WithEvents chk1stSem As CheckBox
    Friend WithEvents btnDelSubj As Button
    Friend WithEvents btnEditSubj As Button
    Friend WithEvents btnAddSubj As Button
    Friend WithEvents chkCheckAllFaculty As CheckBox
    Friend WithEvents chkCheckAllSubject As CheckBox
    Friend WithEvents txtSearch As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents picFaculty As PictureBox
    Friend WithEvents tabSched As TabPage
    Friend WithEvents panelSched As Panel
    Friend WithEvents btnGenerateSchedule As Button
    Friend WithEvents dgvGeneratedSched As DataGridView
    Friend WithEvents Panel1 As Panel
    Friend WithEvents btnImageSched As Button
    Friend WithEvents btnPdfSched As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents btnRefresh As Button
    Friend WithEvents btnDeleteSched As Button
    Friend WithEvents btnRooms As Button
    Friend WithEvents btnRefreshFacultyTable As Button
    Friend WithEvents btnClass As Button
    Friend WithEvents Column7 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As DataGridViewTextBoxColumn
    Friend WithEvents Column6 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn7 As DataGridViewTextBoxColumn
    Friend WithEvents lblDept As Label
    Friend WithEvents btnChangeProctorPref As Button
    Friend WithEvents btnCourse As Button
    Friend WithEvents btnAllPartTime As Button
    Friend WithEvents btnAllFulltime As Button
    Friend WithEvents btnProfEd As Button
    Friend WithEvents btnGenEd As Button
    Friend WithEvents Faculty_chkbox As DataGridViewCheckBoxColumn
    Friend WithEvents Faculty_facID As DataGridViewTextBoxColumn
    Friend WithEvents Faculty_facName As DataGridViewTextBoxColumn
    Friend WithEvents Faculty_dept As DataGridViewTextBoxColumn
    Friend WithEvents Column5 As DataGridViewTextBoxColumn
    Friend WithEvents Column9 As DataGridViewTextBoxColumn
    Friend WithEvents Column8 As DataGridViewTextBoxColumn
    Friend WithEvents Column4 As DataGridViewTextBoxColumn
    Friend WithEvents Column11 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewCheckBoxColumn1 As DataGridViewCheckBoxColumn
    Friend WithEvents ID As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents Column3 As DataGridViewTextBoxColumn
    Friend WithEvents Column1 As DataGridViewTextBoxColumn
    Friend WithEvents Column2 As DataGridViewTextBoxColumn
    Friend WithEvents Column10 As DataGridViewTextBoxColumn
    Friend WithEvents Column12 As DataGridViewTextBoxColumn
End Class
