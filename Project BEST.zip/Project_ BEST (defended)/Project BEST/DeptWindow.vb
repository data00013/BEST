﻿Imports MySql.Data.MySqlClient
Imports System.Globalization
Imports System.IO
Imports System.Reflection.MethodBase

Public Class DeptWindow

    'Public Shared codeblack As Integer = 0

    Dim reader As MySqlDataReader
    Dim DBconnection As New MySqlConnection(LoginForm.ConnectionString)
    Dim cmd As MySqlCommand
    Dim doneLoadFacultyTable As Boolean = False
    Dim doneLoadSubjectTable As Boolean = False

    Public Shared facId As Integer = Nothing
    Public Shared proctorID As Integer = Nothing
    Public Shared secName As String = Nothing
    Public Shared subjCode As String = Nothing
    Public Shared subjId As String = Nothing
    Public Shared sem As Integer
    'Public Shared arrSubjectID As New ArrayList
    'Public Shared arrFacultyID As New ArrayList

    Dim str As String

    Private Sub DeptWindow_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        If LoginForm.accType = "Default" Then
            AdminControl.Show()
        Else
            LoginForm.Show()
        End If
        Me.Dispose()
    End Sub

    Private Sub DeptWindow_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If LoginForm.accType = "Default" Then
            Me.Text = "Admin"
        ElseIf LoginForm.accType = "Regular" Then
            Me.Text = LoginForm.dept_name & " - " & LoginForm.dept_code & " Department"
        End If

            picFaculty.Image = My.Resources.NoImage
        If Date.Now.Month >= 8 And Date.Now.Month <= 12 Then
            sem = 1
            chk1stSem.Checked = CheckState.Checked
        Else
            sem = 2
            chk2ndSem.Checked = CheckState.Checked
        End If
        doneLoadFacultyTable = False
        LoadFacultyTable()
        LoadSubjectTable()
        LoadSchedTable()
    End Sub


    '''
    '''----FACULTY TAB 
    '''
    Public Sub RefreshFacultyStatus()
        Try
            For i As Integer = 0 To dgvFaculty.RowCount - 1
                Dim proctoringAssignment As String = Nothing, facNotifRead As Integer = 0
                cmd = New MySqlCommand("SELECT RoomName, fac_notifRead FROM faculty LEFT JOIN (SELECT DISTINCT(proctor_id), CONCAT(rm_bldg,'-',rm_number) AS RoomName FROM sched JOIN room ON sched.rm_id=room.rm_id) AS A ON faculty.fac_id=A.proctor_id WHERE fac_id=" & dgvFaculty.Rows(i).Cells(1).Value & ";", DBconnection)
                DBconnection.Open()
                reader = cmd.ExecuteReader
                reader.Read()
                'MsgBox(If(reader.IsDBNull(reader.GetOrdinal("RoomName")), Nothing, reader.GetString("RoomName")))
                'MsgBox(reader.GetString("fac_notifRead"))
                proctoringAssignment = If(reader.IsDBNull(reader.GetOrdinal("RoomName")), Nothing, reader.GetString("RoomName"))
                facNotifRead = reader.GetString("fac_notifRead")
                DBconnection.Close()
                dgvFaculty.Rows(i).Cells(6).Value = If(IsNothing(proctoringAssignment), "--Unassigned--", proctoringAssignment)
                dgvFaculty.Rows(i).Cells(7).Value = facNotifRead

                Dim unReadStyle As New DataGridViewCellStyle
                Dim readStyle As New DataGridViewCellStyle
                unReadStyle.Font = New Font(dgvFaculty.Font, FontStyle.Bold)
                readStyle.Font = New Font(dgvFaculty.Font, FontStyle.Regular)
                If dgvFaculty.Rows(i).Cells(7).Value = 1 Then
                    dgvFaculty.Rows(i).DefaultCellStyle = unReadStyle
                Else
                    dgvFaculty.Rows(i).DefaultCellStyle = readStyle
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod.Name)
        Finally
            DBconnection.Dispose()
        End Try
    End Sub

    Public Sub LoadFacultyTable()
        Try
            doneLoadFacultyTable = False
            dgvFaculty.Rows.Clear()

            Dim facultyNotEmpty As Boolean = True
            cmd = New MySqlCommand("SELECT COUNT(*) AS RowCount FROM faculty" & If(LoginForm.accType = "Default", "", " WHERE dept_id=" & LoginForm.dept_id) & ";", DBconnection)
            DBconnection.Open()
            reader = cmd.ExecuteReader
            reader.Read()
            If reader.GetString("RowCount") = 0 Then
                facultyNotEmpty = False
            End If
            DBconnection.Close()

            If facultyNotEmpty Then
                cmd = New MySqlCommand(
                    "SELECT 
                        faculty.fac_id,
                        faculty.fac_altName,
                        faculty.fac_fullName,
                        department.dept_code,
                        faculty.fac_type,
                        faculty.fac_notifRead,
                        RoomName,
                        department.dept_id
                    FROM faculty 
                    JOIN department ON faculty.dept_id=department.dept_id 
                    LEFT JOIN (SELECT DISTINCT(proctor_id), CONCAT(rm_bldg,'-',rm_number) AS RoomName FROM sched JOIN room ON sched.rm_id=room.rm_id) AS RoomTable ON faculty.fac_id=RoomTable.proctor_id
                    " & If(LoginForm.accType = "Default", "", " WHERE department.dept_id=" & LoginForm.dept_id) & "
                    ORDER BY department.dept_id, faculty.fac_altName;",
                    DBconnection)
                DBconnection.Open()
                reader = cmd.ExecuteReader()
                While reader.Read()
                    dgvFaculty.Rows.Add(
                        False,
                        reader.GetString("fac_id"),
                        If(reader.IsDBNull(reader.GetOrdinal("fac_altName")), reader.GetString("fac_fullName"), reader.GetString("fac_altName")),
                        reader.GetString("dept_code"),
                        reader.GetString("fac_fullName"),
                        reader.GetString("fac_type"),
                        If(reader.IsDBNull(reader.GetOrdinal("RoomName")), "--Unassigned--", reader.GetString("RoomName")),
                        reader.GetString("fac_notifRead"),
                        reader.GetString("dept_id")
                    )
                End While
                DBconnection.Close()

                Dim unReadStyle As New DataGridViewCellStyle
                unReadStyle.Font = New Font(dgvFaculty.Font, FontStyle.Bold)
                For i As Integer = 0 To dgvFaculty.RowCount() - 1
                    If dgvFaculty.Rows(i).Cells(7).Value = 1 Then
                        dgvFaculty.Rows(i).DefaultCellStyle = unReadStyle
                    End If
                Next
            Else
                dgvFaculty.Rows.Add(False, "--No Data--", "--No Data--", "--No Data--", "--No Data--", "--No Data--", "--No Data--", "--No Data--", "--No Data--")
            End If

            countCheckedFaculty()
            doneLoadFacultyTable = True
            dgvFaculty.ClearSelection()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod().Name)
        Finally
            DBconnection.Dispose()
        End Try
    End Sub

    Private Sub btnAllFulltime_Click(sender As Object, e As EventArgs) Handles btnAllFulltime.Click
        For i As Integer = 0 To dgvFaculty.RowCount - 1
            If dgvFaculty.Rows(i).Cells(5).Value = "1" Then
                dgvFaculty.Rows(i).Cells(0).Value = True
            End If
        Next
        grpInfo.Focus()
    End Sub

    Private Sub btnAllPartTime_Click(sender As Object, e As EventArgs) Handles btnAllPartTime.Click
        For i As Integer = 0 To dgvFaculty.RowCount - 1
            If dgvFaculty.Rows(i).Cells(5).Value = "0" Then
                dgvFaculty.Rows(i).Cells(0).Value = True
            End If
        Next
        grpInfo.Focus()
    End Sub

    Private Sub dgvFaculty_CurrentCellChanged(ByVal sender As Object, ByVal e As EventArgs) Handles dgvFaculty.CurrentCellChanged
        If doneLoadFacultyTable And dgvFaculty.SelectedRows.Count = 1 Then
            If dgvFaculty.CurrentRow.Cells(1).Value <> "--No Data--" Then
                Try
                    facId = dgvFaculty.CurrentRow.Cells(1).Value
                    btnEditFaculty.Enabled = True

                    cmd = New MySqlCommand("SELECT * FROM faculty WHERE fac_id = '" & dgvFaculty.CurrentRow.Cells(1).Value & "';", DBconnection)
                    DBconnection.Open()
                    reader = cmd.ExecuteReader()
                    reader.Read()
                    Dim contact As String = "(0" & reader.GetString("fac_contact").Substring(3, 3) & ") - " & reader.GetString("fac_contact").Substring(6, 3) & " - " & reader.GetString("fac_contact").Substring(9, 4)

                    If Not IsDBNull(reader("fac_pic")) Then
                        Dim ms As New MemoryStream(DirectCast(reader("fac_pic"), Byte()))
                        picFaculty.Image = Image.FromStream(ms)
                    Else
                        picFaculty.Image = My.Resources.NoImage
                    End If

                    lblName.Text = "Name: " & dgvFaculty.CurrentRow.Cells(4).Value
                    lblDept.Text = "Department: " & dgvFaculty.CurrentRow.Cells(3).Value
                    lblContact.Text = "Contact No.: " & contact
                    lblEmail.Text = "E-mail Ad.: " & If(reader.IsDBNull(reader.GetOrdinal("fac_email")), "--No Data--", reader.GetString("fac_email"))
                    lblFacType.Text = "Type: " & If(reader.GetString("fac_type") = 1, "Full-time", "Part-time")

                    DBconnection.Close()
                Catch ex As Exception
                    MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod().Name)
                Finally
                    DBconnection.Dispose()
                End Try
            End If
        Else
            picFaculty.Image = My.Resources.NoImage
            lblName.Text = "Name: --No Data--"
            lblDept.Text = "Department: --No Data--"
            lblContact.Text = "Contact No.: --No Data--"
            lblEmail.Text = "E-mail Ad.: --No Data--"
            lblFacType.Text = "Type: --No Data--"
        End If
    End Sub

    Private Sub btnAddFaculty_Click(sender As Object, e As EventArgs) Handles btnAddFaculty.Click
        AddFaculty.ShowDialog()
        grpInfo.Focus()
    End Sub

    Private Sub btnEditFaculty_Click(sender As Object, e As EventArgs) Handles btnEditFaculty.Click
        Try
            If dgvFaculty.SelectedRows.Count > 0 Then
                If dgvFaculty.CurrentRow.Cells(2).Value <> "--No Data--" Then
                    facId = dgvFaculty.CurrentRow.Cells(1).Value
                    EditFaculty.ShowDialog()
                End If
            Else
                MsgBox("Please select a row", MsgBoxStyle.Exclamation)
            End If
            grpInfo.Focus()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, GetCurrentMethod().Name)
        End Try
    End Sub

    Private Sub btnDelFaculty_Click(sender As Object, e As EventArgs) Handles btnDelFaculty.Click
        Try
            If dgvFaculty.SelectedRows.Count > 0 Then
                If dgvFaculty.CurrentRow.Cells(2).Value <> "--No Data--" Then
                    IbaPa.DeleteRow(dgvFaculty, 1, 2, "faculty", "fac_id")
                    LoadFacultyTable()
                End If
            Else
                MsgBox("Please select a row", MsgBoxStyle.Exclamation)
            End If
            grpInfo.Focus()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, GetCurrentMethod().Name)
        End Try
    End Sub

    Private Sub btnRefreshFacultyTable_Click(sender As Object, e As EventArgs) Handles btnRefreshFacultyTable.Click
        LoadFacultyTable()
        grpInfo.Focus()
    End Sub

    Private Sub lblEmail_SizeChanged(sender As Object, e As EventArgs) Handles lblEmail.SizeChanged
        If lblEmail.Height > 18 And lblEmail.Height < 34 Then
            lblFacType.Location = New Point(lblFacType.Location.X, lblFacType.Location.Y + 16)
        Else
            lblFacType.Location = New Point(16, 280)
        End If
    End Sub

    Private Sub chkCheckAllFaculty_CheckedChanged(sender As Object, e As EventArgs) Handles chkCheckAllFaculty.CheckedChanged
        Dim countChecked As Integer = 0
        Try
            If chkCheckAllFaculty.CheckState = CheckState.Checked Then
                For i As Integer = 0 To dgvFaculty.Rows.Count() - 1
                    countChecked += 1
                    dgvFaculty.Rows(i).Cells(0).Value = True
                Next
            ElseIf chkCheckAllFaculty.CheckState = CheckState.Unchecked Then
                countChecked = 0
                For i As Integer = 0 To dgvFaculty.Rows.Count() - 1
                    dgvFaculty.Rows(i).Cells(0).Value = False
                Next
            End If

            If dgvFaculty.Rows.Count() > 0 Then
                If countChecked = dgvFaculty.Rows.Count() Then
                    chkCheckAllFaculty.ThreeState = False
                Else
                    chkCheckAllFaculty.ThreeState = True
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, GetCurrentMethod().Name)
        End Try
    End Sub

    Public Sub countCheckedFaculty()
        Dim countChecked As Integer = 0

        For i As Integer = 0 To dgvFaculty.Rows.Count() - 1
            If dgvFaculty.Rows(i).Cells(0).Value = True Then
                countChecked += 1
            End If
        Next

        If dgvFaculty.Rows.Count() > 0 Then
            If countChecked = dgvFaculty.Rows.Count() Then
                chkCheckAllFaculty.ThreeState = False
                chkCheckAllFaculty.CheckState = CheckState.Checked
            ElseIf countChecked = 0 Then
                chkCheckAllFaculty.ThreeState = False
                chkCheckAllFaculty.CheckState = CheckState.Unchecked
            Else
                chkCheckAllFaculty.ThreeState = True
                chkCheckAllFaculty.CheckState = CheckState.Indeterminate
            End If
        End If
    End Sub

    Private Sub dgvFaculty_CurrentCellDirtyStateChanged(sender As Object, e As EventArgs) Handles dgvFaculty.CurrentCellDirtyStateChanged
        If dgvFaculty.IsCurrentCellDirty Then
            dgvFaculty.CommitEdit(DataGridViewDataErrorContexts.Commit)
        End If
    End Sub

    Private Sub dgvFaculty_CellValueChanged(sender As Object, e As DataGridViewCellEventArgs) Handles dgvFaculty.CellValueChanged
        countCheckedFaculty()
    End Sub

    Private Sub dgvFaculty_CellMouseDoubleClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles dgvFaculty.CellMouseDoubleClick
        If e.RowIndex >= 0 And dgvFaculty.Rows(e.RowIndex).Cells(6).Value <> "--Unassigned--" And dgvFaculty.Rows(e.RowIndex).Cells(1).Value <> "--No Data--" Then
            proctorID = dgvFaculty.CurrentRow.Cells(1).Value
            Proctoring.ShowDialog()
        End If
    End Sub


    '''
    '''----SUBJECT TAB 
    '''
    Public Sub LoadSubjectTable()
        Try
            doneLoadSubjectTable = False

            Dim notEmpty As Boolean = True

            dgvSubjects.Rows.Clear()
            cmd = New MySqlCommand("SELECT COUNT(subj_id) AS RowCount FROM subject WHERE subj_sem=" & sem & If(LoginForm.accType = "Default", "", " AND dept_id=" & LoginForm.dept_id) & ";", DBconnection)
            DBconnection.Open()
            reader = cmd.ExecuteReader
            reader.Read()
            If reader.GetString("RowCount") = 0 Then
                notEmpty = False
            End If
            DBconnection.Close()

            If notEmpty Then
                cmd = New MySqlCommand(
                "SELECT A.subj_id, A.subj_code, A.subj_desc, A.subj_year, A.subj_type, A.Sections, A.dept_id, department.dept_code
                FROM (
	                SELECT subject.subj_id, subject.subj_code, subject.subj_desc, subject.subj_year, subject.subj_type, COUNT(class.subj_id) AS Sections, subject.dept_id
	                FROM class
	                RIGHT JOIN subject ON class.subj_id=subject.subj_id
	                WHERE subject.subj_sem = " & sem & If(LoginForm.accType = "Default", "", " AND dept_id=" & LoginForm.dept_id) & " 
	                GROUP BY subject.subj_id
	                ORDER BY subject.subj_year, subject.subj_code) AS A
                JOIN department ON A.dept_id=department.dept_id",
                DBconnection)

                DBconnection.Open()
                reader = cmd.ExecuteReader()
                dgvSubjects.Rows.Clear()

                While reader.Read
                    'str = Nothing
                    Dim year As String = Nothing
                    If reader.GetString("subj_year") = 1 Then
                        year = "1st Year"
                    ElseIf reader.GetString("subj_year") = 2 Then
                        year = "2nd Year"
                    ElseIf reader.GetString("subj_year") = 3 Then
                        year = "3rd Year"
                    ElseIf reader.GetString("subj_year") = 4 Then
                        year = "4th Year"
                    ElseIf reader.GetString("subj_year") = 5 Then
                        year = "5th Year"
                    End If

                    dgvSubjects.Rows.Add(False,
                                        reader.GetString("subj_id"),
                                        reader.GetString("subj_code"),
                                        reader.GetString("subj_desc"),
                                        If(reader.GetString("subj_type") = 1, "Gen Ed", "Prof Ed"),
                                        year,
                                        reader.GetString("Sections"),
                                        reader.GetString("dept_id"),
                                        reader.GetString("dept_code")
                    )
                End While

                DBconnection.Close()

                LiveSearch(txtSearch.Text)
            Else
                dgvSubjects.Rows.Add(False, "--No Data--", "--No Data--", "--No Data--", "--No Data--", "--No Data--", "--No Data--", "--No Data--")
            End If

            doneLoadSubjectTable = True
            dgvSubjects.ClearSelection()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod().Name)
        Finally
            DBconnection.Dispose()
        End Try
    End Sub

    Public Sub LiveSearch(ByVal searchThis As String)
        Try
            searchThis = searchThis.ToUpper
            If txtSearch.TextLength > 0 Then
                For i As Integer = 0 To dgvSubjects.Rows.Count() - 1
                    If dgvSubjects.Rows(i).Cells(2).Value.ToString.ToUpper.Contains(searchThis) Or
                        dgvSubjects.Rows(i).Cells(3).Value.ToString.ToUpper.Contains(searchThis) Or
                        dgvSubjects.Rows(i).Cells(4).Value.ToString.ToUpper.Contains(searchThis) Or
                        dgvSubjects.Rows(i).Cells(5).Value.ToString.ToUpper.Contains(searchThis) Or
                        dgvSubjects.Rows(i).Cells(8).Value.ToString.ToUpper.Contains(searchThis) Then
                        dgvSubjects.Rows.Item(i).Visible = True
                    Else
                        dgvSubjects.Rows.Item(i).Visible = False
                    End If
                Next
            Else
                For i As Integer = 0 To dgvSubjects.Rows.Count() - 1
                    dgvSubjects.Rows.Item(i).Visible = True
                Next
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, GetCurrentMethod().Name)
        End Try
    End Sub

    Private Sub btnAddSubj_Click(sender As Object, e As EventArgs) Handles btnAddSubj.Click
        AddSubject.ShowDialog()
    End Sub

    Private Sub btnEditSubj_Click(sender As Object, e As EventArgs) Handles btnEditSubj.Click
        Try
            Try
                If dgvSubjects.SelectedRows.Count = 0 Then
                    MsgBox("You must select 1 valid row", MsgBoxStyle.Exclamation, GetCurrentMethod.Name)
                ElseIf dgvSubjects.SelectedRows.Count = 1 Then
                    If dgvSubjects.CurrentRow.Cells(1).Value <> "--No Data--" Then
                        subjId = dgvSubjects.CurrentRow.Cells(1).Value
                        EditSubject.ShowDialog()
                    Else
                        MsgBox("Please select valid row", MsgBoxStyle.Exclamation)
                    End If
                Else
                    MsgBox("You can't select more than 1 row", MsgBoxStyle.Exclamation, GetCurrentMethod.Name)
                End If
            Catch ignoreThis As NullReferenceException

            End Try
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btnDelSubj_Click(sender As Object, e As EventArgs) Handles btnDelSubj.Click
        Try
            If dgvSubjects.SelectedRows.Count > 0 Then
                If dgvSubjects.CurrentRow.Cells(2).Value <> "--No Data--" Then
                    IbaPa.DeleteRow(dgvSubjects, 1, 2, "subject", "subj_id")
                Else
                    MsgBox("Please select valid row", MsgBoxStyle.Exclamation)
                End If
            Else
                MsgBox("Please select valid row", MsgBoxStyle.Exclamation)
            End If
            LoadSubjectTable()
            tabSubject.Focus()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, GetCurrentMethod().Name)
        End Try
    End Sub

    Private Function facultyNotEmpty() As Boolean
        Dim returnVal As Boolean = False
        Try
            cmd = New MySqlCommand("SELECT COUNT(*) As RowCount FROM faculty" & If(LoginForm.accType = "Default", "", " WHERE dept_id=" & LoginForm.dept_id) & ";", DBconnection)
            DBconnection.Open()
            reader = cmd.ExecuteReader
            reader.Read()
            If reader.GetString("RowCount") = 0 Then
                returnVal = False
            Else
                returnVal = True
            End If
            DBconnection.Close()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod.Name)
        End Try
        Return returnVal
    End Function 'used in dgvSubjects_CellMouseDoubleClick and btnClass_Click

    Private Sub dgvSubjects_CellMouseDoubleClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles dgvSubjects.CellMouseDoubleClick
        If e.RowIndex >= 0 Then
            If facultyNotEmpty() Then
                subjCode = dgvSubjects.CurrentRow.Cells(2).Value
                ClassEnroll.ShowDialog()
            Else
                MsgBox("Faculty Table is empty", MsgBoxStyle.Exclamation)
                TabControl.SelectedIndex = 0
                btnAddFaculty.Select()
            End If
        End If
    End Sub

    Private Sub btnClass_Click(sender As Object, e As EventArgs) Handles btnClass.Click
        If dgvSubjects.SelectedRows.Count() = 0 Then
            MsgBox("You must select 1 valid row", MsgBoxStyle.Exclamation, GetCurrentMethod.Name)
        ElseIf dgvSubjects.SelectedRows.Count() = 1 Then
            If dgvSubjects.CurrentRow.Cells(1).Value <> "--No Data--" And dgvSubjects.CurrentRow.Visible Then
                If facultyNotEmpty() Then
                    subjCode = dgvSubjects.CurrentRow.Cells(2).Value.ToString
                    ClassEnroll.ShowDialog()
                Else
                    MsgBox("Faculty Table is empty", MsgBoxStyle.Exclamation)
                    TabControl.SelectedIndex = 0
                    btnAddFaculty.Select()
                End If
            Else
                MsgBox("Please select valid row", MsgBoxStyle.Exclamation)
            End If
        Else
            MsgBox("You can't select more than 1 row", MsgBoxStyle.Exclamation, GetCurrentMethod.Name)
        End If
    End Sub

    Private Sub chkCheckAllSubject_CheckedChanged(sender As Object, e As EventArgs) Handles chkCheckAllSubject.CheckedChanged
        Dim countChecked As Integer = 0
        Try
            If chkCheckAllSubject.CheckState = CheckState.Checked Then
                For i As Integer = 0 To dgvSubjects.Rows.Count() - 1
                    countChecked += 1
                    dgvSubjects.Rows(i).Cells(0).Value = True
                Next
            ElseIf chkCheckAllSubject.CheckState = CheckState.Unchecked Then
                For i As Integer = 0 To dgvSubjects.Rows.Count() - 1
                    countChecked = 0
                    dgvSubjects.Rows(i).Cells(0).Value = False
                Next
            Else

            End If

            If dgvSubjects.Rows.Count() > 0 Then
                If countChecked = dgvSubjects.Rows.Count() Then
                    chkCheckAllSubject.ThreeState = False
                Else
                    chkCheckAllSubject.ThreeState = True
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, GetCurrentMethod.Name)
        End Try
    End Sub

    Private Sub dgvSubjects_CurrentCellDirtyStateChanged(sender As Object, e As EventArgs) Handles dgvSubjects.CurrentCellDirtyStateChanged
        If dgvSubjects.IsCurrentCellDirty Then
            dgvSubjects.CommitEdit(DataGridViewDataErrorContexts.Commit)
        End If
    End Sub

    Private Sub dgvSubjects_CellValueChanged(sender As Object, e As DataGridViewCellEventArgs) Handles dgvSubjects.CellValueChanged
        Try
            Dim countChecked As Integer = 0

            For i As Integer = 0 To dgvSubjects.Rows.Count() - 1
                If dgvSubjects.Rows(i).Cells(0).Value = True Then
                    countChecked += 1
                End If
            Next

            If dgvSubjects.Rows.Count() > 0 Then
                If countChecked = dgvSubjects.Rows.Count() Then
                    chkCheckAllSubject.ThreeState = False
                    chkCheckAllSubject.CheckState = CheckState.Checked
                ElseIf countChecked = 0 Then
                    chkCheckAllSubject.ThreeState = False
                    chkCheckAllSubject.CheckState = CheckState.Unchecked
                Else
                    chkCheckAllSubject.ThreeState = True
                    chkCheckAllSubject.CheckState = CheckState.Indeterminate
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, GetCurrentMethod.Name)
        End Try
    End Sub

    Private Sub chk1stSem_CheckedChanged(sender As Object, e As EventArgs) Handles chk1stSem.CheckedChanged
        If chk1stSem.Checked = True Then
            sem = 1
            chk2ndSem.Checked = CheckState.Unchecked
            If doneLoadSubjectTable Then
                LoadSubjectTable()
            End If
        ElseIf chk1stSem.Checked = CheckState.Unchecked And chk2ndSem.Checked = CheckState.Unchecked Then
            dgvSubjects.Rows.Clear()
        End If
        chkCheckAllSubject.CheckState = CheckState.Unchecked
    End Sub

    Private Sub chk2ndSem_CheckedChanged(sender As Object, e As EventArgs) Handles chk2ndSem.CheckedChanged
        If chk2ndSem.Checked = True Then
            sem = 2
            chk1stSem.Checked = CheckState.Unchecked
            If doneLoadSubjectTable Then
                LoadSubjectTable()
            End If
        ElseIf chk1stSem.Checked = CheckState.Unchecked And chk2ndSem.Checked = CheckState.Unchecked Then
            dgvSubjects.Rows.Clear()
        End If
        chkCheckAllSubject.CheckState = CheckState.Unchecked
    End Sub

    Private Sub btnGenEd_Click(sender As Object, e As EventArgs) Handles btnGenEd.Click
        If dgvSubjects.Rows(0).Cells(1).Value <> "--No Data--" Then
            For i As Integer = 0 To dgvSubjects.RowCount - 1
                If dgvSubjects.Rows(i).Cells(4).Value = "Gen Ed" Then
                    dgvSubjects.Rows(i).Cells(0).Value = True
                End If
            Next
        End If
        tabSubject.Focus()
    End Sub

    Private Sub btnProfEd_Click(sender As Object, e As EventArgs) Handles btnProfEd.Click
        If dgvSubjects.Rows(0).Cells(1).Value <> "--No Data--" Then
            For i As Integer = 0 To dgvSubjects.RowCount - 1
                If dgvSubjects.Rows(i).Cells(4).Value = "Prof Ed" Then
                    dgvSubjects.Rows(i).Cells(0).Value = True
                End If
            Next
        End If
        tabSubject.Focus()
    End Sub

    Private Sub txtSearch_TextChanged(sender As Object, e As EventArgs) Handles txtSearch.TextChanged
        Try
            LiveSearch(txtSearch.Text)
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, GetCurrentMethod.Name)
        End Try
    End Sub

    Private Sub txtSearch_Click(sender As Object, e As EventArgs) Handles txtSearch.Click, txtSearch.GotFocus
        txtSearch.SelectionStart = 0
        txtSearch.SelectionLength = txtSearch.TextLength
    End Sub

    Private Sub btnCourse_Click(sender As Object, e As EventArgs) Handles btnCourse.Click
        Course.ShowDialog()
    End Sub


    '''
    '''----SCHEDULE TAB 
    '''
    Public Sub LoadSchedTable(Optional MsgProctoringError As Boolean = False)
        dgvGeneratedSched.Rows.Clear()

        Try
            Dim schedNotEmpty As Boolean = True

            cmd = New MySqlCommand("SELECT COUNT(sched_day) AS RowCheck FROM sched WHERE sched_day is NOT NULL" & If(LoginForm.accType = "Default", "", " AND dept_id=" & LoginForm.dept_id) & ";", DBconnection)
            DBconnection.Open()
            reader = cmd.ExecuteReader
            reader.Read()
            If reader.GetString("RowCheck") = 0 Then
                schedNotEmpty = False
            End If
            DBconnection.Close()

            If schedNotEmpty Then
                cmd = New MySqlCommand(
                    "SELECT 
						sched.sched_day, 
    					sched.sched_start, 
    					sched.sched_end, 
    					subject.subj_code, 
    					section.sec_name, 
    					CONCAT(room.rm_bldg, '-', room.rm_number) AS RoomName, 
					    Professor.facName AS Professor, 
					    Proctor.facName AS Proctor
					FROM sched
					JOIN subject ON sched.subj_id=subject.subj_id
					JOIN section ON sched.sec_id=section.sec_id
					JOIN room ON sched.rm_id=room.rm_id
					JOIN class ON sched.sec_id=class.sec_id AND sched.subj_id=class.subj_id
					JOIN (SELECT faculty.fac_id, IFNULL(fac_altName, fac_fullName) AS facName FROM faculty) AS Professor ON sched.sec_id=class.sec_id AND sched.subj_id=class.subj_id AND class.fac_id=Professor.fac_id
					LEFT JOIN (SELECT faculty.fac_id, IFNULL(fac_altName, fac_fullName) AS facName FROM faculty) AS Proctor ON sched.proctor_id=Proctor.fac_id
					" & If(LoginForm.accType = "Default", "", "WHERE sched.dept_id=" & LoginForm.dept_id) & "
                    ORDER BY sched.sched_day, subject.subj_code, section.sec_name;", DBconnection)
                DBconnection.Open()
                reader = cmd.ExecuteReader
                Dim schedStart, schedEnd As DateTime
                While reader.Read
                    schedStart = reader.GetString("sched_start")
                    schedEnd = reader.GetString("sched_end")
                    dgvGeneratedSched.Rows.Add(
                        reader.GetString("sched_day"),
                        schedStart.ToString("h:mm tt") & " - " & schedEnd.ToString("h:mm tt"),
                        reader.GetString("subj_code"),
                        reader.GetString("Professor"),
                        If(reader.IsDBNull(reader.GetOrdinal("Proctor")), "--No Available--", reader.GetString("Proctor")),
                        reader.GetString("sec_name"),
                        reader.GetString("RoomName"))
                End While
                DBconnection.Close()
                Dim countNoProctor As Integer = 0
                Dim NoProctorRedBackground As New DataGridViewCellStyle
                NoProctorRedBackground.BackColor = Color.FromArgb(255, 111, 111)

                For i As Integer = 0 To dgvGeneratedSched.RowCount() - 1
                    If dgvGeneratedSched.Rows(i).Cells(4).Value = "--No Available--" Then
                        dgvGeneratedSched.Rows(i).DefaultCellStyle = NoProctorRedBackground
                    End If
                Next

                If MsgProctoringError Then
                    Dim rooms_NoProctor = From row As DataGridViewRow In dgvGeneratedSched.Rows Select (If(row.Cells(4).Value = "--No Available--", CStr(row.Cells(6).Value), Nothing)) Distinct
                    Dim strNoProctors As String = ""
                    For Each RoomName As String In rooms_NoProctor
                        If Not IsNothing(RoomName) Then
                            countNoProctor += 1
                            strNoProctors += countNoProctor & vbTab & RoomName & vbCrLf
                        End If
                    Next
                    If countNoProctor > 0 Then
                        MsgBox("The system has detected " & countNoProctor & " room" & If(countNoProctor > 1, "s", "") & " without proctor due to the insufficient amount of registered faculty" & vbCrLf & vbCrLf & strNoProctors)
                    End If
                End If
            Else
                dgvGeneratedSched.Rows.Add("--No Data--", "--No Data--", "--No Data--", "--No Data--", "--No Data--", "--No Data--", "--No Data--")
            End If

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod().Name)
        Finally
            DBconnection.Dispose()
        End Try
        dgvGeneratedSched.ClearSelection()
    End Sub

    Private Sub btnGenerateSchedule_Click(sender As Object, e As EventArgs) Handles btnGenerateSchedule.Click
        panelSched.Focus()
        DataReview.ShowDialog()
    End Sub

    Private Sub btnRefresh_Click(sender As Object, e As EventArgs) Handles btnRefresh.Click
        LoadSchedTable()
    End Sub

    Private Sub btnDeleteSched_Click(sender As Object, e As EventArgs) Handles btnDeleteSched.Click
        Try
            'cmd = New MySqlCommand("DELETE FROM sched WHERE dept_id=" & LoginForm.dept_id & ";", DBconnection)
            Dim clearSched As String = ""
            Dim resetFaculty As String = ""
            Dim resetSubject As String = ""
            If LoginForm.accType = "Default" Then
                clearSched = "TRUNCATE sched;"
                resetFaculty = "UPDATE faculty SET fac_proctorOK=NULL, fac_notifRead=0;"
                resetSubject = "UPDATE subject SET subj_day=NULL;"
            Else
                clearSched = "DELETE FROM sched WHERE dept_id=" & LoginForm.dept_id & ";"
                resetFaculty = "UPDATE faculty set fac_proctorOK=NULL, fac_notifRead=0 WHERE fac_proctorOK=" & LoginForm.dept_id & ";"
                resetSubject = "UPDATE subject SET subj_day=NULL WHERE dept_id=" & LoginForm.dept_id & ";"
            End If

            If MsgBox("Are you sure?", MsgBoxStyle.YesNo, "Delete confirmation") = MsgBoxResult.Yes Then
                cmd = New MySqlCommand(resetFaculty & resetSubject & clearSched, DBconnection)
                DBconnection.Open()
                cmd.ExecuteReader()
                DBconnection.Close()

                IbaPa.RollbackID("sched", "sched_id")

                RefreshFacultyStatus()

                Dim folderName As String = "Schedule"
                If Directory.Exists(folderName) Then
                    For Each fileName As String In Directory.EnumerateFiles(folderName & "\", "*")
                        File.Delete(fileName)
                    Next
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod.Name)
        Finally
            DBconnection.Dispose()
        End Try

        IbaPa.RollbackID("sched", "sched_id")

        LoadSchedTable()
    End Sub

    Private Sub btnRooms_Click(sender As Object, e As EventArgs) Handles btnRooms.Click
        RoomSelect.ShowDialog()
    End Sub

    Private Sub btnImageSched_Click(sender As Object, e As EventArgs) Handles btnImageSched.Click
        Try
            If Not dgvGeneratedSched.Rows(0).Cells(1).Value.ToString.Equals("--No Data--") And dgvGeneratedSched.RowCount > 0 Then
                btnImageSched.Enabled = False

                Dim arrSection As New ArrayList
                Dim arrDeptID As New ArrayList
                Dim secName As String = ""
                Dim deptCode As String = ""
                Dim deptName As String = ""
                Dim folderName As String = "Schedule"

                If Directory.Exists(folderName) Then
                    For Each fileName As String In Directory.EnumerateFiles(folderName & "\", "*.jpg")
                        File.Delete(fileName)
                    Next
                End If

                arrDeptID.Clear()
                If LoginForm.accType = "Default" Then
                    cmd = New MySqlCommand("SELECT DISTINCT(dept_id) FROM sched;", DBconnection)
                    DBconnection.Open()
                    reader = cmd.ExecuteReader
                    While reader.Read
                        arrDeptID.Add(reader.GetString("dept_id"))
                    End While
                    DBconnection.Close()
                Else
                    arrDeptID.Add(LoginForm.dept_id.ToString)
                End If

                arrSection.Clear()
                cmd = New MySqlCommand("SELECT DISTINCT(sec_id) AS sec_id FROM sched" & If(LoginForm.accType = "Default", "", " WHERE dept_id=" & LoginForm.dept_id) & ";", DBconnection)
                DBconnection.Open()
                reader = cmd.ExecuteReader
                While reader.Read
                    arrSection.Add(reader.GetString("sec_id"))
                End While
                DBconnection.Close()

                For Each deptID As String In arrDeptID
                    For Each sectionID In arrSection
                        'MsgBox("Sec ID: " & item)
                        Dim bmp As New Bitmap(My.Resources.schedule_image_template)
                        Dim gfx As Graphics = Graphics.FromImage(bmp)
                        Dim dataRowPositionY As Integer = 660
                        Dim rectangleHeight As Integer = 70
                        Dim rowFontSize As Integer = 32

                        Dim schedNotEmpty As Boolean = True
                        cmd = New MySqlCommand("SELECT COUNT(*) AS RowCount FROM sched WHERE sched.sec_id=" & sectionID & " AND sched.dept_id=" & deptID & ";", DBconnection)
                        DBconnection.Open()
                        reader = cmd.ExecuteReader
                        reader.Read()
                        If reader.GetString("RowCount") = 0 Then
                            schedNotEmpty = False
                        End If
                        DBconnection.Close()

                        'MsgBox("SELECT COUNT(*) AS RowCount FROM sched WHERE sched.sec_id=51 AND sched.dept_id=" & deptID & ";")

                        If schedNotEmpty Then
                            cmd = New MySqlCommand(
                                "SELECT sched.sched_day, sched.sched_start, sched.sched_end, subject.subj_code, Professor.facName AS professor, Proctor.facName AS proctor, CONCAT(rm_bldg,'-',rm_number) AS RoomName, section.sec_name, department.dept_code, department.dept_name
                                FROM sched
                                JOIN subject ON sched.subj_id=subject.subj_id
                                JOIN (SELECT faculty.fac_id, IFNULL(fac_altName, fac_fullName) AS facName FROM faculty) AS Professor ON sched.fac_id=Professor.fac_id
                                LEFT JOIN (SELECT faculty.fac_id, IFNULL(fac_altName, fac_fullName) AS facName FROM faculty) AS Proctor ON sched.proctor_id=Proctor.fac_id
                                JOIN room ON sched.rm_id=room.rm_id
                                JOIN section ON sched.sec_id=section.sec_id
                                JOIN department ON sched.dept_id=department.dept_id
                                WHERE sched.sec_id=" & sectionID & " AND department.dept_id=" & deptID & "
                                ORDER BY sched_day;", DBconnection)
                            'MsgBox("SectionID: " & sectionID & vbCrLf & "DeptID: " & deptID)
                            DBconnection.Open()
                            reader = cmd.ExecuteReader
                            While reader.Read
                                Using dataDrawFont As New Font("Microsoft Sans Serif", rowFontSize)

                                    Dim colDay = New Rectangle(131, dataRowPositionY, 166, 85)
                                    Dim colTime = New Rectangle(297, dataRowPositionY, 508, 85)
                                    Dim colSubject = New Rectangle(805, dataRowPositionY, 384, 85)
                                    Dim colProfessor = New Rectangle(1189, dataRowPositionY, 498, 85)
                                    Dim colProctor = New Rectangle(1687, dataRowPositionY, 502, 85)
                                    Dim colRoom = New Rectangle(2189, dataRowPositionY, 230, 85)

                                    Dim colDayStringFormat = New StringFormat()
                                    Dim colTimeStringFormat = New StringFormat()
                                    Dim colSubjectStringFormat = New StringFormat()
                                    Dim colProfessorStringFormat = New StringFormat()
                                    Dim colProctorStringFormat = New StringFormat()
                                    Dim colRoomStringFormat = New StringFormat()

                                    colDayStringFormat.Alignment = StringAlignment.Center
                                    colTimeStringFormat.Alignment = StringAlignment.Center
                                    colSubjectStringFormat.Alignment = StringAlignment.Center
                                    colProfessorStringFormat.Alignment = StringAlignment.Center
                                    colProctorStringFormat.Alignment = StringAlignment.Center
                                    colRoomStringFormat.Alignment = StringAlignment.Center

                                    colDayStringFormat.LineAlignment = StringAlignment.Center
                                    colTimeStringFormat.LineAlignment = StringAlignment.Center
                                    colSubjectStringFormat.LineAlignment = StringAlignment.Center
                                    colProfessorStringFormat.LineAlignment = StringAlignment.Center
                                    colProctorStringFormat.LineAlignment = StringAlignment.Center
                                    colRoomStringFormat.LineAlignment = StringAlignment.Center

                                    Dim schedStart As DateTime = reader.GetString("sched_start")
                                    Dim schedEnd As DateTime = reader.GetString("sched_end")

                                    gfx.DrawString(reader.GetString("sched_day"), dataDrawFont, Brushes.Black, colDay, colDayStringFormat)
                                    gfx.DrawString(schedStart.ToString("h:mm tt") & " - " & schedEnd.ToString("h:mm tt"), dataDrawFont, Brushes.Black, colTime, colTimeStringFormat)
                                    gfx.DrawString(reader.GetString("subj_code"), dataDrawFont, Brushes.Black, colSubject, colSubjectStringFormat)
                                    gfx.DrawString(reader.GetString("professor"), dataDrawFont, Brushes.Black, colProfessor, colProfessorStringFormat)
                                    gfx.DrawString(If(reader.IsDBNull(reader.GetOrdinal("Proctor")), "", reader.GetString("proctor")), dataDrawFont, Brushes.Black, colProctor, colProctorStringFormat)
                                    gfx.DrawString(reader.GetString("RoomName"), dataDrawFont, Brushes.Black, colRoom, colRoomStringFormat)

                                    dataRowPositionY += rectangleHeight
                                End Using
                            End While

                            secName = reader.GetString("sec_name")
                            Dim sectionFont As New Font("Microsoft Sans Serif", 38)
                            gfx.DrawString(secName, sectionFont, Brushes.Black, 423, 457)

                            deptName = reader.GetString("dept_name")
                            Dim deptNameFont As New Font("Microsoft Sans Serif", 30)
                            gfx.DrawString(deptName, deptNameFont, Brushes.DarkSlateGray, 45, 1545)

                            deptCode = reader.GetString("dept_code")
                            DBconnection.Close()

                            Try
                                If (Not Directory.Exists(folderName)) Then
                                    Directory.CreateDirectory(folderName)
                                End If
                            Catch ex As Exception
                                MsgBox(ex.Message, MsgBoxStyle.Exclamation)
                            End Try

                            bmp.Save(Path.Combine(folderName, deptCode & " " & secName & " Sched.jpg"))
                            bmp.Dispose()
                        End If
                    Next
                Next

                'MsgBox("Saved Successfully" & vbCrLf & "Check Image in Documents", MsgBoxStyle.Information, GetCurrentMethod.Name)

                If MsgBox("Saved Successfully" & vbCrLf & "Do you want to check?", MsgBoxStyle.YesNoCancel + MsgBoxStyle.Question) = DialogResult.Yes Then
                    Process.Start(folderName)
                End If
            Else
                MsgBox("No Data", MsgBoxStyle.Exclamation, GetCurrentMethod.Name)
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod().Name)
        Finally
            btnImageSched.Enabled = True
            DBconnection.Dispose()
        End Try
    End Sub

    Private Sub btnPdfSched_Click(sender As Object, e As EventArgs) Handles btnPdfSched.Click
        Try
            btnPdfSched.Enabled = False
            If Not dgvGeneratedSched.Rows(0).Cells(1).Value.ToString.Equals("--No Data--") And dgvGeneratedSched.RowCount > 0 Then
                IbaPa.ExportPDF()
            Else
                MsgBox("No Data", MsgBoxStyle.Exclamation, GetCurrentMethod.Name)
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, GetCurrentMethod.Name)
        Finally
            btnPdfSched.Enabled = True
        End Try
    End Sub

    Private Sub btnChangeProctorPref_Click(sender As Object, e As EventArgs) Handles btnChangeProctorPref.Click
        ProctoringPref.ShowDialog()
    End Sub
End Class