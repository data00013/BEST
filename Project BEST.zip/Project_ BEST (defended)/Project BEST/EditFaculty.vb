﻿Imports MySql.Data.MySqlClient
Imports System.IO
'Imports System.Drawing.Imaging
Imports System.Reflection.MethodBase

Public Class EditFaculty

    Dim reader As MySqlDataReader
    Dim DBconnection As New MySqlConnection(LoginForm.ConnectionString)
    Dim cmd As MySqlCommand

    Public Sub ResetEditFaculty()
        picFaculty.Image = My.Resources.NoImage
        txtLname.Clear()
        txtFname.Clear()
        txtMname.Clear()
        txtName.Clear()
        txtContact.Text = "09"
        txtEmail.Clear()
    End Sub

    Private Sub EditFaculty_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Text = "Edit Faculty Information - " & If(LoginForm.accType = "Default", "Admin Account", LoginForm.dept_code & " Department")

        IbaPa.LoadCbotData(cboDept, "department", "dept_code")

        If LoginForm.accType = "Default" Then
            cboDept.SelectedItem = DeptWindow.dgvFaculty.CurrentRow.Cells(3).Value
            cboDept.Enabled = True
            reqDept.Visible = True
        Else
            cboDept.SelectedItem = LoginForm.dept_code
            cboDept.Enabled = False
            reqDept.Visible = False
        End If

        Try
            cmd = New MySqlCommand(
                "SELECT 
                    fac_id, 
                    fac_pic,
                    fac_lname, 
                    fac_fname, 
                    fac_mname, 
                    fac_altname, 
                    fac_contact, 
                    fac_email, 
                    fac_type
                FROM faculty 
                WHERE fac_id=" & DeptWindow.facId & ";",
                DBconnection)
            DBconnection.Open()
            reader = cmd.ExecuteReader()
            reader.Read()

            If Not IsDBNull(reader("fac_pic")) Then
                Dim ms As New MemoryStream(DirectCast(reader("fac_pic"), Byte()))
                picFaculty.Image = Image.FromStream(ms)
            End If
            txtLname.Text = reader.GetString("fac_lname")
            txtFname.Text = reader.GetString("fac_fname")
            txtMname.Text = If(reader.IsDBNull(reader.GetOrdinal("fac_mname")), "", reader.GetString("fac_mname"))
            txtName.Text = If(reader.IsDBNull(reader.GetOrdinal("fac_altName")), "", reader.GetString("fac_altName"))
            txtContact.Text = "0" & reader.GetString("fac_contact").Substring(3, 10)
            txtEmail.Text = If(reader.IsDBNull(reader.GetOrdinal("fac_email")), "", reader.GetString("fac_email"))
            chkFulltime.CheckState = If(reader.GetString("fac_type") = 0, CheckState.Unchecked, CheckState.Checked)

            DBconnection.Close()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, "Error Loading Data of ID " & DeptWindow.facId)
        Finally
            DBconnection.Dispose()
        End Try
    End Sub

    Private Sub picFaculty_Click(sender As Object, e As EventArgs) Handles picFaculty.Click
        Try
            uploadPic.Filter = ("All Images |*.png; *.jpg; *.jpeg; ")
            uploadPic.FilterIndex = 4
            uploadPic.FileName = ""
            uploadPic.Title = "Select Profile Picture"
            If uploadPic.ShowDialog() = DialogResult.OK Then
                picFaculty.Image = IbaPa.MakeItSmall(Image.FromFile(uploadPic.FileName))
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            DBconnection.Dispose()
        End Try
    End Sub

    Public Sub EditFaculty(ByRef deptID As Integer)
        Dim contact As String = txtContact.Text

        'Name Concatenation / Fullname
        Dim fullname As String = txtLname.Text & ", " & txtFname.Text & If(txtMname.TextLength > 0, " " & txtMname.Text, "")

        'Nickname
        If txtName.TextLength = 0 Then
            txtName.Text = fullname
        End If

        Dim ms As New MemoryStream
        picFaculty.Image.Save(ms, Imaging.ImageFormat.Jpeg)

        cmd = New MySqlCommand(
            "UPDATE faculty 
            SET 
                fac_pic = @Image, 
                fac_fullName = @FullName,
                fac_altName = @Nickname, 
                fac_lname = @LastName, 
                fac_fname = @FirstName, 
                fac_mname = @MiddleName, 
                fac_type = @Type, 
                fac_contact = @Contact, 
                fac_email = @Email
            WHERE (fac_id = '" & DeptWindow.facId & "');",
        DBconnection)
        With cmd.Parameters
            .AddWithValue("@Image", ms.GetBuffer)
            .AddWithValue("@FullName", fullname)
            .AddWithValue("@Nickname", txtName.Text)
            .AddWithValue("@LastName", txtLname.Text)
            .AddWithValue("@FirstName", txtFname.Text)
            .AddWithValue("@MiddleName", If(txtMname.TextLength = 0, DBNull.Value, txtMname.Text))
            .AddWithValue("@Type", If(chkFulltime.Checked = True, 1, 0))
            .AddWithValue("@Contact", "+63" & contact.Substring(1, 10))
            .AddWithValue("@Email", If(txtEmail.TextLength = 0, DBNull.Value, txtEmail.Text))
        End With
        Try
            DBconnection.Open()
            cmd.ExecuteReader()
            DBconnection.Close()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod.Name)
        Finally
            DBconnection.Dispose()
        End Try

        DeptWindow.LoadFacultyTable()

        For i As Integer = 0 To DeptWindow.dgvFaculty.RowCount - 1
            If DeptWindow.dgvFaculty.Rows(i).Cells(1).Value = DeptWindow.facId Then
                DeptWindow.dgvFaculty.Rows(i).Selected = True
                DeptWindow.dgvFaculty.FirstDisplayedScrollingRowIndex = i
                Exit For
            End If
        Next
    End Sub

    Private Sub btnEditFaculty_Click(sender As Object, e As EventArgs) Handles btnEditFaculty.Click
        Try
            txtLname.Text = IbaPa.getRidOfFckinWhiteSpaces(txtLname.Text)
            txtFname.Text = IbaPa.getRidOfFckinWhiteSpaces(txtFname.Text)
            txtMname.Text = IbaPa.getRidOfFckinWhiteSpaces(txtMname.Text)
            txtName.Text = IbaPa.getRidOfFckinWhiteSpaces(txtName.Text)
            txtEmail.Text = IbaPa.getRidOfFckinWhiteSpaces(txtEmail.Text)

            '  *** Input Valivation ***
            'Profile Picture, Middle Name, Nickname and E-mail
            'Name must start in capital letter and not contain numbers and special charaters
            'Contact Number must be 11 digits

            If txtLname.TextLength > 0 And txtFname.TextLength > 0 And txtContact.Text.Length = 11 And cboDept.SelectedIndex > -1 Then
                '1st IF checks if required fields are not empty

                If InputValidation.isAllAlpha(txtLname.Text & txtFname.Text & txtMname.Text & txtName.Text) Then
                    '2nd IF checks if the name contains numbers or special characters

                    If InputValidation.ContainsSpecialChars(txtEmail.Text) Or txtEmail.Text.Length = 0 Then
                        '3rd IF checks if email is a valid E-mail

                        'name duplication
                        Dim facNameNotExist As Boolean = False
                        cmd = New MySqlCommand(
                        "SELECT COUNT(*) AS RowCheck FROM faculty 
                        WHERE fac_lname='" & txtLname.Text & "' AND fac_fname='" & txtFname.Text & "' " & If(txtMname.TextLength = 0, "", "AND fac_mname='" & txtMname.Text & "'") & " AND fac_id!=" & DeptWindow.facId & ";", DBconnection)
                        DBconnection.Open()
                        reader = cmd.ExecuteReader
                        reader.Read()
                        If reader.GetString("RowCheck") = 0 Then
                            facNameNotExist = True
                        End If
                        DBconnection.Close()

                        If facNameNotExist Then
                            EditFaculty(IbaPa.getTheFckinID("department", "dept_id", "dept_code", cboDept.SelectedItem))

                            Me.Close()
                        Else
                            MsgBox("Failed to Update" & vbCrLf & "Sorry! " & txtFname.Text & If(txtMname.TextLength > 0, " " & txtMname.Text.Substring(0, 1) & ".", "") & " " & txtLname.Text & " exist in the database" & vbCrLf & "Please try again")

                            ResetEditFaculty()
                        End If
                    Else
                        MsgBox("Invalid E-mail" & vbCrLf & "Try Again", MsgBoxStyle.Exclamation)
                        txtEmail.SelectAll()
                    End If
                Else
                    MsgBox("Invalid Input" & vbCrLf & "Name must NOT contain numbers or special characters", MsgBoxStyle.Exclamation)
                End If
            Else
                MsgBox("Please fill all fields" & vbCrLf & "First Name, Last Name and Contact are required", MsgBoxStyle.Exclamation)
                If cboDept.SelectedIndex - 1 Then
                    cboDept.Select()
                ElseIf txtLname.TextLength = 0 Then
                    txtLname.SelectAll()
                ElseIf txtFname.TextLength = 0 Then
                    txtFname.SelectAll()
                ElseIf txtMname.TextLength = 0 Then
                    txtMname.SelectAll()
                ElseIf txtContact.Text.Length = 0 Then
                    txtContact.SelectAll()
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, GetCurrentMethod.Name)
        End Try
    End Sub

    Private Sub txtLname_Click(sender As Object, e As EventArgs) Handles txtLname.GotFocus
        txtLname.SelectAll()
    End Sub

    Private Sub txtFname_Click(sender As Object, e As EventArgs) Handles txtFname.GotFocus
        txtFname.SelectAll()
    End Sub

    Private Sub txtMname_Click(sender As Object, e As EventArgs) Handles txtMname.GotFocus
        txtMname.SelectAll()
    End Sub

    Private Sub txtName_Click(sender As Object, e As EventArgs) Handles txtName.GotFocus
        txtName.SelectAll()
    End Sub

    Private Sub txtContact_Click(sender As Object, e As EventArgs) Handles txtContact.GotFocus
        txtContact.SelectionStart = 3
        txtContact.SelectionLength = txtContact.TextLength
    End Sub

    Private Sub txtEmail_Click(sender As Object, e As EventArgs) Handles txtEmail.GotFocus
        txtEmail.SelectAll()
    End Sub

    Private Sub txtLname_LostFocus(sender As Object, e As EventArgs) Handles txtLname.LostFocus
        txtLname.Text = StrConv(txtLname.Text, VbStrConv.ProperCase)
    End Sub

    Private Sub txtFname_LostFocus(sender As Object, e As EventArgs) Handles txtFname.LostFocus
        txtFname.Text = StrConv(txtFname.Text, VbStrConv.ProperCase)
    End Sub

    Private Sub txtMname_LostFocus(sender As Object, e As EventArgs) Handles txtMname.LostFocus
        txtMname.Text = StrConv(txtMname.Text, VbStrConv.ProperCase)
    End Sub

    Private Sub txtName_LostFocus(sender As Object, e As EventArgs) Handles txtName.LostFocus
        txtName.Text = StrConv(txtName.Text, VbStrConv.ProperCase)
    End Sub

    Private Sub EditFaculty_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        Me.Dispose()
    End Sub
End Class