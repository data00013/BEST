﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class EditSubject
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.txtSubjDuration = New System.Windows.Forms.NumericUpDown()
        Me.lblDuration = New System.Windows.Forms.Label()
        Me.lblDesc = New System.Windows.Forms.Label()
        Me.lblCode = New System.Windows.Forms.Label()
        Me.txtSubjDesc = New System.Windows.Forms.TextBox()
        Me.txtSubjCode = New System.Windows.Forms.TextBox()
        Me.btnEditSubject = New System.Windows.Forms.Button()
        Me.grpType = New System.Windows.Forms.GroupBox()
        Me.rdbMajor = New System.Windows.Forms.RadioButton()
        Me.rdbMinor = New System.Windows.Forms.RadioButton()
        Me.grpSem = New System.Windows.Forms.GroupBox()
        Me.rdb2Sem = New System.Windows.Forms.RadioButton()
        Me.rdb1Sem = New System.Windows.Forms.RadioButton()
        Me.grpYearLevel = New System.Windows.Forms.GroupBox()
        Me.rdb5Yr = New System.Windows.Forms.RadioButton()
        Me.rdb4Yr = New System.Windows.Forms.RadioButton()
        Me.rdb3Yr = New System.Windows.Forms.RadioButton()
        Me.rdb2Yr = New System.Windows.Forms.RadioButton()
        Me.rdb1Yr = New System.Windows.Forms.RadioButton()
        Me.cboDept = New System.Windows.Forms.ComboBox()
        Me.lblDept = New System.Windows.Forms.Label()
        CType(Me.txtSubjDuration, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpType.SuspendLayout()
        Me.grpSem.SuspendLayout()
        Me.grpYearLevel.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtSubjDuration
        '
        Me.txtSubjDuration.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSubjDuration.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSubjDuration.Increment = New Decimal(New Integer() {15, 0, 0, 0})
        Me.txtSubjDuration.Location = New System.Drawing.Point(92, 344)
        Me.txtSubjDuration.Maximum = New Decimal(New Integer() {300, 0, 0, 0})
        Me.txtSubjDuration.Minimum = New Decimal(New Integer() {60, 0, 0, 0})
        Me.txtSubjDuration.Name = "txtSubjDuration"
        Me.txtSubjDuration.Size = New System.Drawing.Size(44, 22)
        Me.txtSubjDuration.TabIndex = 40
        Me.txtSubjDuration.Value = New Decimal(New Integer() {60, 0, 0, 0})
        '
        'lblDuration
        '
        Me.lblDuration.AutoSize = True
        Me.lblDuration.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDuration.Location = New System.Drawing.Point(28, 346)
        Me.lblDuration.Name = "lblDuration"
        Me.lblDuration.Size = New System.Drawing.Size(58, 16)
        Me.lblDuration.TabIndex = 43
        Me.lblDuration.Text = "Duration"
        '
        'lblDesc
        '
        Me.lblDesc.AutoSize = True
        Me.lblDesc.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDesc.Location = New System.Drawing.Point(52, 244)
        Me.lblDesc.Name = "lblDesc"
        Me.lblDesc.Size = New System.Drawing.Size(76, 16)
        Me.lblDesc.TabIndex = 45
        Me.lblDesc.Text = "Description"
        '
        'lblCode
        '
        Me.lblCode.AutoSize = True
        Me.lblCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCode.Location = New System.Drawing.Point(52, 196)
        Me.lblCode.Name = "lblCode"
        Me.lblCode.Size = New System.Drawing.Size(41, 16)
        Me.lblCode.TabIndex = 46
        Me.lblCode.Text = "Code"
        '
        'txtSubjDesc
        '
        Me.txtSubjDesc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSubjDesc.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSubjDesc.Location = New System.Drawing.Point(38, 263)
        Me.txtSubjDesc.Multiline = True
        Me.txtSubjDesc.Name = "txtSubjDesc"
        Me.txtSubjDesc.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtSubjDesc.Size = New System.Drawing.Size(266, 60)
        Me.txtSubjDesc.TabIndex = 39
        '
        'txtSubjCode
        '
        Me.txtSubjCode.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtSubjCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSubjCode.Location = New System.Drawing.Point(38, 215)
        Me.txtSubjCode.Name = "txtSubjCode"
        Me.txtSubjCode.Size = New System.Drawing.Size(118, 22)
        Me.txtSubjCode.TabIndex = 38
        Me.txtSubjCode.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.txtSubjCode.WordWrap = False
        '
        'btnEditSubject
        '
        Me.btnEditSubject.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEditSubject.Location = New System.Drawing.Point(96, 383)
        Me.btnEditSubject.Name = "btnEditSubject"
        Me.btnEditSubject.Size = New System.Drawing.Size(140, 40)
        Me.btnEditSubject.TabIndex = 42
        Me.btnEditSubject.Text = "Edit Subject"
        Me.btnEditSubject.UseVisualStyleBackColor = True
        '
        'grpType
        '
        Me.grpType.Controls.Add(Me.rdbMajor)
        Me.grpType.Controls.Add(Me.rdbMinor)
        Me.grpType.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpType.Location = New System.Drawing.Point(153, 120)
        Me.grpType.Name = "grpType"
        Me.grpType.Size = New System.Drawing.Size(170, 70)
        Me.grpType.TabIndex = 37
        Me.grpType.TabStop = False
        Me.grpType.Text = "Type"
        '
        'rdbMajor
        '
        Me.rdbMajor.AutoSize = True
        Me.rdbMajor.Checked = True
        Me.rdbMajor.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdbMajor.Location = New System.Drawing.Point(6, 43)
        Me.rdbMajor.Name = "rdbMajor"
        Me.rdbMajor.Size = New System.Drawing.Size(151, 19)
        Me.rdbMajor.TabIndex = 9
        Me.rdbMajor.TabStop = True
        Me.rdbMajor.Text = "Professional Education"
        Me.rdbMajor.UseVisualStyleBackColor = True
        '
        'rdbMinor
        '
        Me.rdbMinor.AutoSize = True
        Me.rdbMinor.Enabled = False
        Me.rdbMinor.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdbMinor.Location = New System.Drawing.Point(6, 20)
        Me.rdbMinor.Name = "rdbMinor"
        Me.rdbMinor.Size = New System.Drawing.Size(127, 19)
        Me.rdbMinor.TabIndex = 8
        Me.rdbMinor.Text = "General Education"
        Me.rdbMinor.UseVisualStyleBackColor = True
        '
        'grpSem
        '
        Me.grpSem.Controls.Add(Me.rdb2Sem)
        Me.grpSem.Controls.Add(Me.rdb1Sem)
        Me.grpSem.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpSem.Location = New System.Drawing.Point(153, 45)
        Me.grpSem.Name = "grpSem"
        Me.grpSem.Size = New System.Drawing.Size(170, 70)
        Me.grpSem.TabIndex = 36
        Me.grpSem.TabStop = False
        Me.grpSem.Text = "Semester"
        '
        'rdb2Sem
        '
        Me.rdb2Sem.AutoSize = True
        Me.rdb2Sem.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdb2Sem.Location = New System.Drawing.Point(7, 43)
        Me.rdb2Sem.Name = "rdb2Sem"
        Me.rdb2Sem.Size = New System.Drawing.Size(123, 19)
        Me.rdb2Sem.TabIndex = 7
        Me.rdb2Sem.Text = "Second Semester"
        Me.rdb2Sem.UseVisualStyleBackColor = True
        '
        'rdb1Sem
        '
        Me.rdb1Sem.AutoSize = True
        Me.rdb1Sem.Checked = True
        Me.rdb1Sem.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdb1Sem.Location = New System.Drawing.Point(7, 20)
        Me.rdb1Sem.Name = "rdb1Sem"
        Me.rdb1Sem.Size = New System.Drawing.Size(104, 19)
        Me.rdb1Sem.TabIndex = 6
        Me.rdb1Sem.TabStop = True
        Me.rdb1Sem.Text = "First Semester"
        Me.rdb1Sem.UseVisualStyleBackColor = True
        '
        'grpYearLevel
        '
        Me.grpYearLevel.Controls.Add(Me.rdb5Yr)
        Me.grpYearLevel.Controls.Add(Me.rdb4Yr)
        Me.grpYearLevel.Controls.Add(Me.rdb3Yr)
        Me.grpYearLevel.Controls.Add(Me.rdb2Yr)
        Me.grpYearLevel.Controls.Add(Me.rdb1Yr)
        Me.grpYearLevel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpYearLevel.Location = New System.Drawing.Point(10, 45)
        Me.grpYearLevel.Name = "grpYearLevel"
        Me.grpYearLevel.Size = New System.Drawing.Size(140, 145)
        Me.grpYearLevel.TabIndex = 35
        Me.grpYearLevel.TabStop = False
        Me.grpYearLevel.Text = "Year Level"
        '
        'rdb5Yr
        '
        Me.rdb5Yr.AutoSize = True
        Me.rdb5Yr.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdb5Yr.Location = New System.Drawing.Point(7, 112)
        Me.rdb5Yr.Name = "rdb5Yr"
        Me.rdb5Yr.Size = New System.Drawing.Size(76, 19)
        Me.rdb5Yr.TabIndex = 5
        Me.rdb5Yr.Text = "Fifth Year"
        Me.rdb5Yr.UseVisualStyleBackColor = True
        '
        'rdb4Yr
        '
        Me.rdb4Yr.AutoSize = True
        Me.rdb4Yr.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdb4Yr.Location = New System.Drawing.Point(7, 89)
        Me.rdb4Yr.Name = "rdb4Yr"
        Me.rdb4Yr.Size = New System.Drawing.Size(88, 19)
        Me.rdb4Yr.TabIndex = 4
        Me.rdb4Yr.Text = "Fourth Year"
        Me.rdb4Yr.UseVisualStyleBackColor = True
        '
        'rdb3Yr
        '
        Me.rdb3Yr.AutoSize = True
        Me.rdb3Yr.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdb3Yr.Location = New System.Drawing.Point(7, 66)
        Me.rdb3Yr.Name = "rdb3Yr"
        Me.rdb3Yr.Size = New System.Drawing.Size(81, 19)
        Me.rdb3Yr.TabIndex = 3
        Me.rdb3Yr.Text = "Third Year"
        Me.rdb3Yr.UseVisualStyleBackColor = True
        '
        'rdb2Yr
        '
        Me.rdb2Yr.AutoSize = True
        Me.rdb2Yr.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdb2Yr.Location = New System.Drawing.Point(7, 43)
        Me.rdb2Yr.Name = "rdb2Yr"
        Me.rdb2Yr.Size = New System.Drawing.Size(95, 19)
        Me.rdb2Yr.TabIndex = 2
        Me.rdb2Yr.Text = "Second Year"
        Me.rdb2Yr.UseVisualStyleBackColor = True
        '
        'rdb1Yr
        '
        Me.rdb1Yr.AutoSize = True
        Me.rdb1Yr.Checked = True
        Me.rdb1Yr.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdb1Yr.Location = New System.Drawing.Point(7, 20)
        Me.rdb1Yr.Name = "rdb1Yr"
        Me.rdb1Yr.Size = New System.Drawing.Size(76, 19)
        Me.rdb1Yr.TabIndex = 1
        Me.rdb1Yr.TabStop = True
        Me.rdb1Yr.Text = "First Year"
        Me.rdb1Yr.UseVisualStyleBackColor = True
        '
        'cboDept
        '
        Me.cboDept.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboDept.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboDept.FormattingEnabled = True
        Me.cboDept.Location = New System.Drawing.Point(105, 11)
        Me.cboDept.Name = "cboDept"
        Me.cboDept.Size = New System.Drawing.Size(121, 24)
        Me.cboDept.TabIndex = 48
        '
        'lblDept
        '
        Me.lblDept.AutoSize = True
        Me.lblDept.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDept.Location = New System.Drawing.Point(19, 14)
        Me.lblDept.Name = "lblDept"
        Me.lblDept.Size = New System.Drawing.Size(84, 16)
        Me.lblDept.TabIndex = 47
        Me.lblDept.Text = "Department: "
        '
        'EditSubject
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(333, 435)
        Me.Controls.Add(Me.cboDept)
        Me.Controls.Add(Me.lblDept)
        Me.Controls.Add(Me.txtSubjDuration)
        Me.Controls.Add(Me.lblDuration)
        Me.Controls.Add(Me.lblDesc)
        Me.Controls.Add(Me.lblCode)
        Me.Controls.Add(Me.txtSubjDesc)
        Me.Controls.Add(Me.txtSubjCode)
        Me.Controls.Add(Me.btnEditSubject)
        Me.Controls.Add(Me.grpType)
        Me.Controls.Add(Me.grpSem)
        Me.Controls.Add(Me.grpYearLevel)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.MaximizeBox = False
        Me.Name = "EditSubject"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "EditSubject"
        CType(Me.txtSubjDuration, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpType.ResumeLayout(False)
        Me.grpType.PerformLayout()
        Me.grpSem.ResumeLayout(False)
        Me.grpSem.PerformLayout()
        Me.grpYearLevel.ResumeLayout(False)
        Me.grpYearLevel.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtSubjDuration As NumericUpDown
    Friend WithEvents lblDuration As Label
    Friend WithEvents lblDesc As Label
    Friend WithEvents lblCode As Label
    Friend WithEvents txtSubjDesc As TextBox
    Friend WithEvents txtSubjCode As TextBox
    Friend WithEvents btnEditSubject As Button
    Friend WithEvents grpType As GroupBox
    Friend WithEvents rdbMajor As RadioButton
    Friend WithEvents rdbMinor As RadioButton
    Friend WithEvents grpSem As GroupBox
    Friend WithEvents rdb2Sem As RadioButton
    Friend WithEvents rdb1Sem As RadioButton
    Friend WithEvents grpYearLevel As GroupBox
    Friend WithEvents rdb5Yr As RadioButton
    Friend WithEvents rdb4Yr As RadioButton
    Friend WithEvents rdb3Yr As RadioButton
    Friend WithEvents rdb2Yr As RadioButton
    Friend WithEvents rdb1Yr As RadioButton
    Friend WithEvents cboDept As ComboBox
    Friend WithEvents lblDept As Label
End Class
