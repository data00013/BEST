﻿Imports MySql.Data.MySqlClient
Imports System.Reflection.MethodBase

Public Class EditSubject
    Dim reader As MySqlDataReader
    Dim DBconnection As New MySqlConnection(LoginForm.ConnectionString)
    Dim cmd As MySqlCommand

    'Public Shared RecentEditSubjectID As Integer = Nothing

    Private Sub EditSubject_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Text = "Edit Subject Information - " & If(LoginForm.accType = "Default", "Admin Account", LoginForm.dept_code & " Department")
        Dim sec As Integer = Nothing
        Dim subjDuration As Integer = Nothing

        Try
            IbaPa.LoadCbotData(cboDept, "department", "dept_code")

            If LoginForm.accType = "Default" Then
                cboDept.SelectedItem = DeptWindow.dgvSubjects.CurrentRow.Cells(8).Value
            Else
                cboDept.SelectedItem = LoginForm.dept_code
                cboDept.Enabled = False
            End If

            If cboDept.SelectedItem = "CEAS" Then
                rdbMinor.Enabled = True
            Else
                rdbMinor.Enabled = False
                rdbMajor.Checked = True
            End If

            'autofill data of the selected subject
            cmd = New MySqlCommand("SELECT * FROM subject WHERE subj_id = '" & DeptWindow.subjId & "';", DBconnection)
            DBconnection.Open()
            reader = cmd.ExecuteReader()
            reader.Read()
            txtSubjDuration.Value = reader.GetString("subj_duration")
            txtSubjCode.Text = reader.GetString("subj_code")
            txtSubjDesc.Text = reader.GetString("subj_desc")
            'txtSubjDesc.ReadOnly = True

            If reader.GetString("subj_year") = 1 Then
                rdb1Yr.Checked = True
            ElseIf reader.GetString("subj_year") = 2 Then
                rdb2Yr.Checked = True
            ElseIf reader.GetString("subj_year") = 3 Then
                rdb3Yr.Checked = True
            ElseIf reader.GetString("subj_year") = 4 Then
                rdb4Yr.Checked = True
            ElseIf reader.GetString("subj_year") = 5 Then
                rdb5Yr.Checked = True
            End If

            If reader.GetString("subj_sem") = 1 Then
                rdb1Sem.Checked = True
            ElseIf reader.GetString("subj_sem") = 2 Then
                rdb2Sem.Checked = True
            End If

            If reader.GetString("subj_type") = 1 Then
                rdbMinor.Checked = True
            ElseIf reader.GetString("subj_type") = 2 Then
                rdbMajor.Checked = True
            End If
            DBconnection.Close()

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, GetCurrentMethod.Name)
        Finally
            DBconnection.Dispose()
        End Try
    End Sub

    Public Sub ResetEditingSubject()
        txtSubjCode.Clear()
        txtSubjDesc.Clear()
        txtSubjDuration.Value = txtSubjDuration.Minimum
    End Sub

    Private Sub txtSubjCode_LostFocus(sender As Object, e As EventArgs) Handles txtSubjCode.LostFocus
        Dim code As String = txtSubjCode.Text
        Try
            cmd = New MySqlCommand("SELECT subj_id, subj_desc FROM subject WHERE subj_code='" & code & "';", DBconnection)
            DBconnection.Open()
            reader = cmd.ExecuteReader
            If reader.Read Then
                If Not reader.IsDBNull(reader.GetOrdinal("subj_desc")) And Not reader.GetString("subj_id") = DeptWindow.subjId Then
                    MsgBox(code & " is already in the database" & vbCrLf & "Description: " & reader.GetString("subj_desc"), MsgBoxStyle.Exclamation)
                    txtSubjDesc.Text = reader.GetString("subj_desc")
                    txtSubjDesc.ReadOnly = True
                    txtSubjCode.Select()
                End If
            End If
            DBconnection.Close()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod.Name)
        Finally
            DBconnection.Dispose()
        End Try
    End Sub

    Public Sub EditSubject(ByRef yearLevel As Integer, ByRef semester As Integer, ByRef subjectType As Integer, ByRef deptID As Integer)
        cmd = New MySqlCommand(
            "UPDATE  subject
            SET 
                subj_code = @SubjectCode, 
                subj_desc = @Description, 
                subj_year = @YearLevel, 
                subj_sem = @Semester, 
                subj_type = @SubjectType, 
                subj_duration = @Duration,
                dept_id = @Department
            WHERE subj_id = " & DeptWindow.subjId & ";",
            DBconnection)
        With cmd.Parameters
            .AddWithValue("@SubjectCode", txtSubjCode.Text)
            .AddWithValue("@Description", txtSubjDesc.Text)
            .AddWithValue("@YearLevel", yearLevel)
            .AddWithValue("@Semester", semester)
            .AddWithValue("@SubjectType", subjectType)
            .AddWithValue("@Duration", txtSubjDuration.Value)
            .AddWithValue("@Department", deptID)
        End With

        Try
            DBconnection.Open()
            reader = cmd.ExecuteReader
            reader.Read()
            DBconnection.Close()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, GetCurrentMethod.Name)
        End Try

        DeptWindow.LoadSubjectTable()
        For i As Integer = 0 To DeptWindow.dgvSubjects.RowCount - 1
            If DeptWindow.dgvSubjects.Rows(i).Cells(1).Value = DeptWindow.subjId Then
                DeptWindow.dgvSubjects.Rows(i).Selected = True
                DeptWindow.dgvSubjects.FirstDisplayedScrollingRowIndex = i
                Exit For
            End If
        Next
    End Sub

    Private Sub btnEditSubject_Click(sender As Object, e As EventArgs) Handles btnEditSubject.Click
        Try

            Dim lvl As Integer = Nothing
            Dim sem As Integer = Nothing
            Dim type As Integer = Nothing

            'this is for Year Level radio buttons
            If rdb1Yr.Checked Then
                lvl = 1
            ElseIf rdb2Yr.Checked Then
                lvl = 2
            ElseIf rdb3Yr.Checked Then
                lvl = 3
            ElseIf rdb4Yr.Checked Then
                lvl = 4
            ElseIf rdb5Yr.Checked Then
                lvl = 5
            End If

            'this is for Semester radio buttons
            If rdb1Sem.Checked Then
                sem = 1
            ElseIf rdb2Sem.Checked Then
                sem = 2
            End If

            'this is for Subject Type radio buttons
            If rdbMinor.Checked Then
                type = 1 'Gen Ed
            ElseIf rdbMajor.Checked Then
                type = 2 'Prof Ed
            End If

            If Not IsNothing(lvl) And
                Not IsNothing(sem) And
                Not IsNothing(type) And
                txtSubjCode.TextLength > 0 And
                txtSubjDesc.TextLength > 0 And
                txtSubjDuration.Value > 0 And
                cboDept.SelectedIndex > -1 Then
                If Not IsNumeric(txtSubjCode.Text) And Not IsNumeric(txtSubjDesc.Text) Then
                    If Not InputValidation.ContainsSpecialChars(txtSubjCode.Text) And Not InputValidation.ContainsSpecialChars(txtSubjDesc.Text) Then
                        Dim subjectNotExist As Boolean = False
                        cmd = New MySqlCommand("SELECT COUNT(*) AS RowCheck FROM subject WHERE (subj_code='" & txtSubjCode.Text & "' OR subj_desc='" & txtSubjDesc.Text & "') AND subj_id!=" & DeptWindow.subjId & ";", DBconnection)
                        DBconnection.Open()
                        reader = cmd.ExecuteReader
                        reader.Read()
                        If reader.GetString("RowCheck") = 0 Then
                            subjectNotExist = True
                        End If
                        DBconnection.Close()

                        If subjectNotExist Then
                            EditSubject(lvl, sem, type, IbaPa.getTheFckinID("department", "dept_id", "dept_code", cboDept.SelectedItem))
                            Me.Close()
                        Else
                            MsgBox("Failed to Edit" & vbCrLf & "Sorry! You entered data that already exist in the database. It is either " & txtSubjCode.Text & " or " & txtSubjDesc.Text & vbCrLf & "Please try again", MsgBoxStyle.Exclamation)
                            ResetEditingSubject()
                        End If
                        'RecentEditSubjectID = DeptWindow.subjId
                    Else
                        MsgBox("Sorry! Special Character in Subject Code and Description is invalid" & vbCrLf & "Please try again", MsgBoxStyle.Exclamation)
                        ResetEditingSubject()
                    End If
                Else
                    MsgBox("Sorry! Numbers in Subject Code and Description is invalid" & vbCrLf & "Please try again", MsgBoxStyle.Exclamation)
                    ResetEditingSubject()
                End If
            Else
                MsgBox("Please fill all fields", MsgBoxStyle.Exclamation)
                ResetEditingSubject()
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod.Name)
        End Try
    End Sub

    Private Sub txtSubjCode_GotFocus(sender As Object, e As EventArgs) Handles txtSubjCode.GotFocus
        txtSubjCode.SelectionStart = 0
        txtSubjCode.SelectionLength = txtSubjCode.TextLength
    End Sub

    Private Sub txtSubjName_GotFocus(sender As Object, e As EventArgs) Handles txtSubjDesc.GotFocus
        txtSubjDesc.SelectionStart = 0
        txtSubjDesc.SelectionLength = txtSubjDesc.TextLength
    End Sub

    Private Sub EditSubject_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        Me.Dispose()
    End Sub

    Private Sub cboDept_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboDept.SelectedIndexChanged
        If cboDept.SelectedItem = "CEAS" Then
            rdbMinor.Enabled = True
        Else
            rdbMinor.Enabled = False
            rdbMajor.Checked = True
        End If
    End Sub
End Class