﻿Imports MySql.Data.MySqlClient
Imports System.Reflection.MethodBase
Imports System.Threading

Public Class DataReview

    Dim reader As MySqlDataReader
    Dim DBConnection As New MySqlConnection(LoginForm.ConnectionString)
    Dim cmd As MySqlCommand

    Sub LoadLstDeptData()
        Try
            cmd = New MySqlCommand("SELECT dept_code FROM department ORDER by dept_id;", DBConnection)
            DBConnection.Open()
            reader = cmd.ExecuteReader
            While reader.Read
                lstDept.Items.Add(reader.GetString("dept_code"))
            End While
            DBConnection.Close()
            lstDept.SelectedIndex = 0
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod.Name)
        Finally
            DBConnection.Dispose()
        End Try
    End Sub

    Private Sub DataReview_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            LoadLstDeptData()

            If LoginForm.accType = "Default" Then
                lstDept.Enabled = True
            Else
                lstDept.SelectedItem = LoginForm.dept_code
                lstDept.Enabled = False
            End If

            Dim HasRoomAssignment As Boolean = True
            Dim lstIndex As Integer = 0
            Dim indexOfNoRoomAssignment As Integer = Nothing
            Try
                Do
                    cmd = New MySqlCommand("SELECT COUNT(*) AS RowCount FROM room JOIN department ON room.dept_id=department.dept_id WHERE dept_code='" & If(LoginForm.accType = "Default", lstDept.Items(lstIndex), lstDept.SelectedItem) & "';", DBConnection)
                    DBConnection.Open()
                    reader = cmd.ExecuteReader
                    reader.Read()
                    If reader.GetString("RowCount") = 0 Then
                        HasRoomAssignment = False
                        indexOfNoRoomAssignment = lstIndex
                    End If
                    DBConnection.Close()
                    If HasRoomAssignment = False Or LoginForm.accType = "Regular" Or lstIndex = lstDept.Items.Count - 1 Then
                        Exit Do
                    End If
                    lstIndex += 1
                Loop
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod.Name)
            Finally
                DBConnection.Dispose()
            End Try

            If HasRoomAssignment Then
                btnProceedGenerate.Enabled = True
            Else
                If Not IsNothing(indexOfNoRoomAssignment) Then
                    lstDept.SelectedIndex = indexOfNoRoomAssignment
                End If
                btnProceedGenerate.Enabled = False
                MsgBox("You need to assign rooms for " & lstDept.SelectedItem & " Department")
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation)
        End Try
    End Sub

    Private Sub DataReview_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        Me.Dispose()
    End Sub

    Private Sub lstDept_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstDept.SelectedIndexChanged, lstRoom.SelectedIndexChanged
        Try
            If lstDept.SelectedIndex > -1 And lstDept.Items.Count > 0 Then
                dgvReviewProctor.Rows.Clear()
                For i As Integer = 0 To DeptWindow.dgvFaculty.RowCount - 1
                    If DeptWindow.dgvFaculty.Rows(i).Cells(3).Value() = lstDept.SelectedItem Then
                        If DeptWindow.dgvFaculty.Rows(i).Cells(0).Value() = True Then
                            dgvReviewProctor.Rows.Add(
                                DeptWindow.dgvFaculty.Rows(i).Cells(1).Value(),
                                DeptWindow.dgvFaculty.Rows(i).Cells(2).Value(),
                                If(DeptWindow.dgvFaculty.Rows(i).Cells(5).Value() = 1, "Full-Time", "Part-Time"))
                        End If
                    End If
                Next
                If dgvReviewProctor.RowCount = 0 Then
                    dgvReviewProctor.Rows.Add("--No Data--", "--No Data--", "--No Data--")
                End If
                dgvReviewProctor.ClearSelection()

                dgvReviewSubject.Rows.Clear()
                For i As Integer = 0 To DeptWindow.dgvSubjects.RowCount - 1
                    If DeptWindow.dgvSubjects.Rows(i).Cells(8).Value() = lstDept.SelectedItem Then
                        If DeptWindow.dgvSubjects.Rows(i).Cells(0).Value() = True Then
                            dgvReviewSubject.Rows.Add(
                                DeptWindow.dgvSubjects.Rows(i).Cells(1).Value(),
                                DeptWindow.dgvSubjects.Rows(i).Cells(2).Value(),
                                DeptWindow.dgvSubjects.Rows(i).Cells(4).Value(),
                                DeptWindow.dgvSubjects.Rows(i).Cells(5).Value())
                        End If
                    End If
                Next
                If dgvReviewSubject.RowCount = 0 Then
                    dgvReviewSubject.Rows.Add("--No Data--", "--No Data--", "--No Data--", "--No Data--")
                End If
                dgvReviewSubject.ClearSelection()

                Try
                    lstRoom.Items.Clear()
                    cmd = New MySqlCommand("SELECT CONCAT(rm_bldg,'-',rm_number) AS RoomNumber FROM room JOIN department ON room.dept_id=department.dept_id WHERE department.dept_code='" & lstDept.SelectedItem & "';", DBConnection)
                    DBConnection.Open()
                    reader = cmd.ExecuteReader
                    While reader.Read
                        lstRoom.Items.Add(reader.GetString("RoomNumber"))
                    End While
                    DBConnection.Close()
                Catch ex As Exception
                    MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod.Name)
                Finally
                    DBConnection.Dispose()
                End Try
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation)
        End Try
    End Sub

    Public Sub btnProceedGenerate_Click(sender As Object, e As EventArgs) Handles btnProceedGenerate.Click
        Try

            Me.Close()
            GenerateSchedule.GenerateSchedMainSub(DeptWindow.btnGenerateSchedule, DeptWindow.dgvFaculty, DeptWindow.dgvSubjects, lstDept.Items.Count)
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod.Name)
        Finally
            DBConnection.Dispose()
        End Try
    End Sub
End Class