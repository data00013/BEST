﻿Imports MySql.Data.MySqlClient
Imports System.Reflection.MethodBase
Imports System.IO

Module GenerateSchedule

    Dim reader As MySqlDataReader
    Dim DBconnection As New MySqlConnection(LoginForm.ConnectionString)
    Dim cmd As MySqlCommand

    Dim subjectID, subjectDay As Integer

    Dim PROF_EDUCATION_1 As Integer = 2
    Dim PROF_EDUCATION_2 As Integer = 4
    Dim GEN_EDUCATION_1 As Integer = 1
    Dim GEN_EDUCATION_2 As Integer = 3

    Dim startTime As String = "07:45:00"
    Dim endTime As String = "18:00:00"

    Public Sub GenerateSchedMainSub(ByVal generateButton As Button, ByVal ProctorTable As DataGridView, ByVal SubjectTable As DataGridView, ByRef deptCount As Integer)
        Try
            Dim strScheduleReport As String = ""
            Dim subjectCount As Integer = 0
            generateButton.Enabled = False

            StatusLogForm.Show()
            StatusLogForm.Hide()

            Dim deptID As Integer = 1
            Do
                If LoginForm.accType = "Regular" Then
                    deptID = LoginForm.dept_id
                End If

                StatusLogForm.StatusLog("Dept ID: " & deptID)
                StatusLogForm.StatusLog("")
                StatusLogForm.StatusLog("")

                Dim arrSubjectID_GenEd As New ArrayList
                Dim arrSubjectID_ProfEd As New ArrayList
                Dim arrfacultyID As New ArrayList

                'gets checked subject ID's
                arrSubjectID_GenEd.Clear()
                arrSubjectID_ProfEd.Clear()
                For i As Integer = 0 To SubjectTable.RowCount - 1
                    If SubjectTable.Rows(i).Cells(7).Value = deptID.ToString Then
                        If SubjectTable.Rows(i).Cells(0).Value = True And CInt(SubjectTable.Rows(i).Cells(6).Value) > 0 Then
                            If SubjectTable.Rows(i).Cells(4).Value = "Gen Ed" Then
                                arrSubjectID_GenEd.Add(SubjectTable.Rows(i).Cells(1).Value.ToString)        'General Education
                            ElseIf SubjectTable.Rows(i).Cells(4).Value = "Prof Ed" Then
                                arrSubjectID_ProfEd.Add(SubjectTable.Rows(i).Cells(1).Value.ToString)       'Professional Education
                            End If
                        End If
                    End If
                Next
                subjectCount = arrSubjectID_GenEd.Count + arrSubjectID_ProfEd.Count

                'gets all checked in Faculty Tab
                arrfacultyID.Clear()
                For i As Integer = 0 To ProctorTable.RowCount - 1
                    If ProctorTable.Rows(i).Cells(0).Value = True Then
                        arrfacultyID.Add(ProctorTable.Rows(i).Cells(1).Value.ToString)
                    End If
                Next

                Dim deptHasRooms As Boolean = True
                cmd = New MySqlCommand("SELECT COUNT(*) AS RowCount FROM room WHERE dept_id=" & deptID & ";", DBconnection)
                DBconnection.Open()
                reader = cmd.ExecuteReader
                reader.Read()
                'If reader.GetString("RowCount") Then
                DBconnection.Close()

                If arrSubjectID_GenEd.Count > 0 Or arrSubjectID_ProfEd.Count > 0 Then
                    StatusLogForm.StatusLog("Step 1: Clear Sched Table")
                    ResetSched(deptID)                                                  'Step 1: Clear Sched Table

                    StatusLogForm.StatusLog("Step 2: Divide Subjects")
                    If arrSubjectID_GenEd.Count > 0 Then
                        DivideSubjects(deptID, arrSubjectID_GenEd, 1)                   'Step 2: Divide Subjects
                    End If
                    If arrSubjectID_ProfEd.Count > 0 Then
                        DivideSubjects(deptID, arrSubjectID_ProfEd, 2)
                    End If

                    StatusLogForm.StatusLog("Step 3: Generate Sched")
                    GenerateSched(deptID)                                               'Step 3: Generate Sched

                    StatusLogForm.StatusLog("Step 4: Proctoring Assignment")
                    ProctoringAssignment(deptID, ProctorTable, arrfacultyID, deptCount) 'Step 4: Proctoring Assignment
                End If

                'IbaPa.CountRows("sched", "WHERE dept_id=" & deptID)
                strScheduleReport += "(" & IbaPa.CountRows("sched", "WHERE dept_id=" & deptID, "DISTINCT(subj_id)") & "/" & subjectCount & ") " & vbTab
                strScheduleReport += IbaPa.RetriveThis_AsString("department", "dept_code", "dept_id", deptID) & " Subjects " & vbTab
                strScheduleReport += If(CInt(IbaPa.CountRows("sched", "WHERE dept_id=" & deptID, "DISTINCT(subj_id)")) = subjectCount, "Complete", "Incomplete")
                strScheduleReport += vbCrLf

                If LoginForm.accType = "Regular" Then
                    Exit Do
                End If

                deptID += 1
            Loop Until deptID > deptCount

            MsgBox(strScheduleReport)

            StatusLogForm.SaveLogInTxtFormat()

            DeptWindow.LoadSchedTable(True)
            DeptWindow.RefreshFacultyStatus()

            generateButton.Enabled = True
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, GetCurrentMethod.Name)
        End Try
    End Sub

    Private Sub ResetSched(ByRef deptID As Integer)
        Try
            Dim resetFaculty As String = "UPDATE faculty SET fac_proctorOK=NULL, fac_notifRead=0 WHERE fac_proctorOK=" & deptID & ";"
            Dim resetSubject As String = "UPDATE subject SET subj_day=NULL WHERE dept_id=" & deptID & ";"
            Dim clearSched As String = "DELETE FROM sched WHERE dept_id=" & deptID & ";"

            cmd = New MySqlCommand(resetFaculty & resetSubject & clearSched, DBconnection)
            DBconnection.Open()
            cmd.ExecuteReader()
            DBconnection.Close()
            StatusLogForm.StatusLog("Reset sched dept_id=" & deptID)

            IbaPa.RollbackID("sched", "sched_id")

            Dim folderName As String = "Schedule"
            If Directory.Exists(folderName) Then
                For Each fileName As String In Directory.EnumerateFiles(folderName & "\", "*")
                    File.Delete(fileName)
                Next
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod.Name)
            StatusLogForm.StatusLog(ex.Message)
        Finally
            DBconnection.Dispose()
        End Try
        StatusLogForm.StatusLog("")
        StatusLogForm.StatusLog("")
    End Sub

    Private Sub DivideSubjects(ByRef deptID As Integer, ByRef arrCheckedSubjectID As ArrayList, ByRef subjectType As Integer)
        Try
            Dim arrSubjectID_fromDB As New ArrayList
            cmd = New MySqlCommand(
                "SELECT subject.subj_id, SUM(subject.subj_duration) AS DurationSum
                FROM class JOIN subject ON class.subj_id=subject.subj_id
                WHERE dept_id=" & deptID & "
                GROUP BY subj_id
                ORDER BY DurationSum DESC, RAND();", DBconnection)
            DBconnection.Open()
            reader = cmd.ExecuteReader
            While reader.Read
                If arrCheckedSubjectID.Contains(reader.GetString("subj_id").ToString) Then
                    arrSubjectID_fromDB.Add(reader.GetString("subj_id").ToString)
                End If
            End While
            DBconnection.Close()

            cmd = New MySqlCommand("UPDATE subject SET subj_day=" & If(subjectType = 1, GEN_EDUCATION_1, PROF_EDUCATION_1) & " WHERE subj_id='" & arrSubjectID_fromDB(0) & "';", DBconnection)
            DBconnection.Open()
            cmd.ExecuteReader()
            DBconnection.Close()

            If arrSubjectID_fromDB.Count > 1 Then
                cmd = New MySqlCommand("UPDATE subject SET subj_day=" & If(subjectType = 1, GEN_EDUCATION_2, PROF_EDUCATION_2) & " WHERE subj_id='" & arrSubjectID_fromDB(1) & "';", DBconnection)
                DBconnection.Open()
                cmd.ExecuteReader()
                DBconnection.Close()

                For i As Integer = 2 To arrSubjectID_fromDB.Count - 1
                    cmd = New MySqlCommand(
                        "SELECT subj_day
                        FROM (
                            SELECT subject.subj_code, subject.subj_duration, SUM(subject.subj_duration) AS DurationSum, subject.subj_day
                            FROM class JOIN subject ON class.subj_id=subject.subj_id
                            WHERE subject.subj_day is NOT NULL AND dept_id=" & deptID & "
                            GROUP BY subject.subj_day) AS temp_table
                        ORDER BY DurationSum, RAND()
                        LIMIT 1;", DBconnection)
                    DBconnection.Open()
                    reader = cmd.ExecuteReader
                    reader.Read()
                    subjectDay = reader.GetString("subj_day")
                    DBconnection.Close()

                    cmd = New MySqlCommand("UPDATE subject SET subj_day=" & subjectDay & " WHERE subj_id=" & arrSubjectID_fromDB(i) & ";", DBconnection)
                    DBconnection.Open()
                    cmd.ExecuteReader()
                    DBconnection.Close()
                Next
            End If

            StatusLogForm.StatusLog("Subjects Successfully divided")
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod.Name)
        Finally
            DBconnection.Dispose()
        End Try
        StatusLogForm.StatusLog("")
        StatusLogForm.StatusLog("")
    End Sub

    Private Sub GenerateSched(ByRef deptID As Integer)

        Dim str As String = ""
        'Dim rowCount As Integer

        Dim arrSectionID As New ArrayList
        Dim arrfacID As New ArrayList
        Dim arrRoomID As New ArrayList
        Dim arrSubjectID As New ArrayList
        Dim subjDuration As Integer = Nothing
        Dim arrRemoveSubjID As New ArrayList
        Dim timePickOffset As Integer = 0
        Dim countFalseInsertToSched As Integer = 0

        Dim subjIndexSelection As Integer = Nothing

        Dim pickedTime As DateTime = Nothing

        Dim insertToSched As Boolean = True
        Dim timeStart As DateTime = Nothing
        Dim timeEnd As DateTime = Nothing
        Dim breakTime As Integer = 15 'minutes
        Dim examDay As Integer

        examDay = 1
        Do 'This Loop is for "days"
            Try '
                Dim subjectCount As Integer = 0
                arrSubjectID.Clear()
                StatusLogForm.StatusLog("Day: " & examDay)
                cmd = New MySqlCommand("SELECT COUNT(subject.subj_id) AS RowCount FROM subject WHERE dept_id=" & deptID & " AND subject.subj_day=" & examDay & ";", DBconnection)
                DBconnection.Open()
                reader = cmd.ExecuteReader
                reader.Read()
                subjectCount = reader.GetString("RowCount")
                DBconnection.Close()
                StatusLogForm.StatusLog("Day " & examDay & " has " & subjectCount & " row/s")

                If subjectCount > 0 Then
                    cmd = New MySqlCommand("SELECT subj_id FROM subject WHERE dept_id=" & deptID & " AND subj_day=" & examDay & " ORDER BY subj_duration DESC, RAND();", DBconnection)
                    DBconnection.Open()
                    reader = cmd.ExecuteReader
                    While reader.Read
                        arrSubjectID.Add(reader.GetString("subj_id"))
                    End While
                    StatusLogForm.StatusLog("Subject Count: " & arrSubjectID.Count)
                End If
            Catch ex As Exception
                StatusLogForm.StatusLog("Error Getting Subject ID's")
                StatusLogForm.StatusLog(ex.Message)
                MsgBox(ex.Message, MsgBoxStyle.Critical, "Error Getting Subject ID's")
            Finally
                DBconnection.Dispose()
            End Try

            If arrSubjectID.Count > 0 Then
                Do
                    subjIndexSelection = 0
                    arrRemoveSubjID.Clear()
                    countFalseInsertToSched = 0
                    Do
                        'Get Subject Duration
                        Try
                            StatusLogForm.StatusLog("subj_id=" & arrSubjectID(subjIndexSelection))
                            cmd = New MySqlCommand("SELECT subj_duration FROM subject WHERE subj_id=" & arrSubjectID(subjIndexSelection) & ";", DBconnection)
                            DBconnection.Open()
                            reader = cmd.ExecuteReader
                            subjDuration = Nothing
                            If reader.Read Then
                                subjDuration = reader.GetString("subj_duration")
                            End If
                            DBconnection.Close()
                        Catch ex As Exception
                            MsgBox(ex.Message, MsgBoxStyle.Critical, "Error Getting Subject Duration")
                            StatusLogForm.StatusLog("Error Getting Subject Duration")
                            StatusLogForm.StatusLog(ex.Message)
                        Finally
                            DBconnection.Dispose()
                        End Try
                        StatusLogForm.StatusLog("Duration of SubjectID_" & arrSubjectID(subjIndexSelection) & ": " & subjDuration)

                        If Not IsNothing(subjDuration) Then
                            'Getting Section ID's and Faculty ID
                            Try
                                StatusLogForm.StatusLog("Getting Section ID's of SubjectID_" & arrSubjectID(subjIndexSelection))
                                arrSectionID.Clear()
                                arrfacID.Clear()
                                cmd = New MySqlCommand("SELECT sec_id, fac_id FROM class WHERE subj_id=" & arrSubjectID(subjIndexSelection) & ";", DBconnection)
                                DBconnection.Open()
                                reader = cmd.ExecuteReader
                                While reader.Read
                                    arrSectionID.Add(reader.GetString("sec_id"))
                                    arrfacID.Add(reader.GetString("fac_id"))
                                End While
                                DBconnection.Close()
                            Catch ex As Exception
                                StatusLogForm.StatusLog("Error Geting Sections" & vbCrLf & "Subject ID: " & arrSubjectID(subjIndexSelection))
                                StatusLogForm.StatusLog(ex.Message)
                                MsgBox(ex.Message, MsgBoxStyle.Critical, "Error Geting Sections" & vbCrLf & "Subject ID: " & arrSubjectID(subjIndexSelection))
                            Finally
                                DBconnection.Dispose()
                            End Try
                            StatusLogForm.StatusLog("Section Count: " & arrSectionID.Count)
                            For i As Integer = 0 To arrSectionID.Count - 1
                                StatusLogForm.StatusLog("sec_id=" & arrSectionID(i) & vbTab & "fac_id=" & arrfacID(i))
                            Next

                            Dim derivedTable As String =
                                "SELECT IF(A.sched_end is NULL, '" & startTime & "', A.sched_end) AS sched_end, rm_id
                                    FROM (SELECT MAX(sched_end) AS sched_end, room.rm_id
                                        FROM room 
                                        LEFT JOIN sched ON room.rm_id=sched.rm_id AND sched.sched_day=" & examDay & "
                                        " & If(examDay = 1 Or examDay = 3, "", "WHERE room.dept_id=" & deptID) & "
                                        GROUP BY room.rm_id) AS A"

                            'Selecting Time
                            pickedTime = Nothing
                            Try
                                StatusLogForm.StatusLog("Selecting Time")
                                cmd = New MySqlCommand(
                                    "SELECT 
                                	    sched_end 
                                	FROM (" & derivedTable & ") AS temp_table 
                                	GROUP BY sched_end 
                                	ORDER BY sched_end
                                	LIMIT " & timePickOffset & ",1;",
                                    DBconnection)
                                DBconnection.Open()
                                reader = cmd.ExecuteReader
                                reader.Read()
                                pickedTime = reader.GetString("sched_end")
                                DBconnection.Close()

                                cmd = New MySqlCommand(
                                    "SELECT sched_end FROM (
										SELECT 
								            sched_end
                                        FROM (" & derivedTable & ") AS temp_table 
							            WHERE sched_end >= '" & pickedTime.ToString("HH:mm:ss") & "'
                                        ORDER BY sched_end
                                        LIMIT " & arrSectionID.Count & ") AS temp_table2
									ORDER BY sched_end DESC
                                    LIMIT 1;",
                                    DBconnection)
                                DBconnection.Open()
                                reader = cmd.ExecuteReader
                                reader.Read()
                                pickedTime = reader.GetString("sched_end")
                                DBconnection.Close()
                            Catch ex As Exception
                                StatusLogForm.StatusLog("Error Selecting Time")
                                StatusLogForm.StatusLog(ex.Message)
                                MsgBox(ex.Message, MsgBoxStyle.Critical, "Error! Selecting Time")
                            Finally
                                DBconnection.Dispose()
                            End Try
                            StatusLogForm.StatusLog("Picked Time: " & pickedTime.ToString("h:mm tt"))

                            If pickedTime.AddMinutes(subjDuration).ToString("HH:mm:ss") > DateTime.Parse(endTime).ToString("HH:mm:ss") Then
                                MsgBox("Department: " & IbaPa.RetriveThis_AsString("department", "dept_name", "dept_id", deptID) & vbCrLf & "Picked Time: " & pickedTime.ToString("h:mm tt") & vbCrLf & vbCrLf & "Time exceeded the examination day. You must add more rooms", MsgBoxStyle.Exclamation)
                                Exit Sub
                            End If

                            'Room Selection
                            Try
                                StatusLogForm.StatusLog("Room Selection")
                                arrRoomID.Clear()
                                cmd = New MySqlCommand(
                                    "SELECT
                                        rm_id 
                                    FROM (" & derivedTable & ") AS temp_table 
					                WHERE sched_end <= '" & pickedTime.ToString("HH:mm:ss") & "'
                                    ORDER BY sched_end DESC
                                    LIMIT " & arrSectionID.Count & ";",
                                    DBconnection)
                                DBconnection.Open()
                                reader = cmd.ExecuteReader
                                While reader.Read
                                    arrRoomID.Add(reader.GetString("rm_id"))
                                End While
                            Catch ex As Exception
                                StatusLogForm.StatusLog("Error! Room Selection")
                                StatusLogForm.StatusLog(ex.Message)
                                MsgBox(ex.Message, MsgBoxStyle.Critical, "Error! Room Selection")
                            Finally
                                DBconnection.Dispose()
                            End Try
                            StatusLogForm.StatusLog("Room Count: " & arrRoomID.Count)
                            For Each room In arrRoomID
                                StatusLogForm.StatusLog("rm_id=" & room)
                            Next

                            If arrRoomID.Count < arrSectionID.Count Then
                                MsgBox("Department: " & IbaPa.RetriveThis_AsString("department", "dept_name", "dept_id", deptID) & vbCrLf & "No. of Rooms assigned: " & IbaPa.CountRows("room", "WHERE dept_id=" & deptID) & vbCrLf & vbCrLf & "Number of rooms assigned to the department is not enough. You must add more rooms and try again", MsgBoxStyle.Exclamation)
                                Exit Sub
                            End If

                            'checking if the selected subject can exam in pickedTime
                            insertToSched = True
                            StatusLogForm.StatusLog("Checking if the selected subject can exam in pickedTime")
                            StatusLogForm.StatusLog("Boolean 'insertToSched' is set to default value TRUE")
                            Try
                                Dim x As Integer = 1
                                For Each sectionID In arrSectionID
                                    StatusLogForm.StatusLog("(" & x & "/" & arrSectionID.Count & ")" & " Checking sec=" & sectionID)
                                    cmd = New MySqlCommand("SELECT sched_start, sched_end FROM sched WHERE sec_id=" & sectionID & " AND (sched_day=" & examDay & " OR sched_day is NULL);", DBconnection)
                                    DBconnection.Open()
                                    reader = cmd.ExecuteReader
                                    While reader.Read
                                        timeStart = reader.GetString("sched_start")
                                        timeEnd = reader.GetString("sched_end")
                                        If timeStart <= pickedTime.AddMinutes(breakTime) And timeEnd >= pickedTime.AddMinutes(breakTime) Then
                                            insertToSched = False
                                            StatusLogForm.StatusLog(timeStart.ToString("h:mm tt") & " < " & pickedTime.ToString("h:mm tt") & " < " & timeEnd.ToString("h:mm tt") & vbTab & "FALSE")
                                            StatusLogForm.StatusLog("value of insertToSched changed to False")
                                            Exit For
                                        Else
                                            StatusLogForm.StatusLog(timeStart.ToString("h:mm tt") & " < " & pickedTime.ToString("h:mm tt") & " < " & timeEnd.ToString("h:mm tt") & vbTab & "TRUE")
                                        End If
                                    End While
                                    DBconnection.Close()
                                    x += 1
                                Next
                            Catch ex As Exception
                                StatusLogForm.StatusLog("Error checking pickedTime")
                                StatusLogForm.StatusLog(ex.Message)
                                MsgBox(ex.Message, MsgBoxStyle.Critical, "Error checking pickedTime")
                            Finally
                                StatusLogForm.StatusLog("Connection Dispose")
                                DBconnection.Dispose()
                            End Try

                            'MsgBox(insertToSched)
                            Try
                                If insertToSched Then
                                    StatusLogForm.StatusLog("pickedTime: " & pickedTime.ToString("h:mm tt"))
                                    pickedTime = pickedTime.AddMinutes(breakTime)
                                    StatusLogForm.StatusLog("Add 15-minute break")
                                    StatusLogForm.StatusLog("pickedTime: " & pickedTime.ToString("h:mm tt"))

                                    StatusLogForm.StatusLog("Starting to insert to Sched Table")
                                    For i As Integer = 0 To arrSectionID.Count - 1
                                        cmd = New MySqlCommand("INSERT INTO sched (sched_day, sched_start, sched_end,fac_id, rm_id, subj_id, sec_id, dept_id) VALUES (@Day, @Start, @End, @Faculty, @Room, @Subject, @Section, @Department)", DBconnection)
                                        'MsgBox("INSERT INTO sched (sched_day, sched_start, sched_end, rm_id, subj_id, sec_id, dept_id) VALUES (" & examDay & ", " & pickedTime.ToString("HH:mm:ss") & ", " & pickedTime.AddMinutes(subjDuration).ToString("HH:mm:ss") & ", " & arrRoomID(i) & ", " & DeptWindow.arrSubjectID(subjIndexSelection) & ", " & arrSectionID(i) & ", " & LoginForm.dept_id & ")")
                                        With cmd.Parameters
                                            .AddWithValue("@Day", examDay)
                                            .AddWithValue("@Start", pickedTime.ToString("HH:mm:ss"))
                                            .AddWithValue("@End", pickedTime.AddMinutes(subjDuration).ToString("HH:mm:ss"))
                                            .AddWithValue("@Faculty", arrfacID(i))
                                            .AddWithValue("@Room", arrRoomID(i))
                                            .AddWithValue("@Subject", arrSubjectID(subjIndexSelection))
                                            .AddWithValue("@Section", arrSectionID(i))
                                            .AddWithValue("Department", deptID)
                                        End With
                                        Try
                                            DBconnection.Open()
                                            cmd.ExecuteReader()
                                            DBconnection.Close()
                                        Catch ex As Exception
                                            MsgBox(ex.Message, MsgBoxStyle.Critical, "Error Insertion")
                                        Finally
                                            DBconnection.Dispose()
                                        End Try
                                    Next
                                    StatusLogForm.StatusLog("Successfully Inserted to Sched Table")
                                    StatusLogForm.StatusLog("countFalseInsertToSched: " & countFalseInsertToSched)
                                    StatusLogForm.StatusLog("timePickOffset: " & timePickOffset)
                                    countFalseInsertToSched = 0
                                    timePickOffset = 0
                                    arrRemoveSubjID.Add(arrSubjectID(subjIndexSelection))
                                Else
                                    countFalseInsertToSched += 1
                                    StatusLogForm.StatusLog("countFalseInsertToSched: " & countFalseInsertToSched)
                                End If
                            Catch ex As Exception
                                StatusLogForm.StatusLog("Error! Making Sched")
                                StatusLogForm.StatusLog(ex.Message)
                                MsgBox(ex.Message, MsgBoxStyle.Critical, "Error! Making Sched")
                            Finally
                                DBconnection.Dispose()
                            End Try

                            If countFalseInsertToSched = arrSubjectID.Count Then
                                StatusLogForm.StatusLog("(" & countFalseInsertToSched & "/" & arrSubjectID.Count & ")")
                                timePickOffset += 1
                                StatusLogForm.StatusLog("timePickOffset increment")
                                StatusLogForm.StatusLog("timepickOffset: " & timePickOffset)
                            End If
                        End If
                        subjIndexSelection += 1
                    Loop Until subjIndexSelection = arrSubjectID.Count
                    For Each item In arrRemoveSubjID
                        arrSubjectID.Remove(item)
                    Next
                Loop Until arrSubjectID.Count = 0
            End If

            If examDay = 2 Then
                'Exit Do
            End If
            examDay += 1

            StatusLogForm.StatusLog("")
        Loop Until examDay = 5
    End Sub

    Private Sub ProctoringAssignment(ByRef deptID As Integer, ByRef ProctorTable As DataGridView, ByVal arrFacCheckedID As ArrayList, ByRef deptCount As Integer)
        Dim str As String
        Dim arrPref As New ArrayList
        Dim arrProctorID As New ArrayList
        Dim deptPref As String = Nothing

        'Get Proctor Selection Preference
        cmd = New MySqlCommand("SELECT dept_proctoringPref FROM department WHERE dept_id=" & deptID & ";", DBconnection)
        DBconnection.Open()
        reader = cmd.ExecuteReader
        reader.Read()
        deptPref = reader.GetString("dept_proctoringPref")
        DBconnection.Close()

        arrPref.AddRange(deptPref.ToCharArray)

        IbaPa.randomDept(arrPref, deptCount)

        For i As Integer = 0 To arrPref.Count - 1
            'cmd = New MySqlCommand("SELECT fac_id FROM faculty WHERE fac_type=0 AND dept_id=" & arrPref(i) & " AND fac_proctorOK is NULL ORDER BY RAND();", DBconnection)
            cmd = New MySqlCommand("SELECT fac_id FROM faculty WHERE dept_id=" & arrPref(i) & " AND fac_proctorOK is NULL ORDER BY fac_type DESC, RAND();", DBconnection)
            DBconnection.Open()
            reader = cmd.ExecuteReader
            While reader.Read
                If LoginForm.accType = "Default" Then
                    If arrFacCheckedID.Contains(reader.GetString("fac_id").ToString) Then
                        arrProctorID.Add(reader.GetString("fac_id").ToString)
                    End If
                Else
                    If i = 0 Then
                        If arrFacCheckedID.Contains(reader.GetString("fac_id").ToString) Then
                            arrProctorID.Add(reader.GetString("fac_id").ToString)
                        End If
                    ElseIf i > 0 Then
                        arrProctorID.Add(reader.GetString("fac_id").ToString)
                    End If
                End If
            End While
            DBconnection.Close()
        Next

        For type As Integer = 1 To 2
            Dim roomExist As Boolean = True
            cmd = New MySqlCommand("SELECT COUNT(*) AS RowCount FROM sched WHERE dept_id=" & deptID & " AND " & If(type = 1, "(sched_day=1 OR sched_day=3)", "(sched_day=2 OR sched_day=4)") & " ORDER BY rm_id;", DBconnection)
            DBconnection.Open()
            reader = cmd.ExecuteReader
            reader.Read()
            If reader.GetString("RowCount") = 0 Then
                roomExist = False
            End If
            DBconnection.Close()

            If roomExist Then
                'Get Room ID's
                Dim arrRoom As New ArrayList
                cmd = New MySqlCommand("SELECT DISTINCT(rm_id) AS rm_id FROM sched WHERE dept_id=" & deptID & " AND " & If(type = 1, "(sched_day=1 OR sched_day=3)", "(sched_day=2 OR sched_day=4)") & " ORDER BY rm_id;", DBconnection)
                DBconnection.Open()
                reader = cmd.ExecuteReader
                While reader.Read
                    arrRoom.Add(reader.GetString("rm_id"))
                End While
                DBconnection.Close()

                For Each roomID As String In arrRoom
                    Dim arrTempFacID As New ArrayList
                    cmd = New MySqlCommand("SELECT DISTINCT(fac_id) FROM sched WHERE rm_id=" & roomID & " AND " & If(type = 1, "(sched_day=1 OR sched_day=3)", "(sched_day=2 OR sched_day=4)") & ";", DBconnection)
                    DBconnection.Open()
                    reader = cmd.ExecuteReader
                    While reader.Read
                        arrTempFacID.Add(reader.GetString("fac_id").ToString)
                    End While
                    DBconnection.Close()

                    Dim removeProctorID As String = ""
                    For i As Integer = 0 To arrProctorID.Count - 1
                        Dim proctor As String = arrProctorID(i)
                        StatusLogForm.StatusLog("Proctor ID: " & proctor)
                        Dim proctorOK As Boolean = True
                        If arrTempFacID.Count > 0 Then
                            For j As Integer = 0 To arrTempFacID.Count - 1
                                Dim faculty As String = arrTempFacID(j)
                                StatusLogForm.StatusLog(proctor & "=" & faculty & vbTab & (proctor = faculty).ToString)
                                If proctor = faculty Then
                                    StatusLogForm.StatusLog("...next Proctor ID")
                                    proctorOK = False
                                    Exit For
                                End If
                            Next
                        End If
                        If proctorOK Then
                            StatusLogForm.StatusLog("Proctor ID: " & proctor)
                            StatusLogForm.StatusLog("...assigning Proctor ID_" & proctor & " to Room " & roomID)
                            cmd = New MySqlCommand("UPDATE sched SET proctor_id=" & proctor & " WHERE rm_id=" & roomID & " AND " & If(type = 1, "(sched_day=1 OR sched_day=3)", "(sched_day=2 OR sched_day=4)") & ";", DBconnection)
                            DBconnection.Open()
                            cmd.ExecuteReader()
                            DBconnection.Close()

                            cmd = New MySqlCommand("UPDATE faculty SET fac_proctorOK=" & deptID & ", fac_notifRead=1 WHERE fac_id=" & proctor & ";", DBconnection)
                            DBconnection.Open()
                            cmd.ExecuteReader()
                            DBconnection.Close()

                            removeProctorID = proctor
                            Exit For
                        End If
                    Next
                    If removeProctorID.Length > 0 Then
                        StatusLogForm.StatusLog("...removing " & removeProctorID & " from Faculty ID List")

                        For i As Integer = 0 To arrProctorID.Count - 1
                            If removeProctorID.ToString = arrProctorID(i).ToString Then
                                arrProctorID.RemoveAt(i)
                                Exit For
                            End If
                        Next

                        str = ""
                        For Each item As String In arrProctorID
                            str += item & " - "
                        Next
                        StatusLogForm.StatusLog(str)
                        StatusLogForm.StatusLog("Proctor Count: " & arrProctorID.Count)
                        StatusLogForm.StatusLog("")
                    End If
                Next
            End If
        Next
    End Sub

    Private Sub CountSubjectsInSched(ByRef deptID As Integer)
        Try
            cmd = New MySqlCommand("SELECT COUNT(*) FROM sched WHERE dept_id=" & deptID & ";", DBconnection)
            DBconnection.Open()
            reader = cmd.ExecuteReader

        Catch ex As Exception

        End Try
    End Sub
End Module