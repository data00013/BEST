﻿Imports System.Text.RegularExpressions
Imports MySql.Data.MySqlClient
Imports System.Reflection.MethodBase
Imports iTextSharp.text.pdf
Imports iTextSharp.text
Imports System.IO
Imports System.Drawing

Module IbaPa

    Dim reader As MySqlDataReader
    Dim DBconnection As New MySqlConnection(LoginForm.ConnectionString)
    Dim cmd As MySqlCommand

    Function MakeItSmall(img As Drawing.Bitmap) As Drawing.Bitmap

        Const maxWidth As Integer = 120
        Const maxHeight As Integer = 120
        Dim percentToShrink As Double = -1

        If img.Width >= img.Height Then
            ' Do we need to resize based on width?
            If img.Width > maxWidth Then
                percentToShrink = CDbl(maxWidth) / CDbl(img.Width)
            End If
        Else
            ' Do we need to resize based on width?
            If img.Height > maxHeight Then
                percentToShrink = CDbl(maxHeight) / CDbl(img.Height)
            End If
        End If

        Dim newWidth As Integer = img.Width
        Dim newHeight As Integer = img.Height

        ' So do we need to resize?
        If percentToShrink <> -1 Then
            newWidth = CInt(Math.Truncate(img.Width * percentToShrink))
            newHeight = CInt(Math.Truncate(img.Height * percentToShrink))
        End If

        ' convert the image to a png and get a byte[]
        Dim ms As New IO.MemoryStream()
        Dim bmp As New Bitmap(newWidth, newHeight)
        Using g As Graphics = Graphics.FromImage(bmp)
            g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic
            g.FillRectangle(System.Drawing.Brushes.White, 0, 0, newWidth, newHeight)
            g.DrawImage(img, 0, 0, newWidth, newHeight)
        End Using

        ms.Dispose()

        Return bmp
    End Function

    Function ConvDruationToString(ByVal duration As Integer) As String
        Dim newDuration As String = ""
        Dim H, m As Integer

        H = duration \ 60
        m = duration Mod 60

        If H > 0 Then
            newDuration = H & "hr" & If(H > 1, "s", "") & " and "
        End If
        newDuration += m & "min" & If(m > 1, "s", "")

        Return newDuration.ToString
    End Function

    Function CountRows(ByRef tbName As String, ByRef Optional condition As String = Nothing, ByRef Optional column As String = "*") As Integer
        Dim returnVal As Integer
        Try
            'MsgBox("SELECT COUNT(*) AS RowCount FROM " & tbName & " '" & If(IsNothing(condition), "", condition) & "';")
            cmd = New MySqlCommand("SELECT COUNT(" & column & ") AS RowCount FROM " & tbName & " " & If(IsNothing(condition), "", condition) & ";", DBconnection)
            DBconnection.Open()
            reader = cmd.ExecuteReader
            reader.Read()
            returnVal = reader.GetString("RowCount")
            DBconnection.Close()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod.Name)
        Finally
            DBconnection.Dispose()
        End Try
        Return returnVal
    End Function

    Sub RollbackID(tableName, tbColID)
        Try
            Dim arrID As New ArrayList
            Dim newID As Integer

            cmd = New MySqlCommand("SELECT " & tbColID & " FROM " & tableName & " ORDER BY " & tbColID & ";", DBconnection)
            DBconnection.Open()
            reader = cmd.ExecuteReader
            While reader.Read
                arrID.Add(reader.GetString(tbColID))
            End While
            DBconnection.Close()

            newID = 1
            For Each item In arrID
                cmd = New MySqlCommand("UPDATE " & tableName & " SET " & tbColID & "=" & newID & " WHERE " & tbColID & "=" & item & ";", DBconnection)
                DBconnection.Open()
                cmd.ExecuteReader()
                DBconnection.Close()
                newID += 1
            Next

            cmd = New MySqlCommand("ALTER TABLE " & tableName & " AUTO_INCREMENT=" & newID & ";", DBconnection)
            DBconnection.Open()
            cmd.ExecuteReader()
            DBconnection.Close()
        Catch ex As Exception
            MsgBox(ex.Message,, "Error Sub RollBack ID")
        Finally
            DBconnection.Dispose()
        End Try
    End Sub

    Function PromptErrorMsg(ByVal exception As Exception) As String

        Dim trace = New Diagnostics.StackTrace(exception, True)
        Dim line As String = Strings.Right(trace.ToString, 5)
        Dim str As String = ""
        Dim Xcont As Integer = 0

        For Each sf As StackFrame In trace.GetFrames
            Xcont = Xcont + 1
            str = str & Xcont & ". " & sf.GetMethod().ReflectedType.ToString & " " & sf.GetMethod().Name & vbCrLf
        Next

        Return "Error in Line number: " & line & exception.Message & vbCrLf & vbCrLf & "Methods : " & vbCrLf & str
    End Function

    Function getRidOfFckinWhiteSpaces(ByVal str As String) As String
        Return Regex.Replace(str, "\s+", " ").Trim
    End Function

    Sub DeleteRow(ByVal dgv As DataGridView, ByVal colID As Integer, ByVal colName As Integer, ByVal tbName As String, ByVal tbColID As String)
        Try
            Dim numberOfFckinRows As Integer = 0
            Dim iWantToDeleteThisFckinRows_arr As New ArrayList
            Dim nameOfFckinRows_arr As New ArrayList

            For i As Integer = 0 To dgv.RowCount() - 1
                If dgv.Rows(i).Selected Then
                    numberOfFckinRows += 1
                    iWantToDeleteThisFckinRows_arr.Add(dgv.Rows(i).Cells(colID).Value)
                    nameOfFckinRows_arr.Add(dgv.Rows(i).Cells(colName).Value)
                End If
            Next

            Dim str As String = ""
            For i As Integer = 0 To nameOfFckinRows_arr.Count - 1
                str += nameOfFckinRows_arr(i)
                If i < nameOfFckinRows_arr.Count - 2 Then
                    str += ", "
                End If
                If i = nameOfFckinRows_arr.Count - 2 Then
                    str += " and "
                End If
            Next

            If MsgBox("Are you sure you want to delete the ff: " & vbCrLf & str, MsgBoxStyle.YesNoCancel + MsgBoxStyle.Question, "Delete Confirmation") = DialogResult.Yes Then
                For Each item In iWantToDeleteThisFckinRows_arr
                    cmd = New MySqlCommand("DELETE FROM " & tbName & " WHERE " & tbColID & " = " & item & ";", DBconnection)

                    DBconnection.Open()
                    cmd.ExecuteReader()
                    DBconnection.Close()
                Next

                IbaPa.RollbackID(tbName, tbColID)
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod.Name)
        Finally
            DBconnection.Dispose()
        End Try
    End Sub

    Sub FullSchedJPG(ByRef day As Integer, ByVal start As Integer, ByVal limit As Integer)
        Dim folderName As String = "Schedule"
        Dim bmp As New Bitmap(My.Resources.SchedTemplateletterSize)
        Dim gfx As Graphics = Graphics.FromImage(bmp)

        Dim examDay As Integer

        'Title
        Using titleFont As New Drawing.Font("Microsoft Sans Serif", 60, FontStyle.Bold)
            Dim titleRectangle As New Drawing.Rectangle(154, 477, 2248, 120)
            Dim kulay As New SolidBrush(Color.FromArgb(100, 255, 45, 45))
            Dim titleStringFormat As New StringFormat
            titleStringFormat.Alignment = StringAlignment.Center
            titleStringFormat.LineAlignment = StringAlignment.Center
            'gfx.FillRectangle(kulay, titleRectangle)
            gfx.DrawString(If(LoginForm.accType = "Default", "University of Batangas", IbaPa.RetriveThis_AsString("department", "dept_name", "dept_id", LoginForm.dept_id)), titleFont, Brushes.Black, titleRectangle, titleStringFormat)
        End Using

        'Row Data
        Dim dataRowPositionY As Integer = 910
        Dim rectangleHeight As Integer = 70
        Dim alternateIndex As Integer = 0
        cmd = New MySqlCommand(
            "SELECT 
                sched.sched_day AS 'Day', 
                CONCAT(DATE_FORMAT(sched.sched_start, '%l:%i %p'),' - ',DATE_FORMAT(sched.sched_end, '%l:%i %p')) AS 'Time', 
                subject.subj_code AS 'Subject Code',
                Professor.facName AS 'Professor',
                Proctor.facName AS 'Proctor',
                section.sec_name AS 'Section',
                CONCAT(rm_bldg,'-',rm_number) AS 'Room'
            FROM sched
            JOIN subject ON sched.subj_id=subject.subj_id
            JOIN (SELECT faculty.fac_id, IFNULL(fac_altName, fac_fullName) AS facName FROM faculty) AS Professor ON sched.fac_id=Professor.fac_id
            LEFT JOIN (SELECT faculty.fac_id, IFNULL(fac_altName, fac_fullName) AS facName FROM faculty) AS Proctor ON sched.proctor_id=Proctor.fac_id
            JOIN room ON sched.rm_id=room.rm_id
            JOIN section ON sched.sec_id=section.sec_id
            WHERE sched_day=" & day & If(LoginForm.accType = "Default", "", " AND sched.dept_id=" & LoginForm.dept_id) & "
            ORDER BY subject.subj_code, Professor.facName
            LIMIT " & start & ", " & limit & ";", DBconnection)
        DBconnection.Open()
        reader = cmd.ExecuteReader
        While reader.Read
            Using dataDrawFont As New Drawing.Font("Microsoft Sans Serif", 28)
                'Dim colDay = New Drawing.Rectangle(154, dataRowPositionY, 143, rectangleHeight)
                Dim colTime = New Drawing.Rectangle(154, dataRowPositionY, 474, rectangleHeight)
                Dim colSubject = New Drawing.Rectangle(632, dataRowPositionY, 279, rectangleHeight)
                Dim colProfessor = New Drawing.Rectangle(914, dataRowPositionY, 491, rectangleHeight)
                Dim colProctor = New Drawing.Rectangle(1409, dataRowPositionY, 491, rectangleHeight)
                Dim colSection = New Drawing.Rectangle(1904, dataRowPositionY, 279, rectangleHeight)
                Dim colRoom = New Drawing.Rectangle(2187, dataRowPositionY, 204, rectangleHeight)

                Dim cellStringFormat = New StringFormat()

                cellStringFormat.Alignment = StringAlignment.Center
                cellStringFormat.LineAlignment = StringAlignment.Center

                Dim color_1 As New SolidBrush(Color.FromArgb(100, 255, 255, 255))
                Dim color_2 As New SolidBrush(Color.FromArgb(100, 220, 220, 220))

                If alternateIndex Mod 2 = 0 Then
                    'gfx.FillRectangle(color_1, colDay)
                    gfx.FillRectangle(color_1, colTime)
                    gfx.FillRectangle(color_1, colSubject)
                    gfx.FillRectangle(color_1, colProfessor)
                    gfx.FillRectangle(color_1, colProctor)
                    gfx.FillRectangle(color_1, colSection)
                    gfx.FillRectangle(color_1, colRoom)
                Else
                    'gfx.FillRectangle(color_2, colDay)
                    gfx.FillRectangle(color_2, colTime)
                    gfx.FillRectangle(color_2, colSubject)
                    gfx.FillRectangle(color_2, colProfessor)
                    gfx.FillRectangle(color_2, colProctor)
                    gfx.FillRectangle(color_2, colSection)
                    gfx.FillRectangle(color_2, colRoom)
                End If

                'gfx.DrawString(reader.GetString("Day"), dataDrawFont, Brushes.Black, colDay, cellStringFormat)
                gfx.DrawString(reader.GetString("Time"), dataDrawFont, Brushes.Black, colTime, cellStringFormat)
                gfx.DrawString(reader.GetString("Subject Code"), dataDrawFont, Brushes.Black, colSubject, cellStringFormat)
                gfx.DrawString(reader.GetString("Professor"), dataDrawFont, Brushes.Black, colProfessor, cellStringFormat)
                gfx.DrawString(If(reader.IsDBNull(reader.GetOrdinal("Proctor")), "", reader.GetString("Proctor")), dataDrawFont, Brushes.Black, colProctor, cellStringFormat)
                gfx.DrawString(reader.GetString("Section"), dataDrawFont, Brushes.Black, colSection, cellStringFormat)
                gfx.DrawString(reader.GetString("Room"), dataDrawFont, Brushes.Black, colRoom, cellStringFormat)

                'gfx.DrawString(i + 1, dataDrawFont, Brushes.Black, 200, dataRowPositionY, New StringFormat(StringAlignment.Center))
                alternateIndex += 1
            End Using
            dataRowPositionY += rectangleHeight
            examDay = reader.GetString("Day")
        End While
        'MsgBox(reader.GetString("Day"))
        Dim dayFont As New Drawing.Font("Microsoft Sans Serif", 40, FontStyle.Bold)
        gfx.DrawString("Day " & examDay, dayFont, Brushes.Black, 220, 700)
        DBconnection.Close()

        Try
            If (Not Directory.Exists(folderName)) Then
                Directory.CreateDirectory(folderName)
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, GetCurrentMethod.Name)
        End Try

        bmp.Save(Path.Combine(folderName, If(LoginForm.accType = "Default", "UB", LoginForm.dept_code) & " Major Exam Schedule " & DateTime.Now.ToString("yyyy") & ".jpg"))

        'IbaPa.ExportPDF(bmp)
        bmp.Dispose()
    End Sub

    Sub ExportPDF()
        Dim folderProjectBest As String = "Brahman Exam Schedulling Technology - BEST"
        Dim folderName = "Schedule"
        Dim fileName As String = If(LoginForm.accType = "Default", "UB", LoginForm.dept_code) & " Major Exam Schedule " & DateTime.Now.ToString("yyyy")
        Dim pdfDoc As Document
        Try
            If (Not Directory.Exists(folderName)) Then
                Directory.CreateDirectory(folderName)
            End If

            pdfDoc = New Document(PageSize.LETTER)
            Dim pdfWrite As PdfWriter = PdfWriter.GetInstance(pdfDoc, New FileStream(folderName & "\" & fileName & ".pdf", FileMode.Create))

            pdfDoc.Open()
            For examDay As Integer = 1 To 4
                Dim limit As Integer = 30
                Dim start As Integer = 0
                Dim rowCount As Integer = CountRows("sched", "WHERE sched_day=" & examDay & If(LoginForm.accType = "Default", "", " AND dept_id=" & LoginForm.dept_id))
                Do
                    'MsgBox("Day: " & examDay & vbCrLf & "Rows: " & rowCount & vbCrLf & "Start: " & start & vbCrLf & "Limit: " & limit)
                    FullSchedJPG(examDay, start, limit)
                    Dim pdfImage As iTextSharp.text.Image = iTextSharp.text.Image.GetInstance(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\\Brahman Exam Schedulling Technology - BEST\\" & If(LoginForm.accType = "Default", "Default", LoginForm.dept_code) & "\\" & folderName & "\\" & fileName & ".jpg")
                    pdfImage.SetAbsolutePosition(0, 0)
                    pdfImage.ScaleToFit(PageSize.LETTER.Width, PageSize.LETTER.Height)
                    pdfDoc.Add(pdfImage)
                    If start + limit <= rowCount Then
                        start += limit
                        pdfDoc.NewPage()
                    Else
                        Exit Do
                    End If
                Loop
                If examDay < 4 And rowCount > 0 Then
                    pdfDoc.NewPage()
                End If
            Next
            pdfDoc.Close()
            FileSystem.Kill(folderName & "\" & fileName & ".jpg")

            If MsgBox("Sched is sucessfully exported as PDF" & vbCrLf & "Do you want to open it?", MsgBoxStyle.YesNoCancel + MsgBoxStyle.Question) = DialogResult.Yes Then
                Process.Start(folderName & "\" & fileName & ".pdf")
            End If

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation)
        End Try
    End Sub

    Function getTheFckinID(ByRef tableName As String, ByRef colID As String, ByRef columnName As String, ByRef value As String) As Integer
        Dim returnVal As Integer = Nothing
        Try
            cmd = New MySqlCommand("SELECT " & colID & " FROM " & tableName & " WHERE " & columnName & "='" & value & "';", DBconnection)
            DBconnection.Open()
            reader = cmd.ExecuteReader
            reader.Read()
            returnVal = reader.GetString(colID)
            DBconnection.Close()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod.Name)
        Finally
            DBconnection.Dispose()
        End Try
        Return returnVal
    End Function

    Function RetriveThis_AsString(ByRef tableName As String, ByRef retriveColumn As String, ByRef whereColumn As String, ByRef value As String) As String
        Dim returnVal As String = Nothing
        Try
            cmd = New MySqlCommand("SELECT " & retriveColumn & " FROM " & tableName & " WHERE " & whereColumn & "='" & value & "';", DBconnection)
            DBconnection.Open()
            reader = cmd.ExecuteReader
            reader.Read()
            returnVal = reader.GetString(retriveColumn)
            DBconnection.Close()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod.Name)
        Finally
            DBconnection.Dispose()
        End Try
        Return returnVal
    End Function

    Sub LoadCbotData(ByVal cbo As ComboBox, ByVal table As String, ByVal column As String)
        Try
            cbo.Items.Clear()
            cmd = New MySqlCommand("SELECT " & column & " FROM " & table & ";", DBconnection)
            DBconnection.Open()
            reader = cmd.ExecuteReader
            While reader.Read
                cbo.Items.Add(reader.GetString(column))
            End While
            DBconnection.Close()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod.Name)
        Finally
            DBconnection.Dispose()
        End Try
    End Sub

    Function CountVisibleRow(ByVal dgv As DataGridView) As Integer
        Dim returnVal As Integer = 0
        For i As Integer = 0 To dgv.RowCount - 1
            If dgv.Rows(i).Visible = True Then
                returnVal += 1
            End If
        Next
        Return returnVal
    End Function

    Sub randomDept(ByVal arr As ArrayList, ByVal elem As Integer)
        Dim arrRandom As New ArrayList

        For i As Integer = 1 To elem
            arrRandom.Add(i.ToString)
        Next

        Dim temp As String
        Dim rnd As New Random
        For i As Integer = 0 To arrRandom.Count - 2
            Dim randomIndex As Integer = rnd.Next(i + 1, arrRandom.Count)
            temp = arrRandom(i)
            arrRandom(i) = arrRandom(randomIndex)
            arrRandom(randomIndex) = temp
        Next

        For i As Integer = 0 To arr.Count - 1
            arrRandom.Remove(arr(i).ToString)
        Next

        arr.AddRange(arrRandom)
    End Sub

    Sub randomizeOrder(ByVal arr As ArrayList)
        Dim rnd As New Random
        Dim temp As Integer
        For i As Integer = 0 To arr.Count - 2
            Dim randomIndex As Integer = rnd.Next(i + 1, arr.Count)
            temp = arr(i)
            arr(i) = arr(randomIndex)
            arr(randomIndex) = temp
        Next
    End Sub
End Module
