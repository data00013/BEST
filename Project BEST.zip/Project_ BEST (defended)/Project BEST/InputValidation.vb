﻿Imports System.Text.RegularExpressions

Module InputValidation
    Function isAllNumeric(inp As String) As Boolean
        Return Regex.IsMatch(inp, "\A-{0,1}[0-9.]*\Z")
        'Return Not Regex.IsMatch(inp, "[0-9]")
    End Function

    Function isAllAlpha(inp As String) As Boolean
        Return Regex.IsMatch(inp, "^[a-zA-Z ]*$")
    End Function

    Function isAlphaWithComma(inp As String) As Boolean
        Return Regex.IsMatch(inp, "^[a-zA-Z ,]{0,150}$")
    End Function

    Function ContainsNumber(inp As String) As Boolean
        Return Regex.IsMatch(inp, "[0-9]")
    End Function

    Function ContainsSpecialChars(inp As String) As Boolean
        Return Not (Regex.IsMatch(inp, "^[a-zA-Z0-9,. \r\n]{1,}$"))
    End Function
End Module
