﻿Imports System.IO
Imports MySql.Data.MySqlClient

Public Class LoginForm

    Public Shared ConnectionString As String = "Server=localhost;Database=codeblack;Uid=root;Pwd=CodeBlack000"
    Public Shared defaultPath As String = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\Brahman Exam Schedulling Technology - BEST"
    Public Shared dir As String

    Dim reader As MySqlDataReader
    Dim DBconnection As New MySqlConnection(LoginForm.ConnectionString)
    Dim cmd As MySqlCommand

    Public Shared acc_name As String
    Public Shared dept_id As String
    Public Shared dept_code As String
    Public Shared dept_name As String

    Public Shared accType As String

    Private Sub LoginForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        dir = defaultPath
        Try
            If (Not Directory.Exists(dir)) Then
                Directory.CreateDirectory(dir)
            End If
            Directory.SetCurrentDirectory(dir)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btnLogIn_Click(sender As Object, e As EventArgs) Handles btnLogIn.Click
        Dim username As String = Nothing
        Dim password As String = Nothing

        If txtUsername.TextLength > 0 And txtPassword.TextLength > 0 Then
            If Not txtUsername.Text.Contains(" ") Then
                Dim checkUser As Integer = 0
                Dim checkPass As Integer = 0

                Try
                    cmd = New MySqlCommand("SELECT COUNT(*) AS 'RowCount', acc_user FROM account WHERE acc_user = '" & txtUsername.Text & "';", DBconnection)
                    DBconnection.Open()
                    reader = cmd.ExecuteReader
                    reader.Read()
                    If Not reader.IsDBNull(reader.GetOrdinal("acc_user")) Then
                        username = reader.GetString("acc_user")
                        If username = txtUsername.Text Then
                            checkUser = reader.GetString("RowCount")
                        End If
                    End If
                    DBconnection.Close()


                    If checkUser > 0 Then
                        cmd = New MySqlCommand("SELECT COUNT(*) AS RowCount, acc_user, acc_pass FROM account WHERE acc_user = '" & txtUsername.Text & "' AND acc_pass = '" & txtPassword.Text & "';", DBconnection)
                        DBconnection.Open()
                        reader = cmd.ExecuteReader
                        reader.Read()
                        If Not (reader.IsDBNull(reader.GetOrdinal("acc_user")) And reader.IsDBNull(reader.GetOrdinal("acc_pass"))) Then
                            username = reader.GetString("acc_user")
                            password = reader.GetString("acc_pass")
                            If username = txtUsername.Text And password = txtPassword.Text Then
                                checkPass = reader.GetString("RowCount")
                            End If
                        End If
                        DBconnection.Close()
                    End If

                    If checkUser > 0 Then
                        If checkPass > 0 Then
                            cmd = New MySqlCommand(
                                "SELECT acc_name, acc_user, acc_pass, acc_type, department.dept_id, department.dept_code, department.dept_name 
                                FROM account 
                                LEFT JOIN department ON account.dept_id=department.dept_id 
                                WHERE acc_user='" & txtUsername.Text & "' AND acc_pass='" & txtPassword.Text & "';",
                            DBconnection)
                            DBconnection.Open()
                            reader = cmd.ExecuteReader
                            reader.Read()

                            accType = reader.GetString("acc_type")
                            acc_name = reader.GetString("acc_name")

                            If accType = "Default" Then
                                AdminControl.Show()
                                dir = Path.Combine(dir, accType)
                            Else
                                dept_id = reader.GetString("dept_id")
                                dept_code = reader.GetString("dept_code")
                                dept_name = reader.GetString("dept_name")
                                DeptWindow.Show()
                                dir = Path.Combine(dir, dept_code)
                            End If

                            DBconnection.Close()

                            Try
                                If (Not Directory.Exists(dir)) Then
                                    Directory.CreateDirectory(dir)
                                End If
                                Directory.SetCurrentDirectory(dir)
                            Catch ex As Exception
                                MsgBox(ex.Message)
                            End Try
                            Me.Close()
                        Else
                            MsgBox("Sorry! " & vbCrLf & " You entered the wrong password")

                            txtPassword.Clear()
                            txtPassword.Select()
                        End If
                    Else
                        MsgBox("Sorry! " & txtUsername.Text & " is not registered")

                        txtUsername.Clear()
                        txtPassword.Clear()
                        txtUsername.Select()
                    End If

                Catch ex As Exception
                    MsgBox(ex.Message)
                Finally
                    DBconnection.Dispose()
                End Try
            Else
                MsgBox("Invalid Input" & vbCrLf & "Please try again")
                txtUsername.Clear()
                txtPassword.Clear()
                txtUsername.Select()
            End If
        ElseIf txtUsername.TextLength > 0 And txtPassword.TextLength = 0 Then
            txtPassword.Select()
        ElseIf txtUsername.TextLength = 0 And txtPassword.TextLength > 0 Then
            txtUsername.Select()
        Else
            txtUsername.Select()
        End If
    End Sub

    Private Sub LoginForm_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        Me.Dispose()
    End Sub
End Class