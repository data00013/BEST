﻿Imports MySql.Data.MySqlClient
Imports System.Reflection.MethodBase

Public Class Proctoring

    Dim reader As MySqlDataReader
    Dim DBconnection As New MySqlConnection(LoginForm.ConnectionString)
    Dim cmd As MySqlCommand

    Private Sub Proctoring_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            cmd = New MySqlCommand("SELECT fac_fullName FROM faculty WHERE fac_id=" & DeptWindow.proctorID & ";", DBconnection)
            DBconnection.Open()
            reader = cmd.ExecuteReader
            reader.Read()
            lblName.Text = "Name: " & reader.GetString("fac_fullName")
            DBconnection.Close()

            Dim schedStart, schedEnd As DateTime
            dgvProctoring.Rows.Clear()
            cmd = New MySqlCommand(
                "SELECT sched_day, sched_start, sched_end, subj_code, sec_name , CONCAT(rm_bldg,'-',rm_number) AS Room
                FROM sched 
                JOIN subject ON sched.subj_id=subject.subj_id 
                JOIN section ON sched.sec_id=section.sec_id 
                JOIN room ON sched.rm_id=room.rm_id 
                WHERE proctor_id=" & DeptWindow.proctorID & ";", DBconnection)
            DBconnection.Open()
            reader = cmd.ExecuteReader
            While reader.Read
                schedStart = reader.GetString("sched_start")
                schedEnd = reader.GetString("sched_end")
                dgvProctoring.Rows.Add(
                    reader.GetString("sched_day"),
                    schedStart.ToString("h:mm tt") & " - " & schedEnd.ToString("h:mm tt"),
                    reader.GetString("subj_code"),
                    reader.GetString("sec_name")
                    )
                lblRoom.Text = "Room: " & reader.GetString("Room")
            End While
            DBconnection.Close()

            cmd = New MySqlCommand("UPDATE faculty SET fac_notifRead=0 WHERE fac_id=" & DeptWindow.proctorID & ";", DBconnection)
            DBconnection.Open()
            cmd.ExecuteReader()
            DBconnection.Close()

            DeptWindow.RefreshFacultyStatus()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod.Name)
        Finally
            DBconnection.Dispose()
        End Try
    End Sub

    Private Sub Proctoring_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        Me.Dispose()
    End Sub
End Class