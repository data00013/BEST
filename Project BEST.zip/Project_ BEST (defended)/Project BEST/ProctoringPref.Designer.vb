﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ProctoringPref
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lstDept = New System.Windows.Forms.ListBox()
        Me.lstProctoringOrder = New System.Windows.Forms.ListBox()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.btnRemove = New System.Windows.Forms.Button()
        Me.btnOrderUp = New System.Windows.Forms.Button()
        Me.btnOrderDown = New System.Windows.Forms.Button()
        Me.cboDept = New System.Windows.Forms.ComboBox()
        Me.lblDept = New System.Windows.Forms.Label()
        Me.btnSaveProctoringPref = New System.Windows.Forms.Button()
        Me.lblNote = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lstDept
        '
        Me.lstDept.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstDept.FormattingEnabled = True
        Me.lstDept.ItemHeight = 16
        Me.lstDept.Location = New System.Drawing.Point(27, 46)
        Me.lstDept.Name = "lstDept"
        Me.lstDept.Size = New System.Drawing.Size(90, 132)
        Me.lstDept.TabIndex = 0
        '
        'lstProctoringOrder
        '
        Me.lstProctoringOrder.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstProctoringOrder.FormattingEnabled = True
        Me.lstProctoringOrder.ItemHeight = 16
        Me.lstProctoringOrder.Location = New System.Drawing.Point(204, 46)
        Me.lstProctoringOrder.Name = "lstProctoringOrder"
        Me.lstProctoringOrder.Size = New System.Drawing.Size(90, 132)
        Me.lstProctoringOrder.TabIndex = 1
        '
        'btnAdd
        '
        Me.btnAdd.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAdd.Location = New System.Drawing.Point(123, 70)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(75, 40)
        Me.btnAdd.TabIndex = 2
        Me.btnAdd.Text = "Add"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'btnRemove
        '
        Me.btnRemove.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRemove.Location = New System.Drawing.Point(123, 116)
        Me.btnRemove.Name = "btnRemove"
        Me.btnRemove.Size = New System.Drawing.Size(75, 40)
        Me.btnRemove.TabIndex = 2
        Me.btnRemove.Text = "Remove"
        Me.btnRemove.UseVisualStyleBackColor = True
        '
        'btnOrderUp
        '
        Me.btnOrderUp.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOrderUp.Location = New System.Drawing.Point(300, 80)
        Me.btnOrderUp.Name = "btnOrderUp"
        Me.btnOrderUp.Size = New System.Drawing.Size(30, 30)
        Me.btnOrderUp.TabIndex = 3
        Me.btnOrderUp.Text = "▲"
        Me.btnOrderUp.UseVisualStyleBackColor = True
        '
        'btnOrderDown
        '
        Me.btnOrderDown.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOrderDown.Location = New System.Drawing.Point(300, 116)
        Me.btnOrderDown.Name = "btnOrderDown"
        Me.btnOrderDown.Size = New System.Drawing.Size(30, 30)
        Me.btnOrderDown.TabIndex = 4
        Me.btnOrderDown.Text = "▼"
        Me.btnOrderDown.UseVisualStyleBackColor = True
        '
        'cboDept
        '
        Me.cboDept.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboDept.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboDept.FormattingEnabled = True
        Me.cboDept.Location = New System.Drawing.Point(123, 12)
        Me.cboDept.Name = "cboDept"
        Me.cboDept.Size = New System.Drawing.Size(121, 24)
        Me.cboDept.TabIndex = 9
        '
        'lblDept
        '
        Me.lblDept.AutoSize = True
        Me.lblDept.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDept.Location = New System.Drawing.Point(33, 16)
        Me.lblDept.Name = "lblDept"
        Me.lblDept.Size = New System.Drawing.Size(84, 16)
        Me.lblDept.TabIndex = 8
        Me.lblDept.Text = "Department: "
        '
        'btnSaveProctoringPref
        '
        Me.btnSaveProctoringPref.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSaveProctoringPref.Location = New System.Drawing.Point(128, 184)
        Me.btnSaveProctoringPref.Name = "btnSaveProctoringPref"
        Me.btnSaveProctoringPref.Size = New System.Drawing.Size(100, 40)
        Me.btnSaveProctoringPref.TabIndex = 10
        Me.btnSaveProctoringPref.Text = "Save"
        Me.btnSaveProctoringPref.UseVisualStyleBackColor = True
        '
        'lblNote
        '
        Me.lblNote.AutoSize = True
        Me.lblNote.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.lblNote.Location = New System.Drawing.Point(9, 230)
        Me.lblNote.MaximumSize = New System.Drawing.Size(340, 0)
        Me.lblNote.MinimumSize = New System.Drawing.Size(315, 0)
        Me.lblNote.Name = "lblNote"
        Me.lblNote.Size = New System.Drawing.Size(339, 26)
        Me.lblNote.TabIndex = 11
        Me.lblNote.Text = "Note: The department proctoring priority depends on the arrangement. The remainin" &
    "g departments will be added randomly."
        '
        'ProctoringPref
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(356, 267)
        Me.Controls.Add(Me.lblNote)
        Me.Controls.Add(Me.btnSaveProctoringPref)
        Me.Controls.Add(Me.cboDept)
        Me.Controls.Add(Me.lblDept)
        Me.Controls.Add(Me.btnOrderDown)
        Me.Controls.Add(Me.btnOrderUp)
        Me.Controls.Add(Me.btnRemove)
        Me.Controls.Add(Me.btnAdd)
        Me.Controls.Add(Me.lstProctoringOrder)
        Me.Controls.Add(Me.lstDept)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "ProctoringPref"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Proctoring Preference"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lstDept As ListBox
    Friend WithEvents lstProctoringOrder As ListBox
    Friend WithEvents btnAdd As Button
    Friend WithEvents btnRemove As Button
    Friend WithEvents btnOrderUp As Button
    Friend WithEvents btnOrderDown As Button
    Friend WithEvents cboDept As ComboBox
    Friend WithEvents lblDept As Label
    Friend WithEvents btnSaveProctoringPref As Button
    Friend WithEvents lblNote As Label
End Class
