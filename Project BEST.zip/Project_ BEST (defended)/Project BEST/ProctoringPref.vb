﻿Imports MySql.Data.MySqlClient
Imports System.Reflection.MethodBase

Public Class ProctoringPref

    Dim reader As MySqlDataReader
    Dim DBconnection As New MySqlConnection(LoginForm.ConnectionString)
    Dim cmd As MySqlCommand

    Sub LoadLstDeptData()
        Try
            lstDept.Items.Clear()
            cmd = New MySqlCommand("SELECT dept_code FROM department;", DBconnection)
            DBconnection.Open()
            reader = cmd.ExecuteReader
            While reader.Read
                lstDept.Items.Add(reader.GetString("dept_code"))
            End While
            DBconnection.Close()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod.Name)
        Finally
            DBconnection.Dispose()
        End Try
    End Sub

    Sub LoadLstProctorPref(ByVal code As String)
        Try
            lstProctoringOrder.Items.Clear()
            Dim proctoringPref As String = ""
            Dim arrProctoringPref As New ArrayList
            cmd = New MySqlCommand("SELECT dept_proctoringPref FROM department WHERE dept_code='" & code & "';", DBconnection)
            DBconnection.Open()
            reader = cmd.ExecuteReader
            reader.Read()
            arrProctoringPref.AddRange(reader.GetString("dept_proctoringPref").ToCharArray)
            DBconnection.Close()

            If arrProctoringPref.Count > 0 Then
                For Each deptID In arrProctoringPref
                    cmd = New MySqlCommand("SELECT dept_code FROM department WHERE dept_id=" & deptID & ";", DBconnection)
                    DBconnection.Open()
                    reader = cmd.ExecuteReader
                    reader.Read()
                    lstProctoringOrder.Items.Add(reader.GetString("dept_code"))
                    lstDept.Items.Remove(reader.GetString("dept_code"))
                    DBconnection.Close()
                Next
            End If

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod.Name)
        Finally
            DBconnection.Dispose
        End Try
    End Sub

    Private Sub ProctoringPref_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        IbaPa.LoadCbotData(cboDept, "department", "dept_code")
        LoadLstDeptData()
        If LoginForm.accType = "Default" Then
            cboDept.Enabled = True
            cboDept.SelectedIndex = 0
        Else
            cboDept.Enabled = False
            cboDept.SelectedItem = LoginForm.dept_code
            LoadLstProctorPref(If(LoginForm.accType = "Default", cboDept.SelectedItem, LoginForm.dept_code))
        End If
    End Sub

    Private Sub cboDept_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboDept.SelectedIndexChanged
        If cboDept.SelectedIndex > -1 Then
            LoadLstDeptData()
            LoadLstProctorPref(If(LoginForm.accType = "Default", cboDept.SelectedItem, LoginForm.dept_code))
        End If
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        If lstDept.SelectedIndex > -1 Then
            lstProctoringOrder.Items.Add(lstDept.SelectedItem)
            lstDept.Items.Remove(lstDept.SelectedItem)
        End If
    End Sub

    Private Sub btnRemove_Click(sender As Object, e As EventArgs) Handles btnRemove.Click
        If lstProctoringOrder.SelectedIndex > -1 Then
            If (cboDept.Visible = True And Not cboDept.SelectedItem = lstProctoringOrder.SelectedItem) Or
                (cboDept.Visible = False And Not LoginForm.dept_code = lstProctoringOrder.SelectedItem) Then
                lstDept.Items.Add(lstProctoringOrder.SelectedItem)
                lstProctoringOrder.Items.Remove(lstProctoringOrder.SelectedItem)
            End If
        End If
    End Sub

    Private Sub btnOrderUp_Click(sender As Object, e As EventArgs) Handles btnOrderUp.Click
        If lstProctoringOrder.SelectedIndex > -1 And lstProctoringOrder.SelectedIndex > 0 Then
            If lstProctoringOrder.Items(lstProctoringOrder.SelectedIndex - 1) <> If(LoginForm.accType = "Default", cboDept.SelectedItem, LoginForm.dept_code) Then
                Dim index = lstProctoringOrder.SelectedIndex - 1
                lstProctoringOrder.Items.Insert(index, lstProctoringOrder.SelectedItem)
                lstProctoringOrder.Items.RemoveAt(lstProctoringOrder.SelectedIndex)
                lstProctoringOrder.SelectedIndex = index
            End If
        End If
    End Sub

    Private Sub btnOrderDown_Click(sender As Object, e As EventArgs) Handles btnOrderDown.Click
        If lstProctoringOrder.SelectedIndex > -1 And lstProctoringOrder.SelectedIndex < lstProctoringOrder.Items.Count - 1 Then
            If lstProctoringOrder.SelectedItem <> If(LoginForm.accType = "Default", cboDept.SelectedItem, LoginForm.dept_code) Then
                Dim index = lstProctoringOrder.SelectedIndex + 2
                lstProctoringOrder.Items.Insert(index, lstProctoringOrder.SelectedItem)
                lstProctoringOrder.Items.RemoveAt(lstProctoringOrder.SelectedIndex)
                lstProctoringOrder.SelectedIndex = index - 1
            End If
        End If
    End Sub

    Private Sub btnSaveProctoringPref_Click(sender As Object, e As EventArgs) Handles btnSaveProctoringPref.Click
        Dim proctoringPref As String = ""
        Try
            For i As Integer = 0 To lstProctoringOrder.Items.Count - 1
                proctoringPref += IbaPa.getTheFckinID("department", "dept_id", "dept_code", lstProctoringOrder.Items(i)).ToString
            Next

            If proctoringPref.Length > 0 Then
                cmd = New MySqlCommand("UPDATE department SET dept_proctoringPref='" & proctoringPref & "' WHERE dept_code='" & If(LoginForm.accType = "Default", cboDept.SelectedItem, LoginForm.dept_code) & "';", DBconnection)
                DBconnection.Open()
                cmd.ExecuteReader()
                DBconnection.Close()
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod.Name)
        Finally
            DBconnection.Dispose()
        End Try
    End Sub

    Private Sub ProctoringPref_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        Me.Dispose()
    End Sub
End Class