﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Room
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle16 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle17 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle18 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.dgvRoom = New System.Windows.Forms.DataGridView()
        Me.ID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.grpRoomInputs = New System.Windows.Forms.GroupBox()
        Me.cboBuilding = New System.Windows.Forms.ComboBox()
        Me.txtRoomNumber = New System.Windows.Forms.MaskedTextBox()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.btnAddEdit = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        CType(Me.dgvRoom, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpRoomInputs.SuspendLayout()
        Me.SuspendLayout()
        '
        'dgvRoom
        '
        Me.dgvRoom.AllowUserToAddRows = False
        Me.dgvRoom.AllowUserToDeleteRows = False
        Me.dgvRoom.AllowUserToResizeColumns = False
        Me.dgvRoom.AllowUserToResizeRows = False
        Me.dgvRoom.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgvRoom.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvRoom.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgvRoom.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        DataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle16.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle16.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle16.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle16.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvRoom.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle16
        Me.dgvRoom.ColumnHeadersHeight = 40
        Me.dgvRoom.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.dgvRoom.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.ID, Me.Column2, Me.Column3, Me.Column4})
        DataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle17.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle17.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle17.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvRoom.DefaultCellStyle = DataGridViewCellStyle17
        Me.dgvRoom.Location = New System.Drawing.Point(47, 169)
        Me.dgvRoom.Name = "dgvRoom"
        DataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle18.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle18.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle18.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvRoom.RowHeadersDefaultCellStyle = DataGridViewCellStyle18
        Me.dgvRoom.RowHeadersVisible = False
        Me.dgvRoom.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvRoom.Size = New System.Drawing.Size(344, 262)
        Me.dgvRoom.StandardTab = True
        Me.dgvRoom.TabIndex = 1
        Me.dgvRoom.TabStop = False
        '
        'ID
        '
        Me.ID.HeaderText = "Column1"
        Me.ID.Name = "ID"
        Me.ID.Visible = False
        '
        'Column2
        '
        Me.Column2.FillWeight = 85.0!
        Me.Column2.HeaderText = "ROOM"
        Me.Column2.Name = "Column2"
        Me.Column2.ReadOnly = True
        '
        'Column3
        '
        Me.Column3.FillWeight = 85.0!
        Me.Column3.HeaderText = "BUILDING"
        Me.Column3.Name = "Column3"
        Me.Column3.ReadOnly = True
        '
        'Column4
        '
        Me.Column4.FillWeight = 70.0!
        Me.Column4.HeaderText = "FLOOR LEVEL"
        Me.Column4.Name = "Column4"
        Me.Column4.ReadOnly = True
        '
        'grpRoomInputs
        '
        Me.grpRoomInputs.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.grpRoomInputs.Controls.Add(Me.cboBuilding)
        Me.grpRoomInputs.Controls.Add(Me.txtRoomNumber)
        Me.grpRoomInputs.Controls.Add(Me.btnDelete)
        Me.grpRoomInputs.Controls.Add(Me.btnAddEdit)
        Me.grpRoomInputs.Controls.Add(Me.Label2)
        Me.grpRoomInputs.Controls.Add(Me.Label1)
        Me.grpRoomInputs.Location = New System.Drawing.Point(47, 19)
        Me.grpRoomInputs.Name = "grpRoomInputs"
        Me.grpRoomInputs.Size = New System.Drawing.Size(356, 127)
        Me.grpRoomInputs.TabIndex = 0
        Me.grpRoomInputs.TabStop = False
        Me.grpRoomInputs.Text = "Manage Rooms"
        '
        'cboBuilding
        '
        Me.cboBuilding.BackColor = System.Drawing.SystemColors.Window
        Me.cboBuilding.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboBuilding.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboBuilding.FormattingEnabled = True
        Me.cboBuilding.Items.AddRange(New Object() {"A", "B"})
        Me.cboBuilding.Location = New System.Drawing.Point(80, 66)
        Me.cboBuilding.Name = "cboBuilding"
        Me.cboBuilding.Size = New System.Drawing.Size(52, 24)
        Me.cboBuilding.TabIndex = 2
        '
        'txtRoomNumber
        '
        Me.txtRoomNumber.CutCopyMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals
        Me.txtRoomNumber.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRoomNumber.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite
        Me.txtRoomNumber.Location = New System.Drawing.Point(80, 36)
        Me.txtRoomNumber.Mask = "000"
        Me.txtRoomNumber.Name = "txtRoomNumber"
        Me.txtRoomNumber.PromptChar = Global.Microsoft.VisualBasic.ChrW(32)
        Me.txtRoomNumber.ResetOnSpace = False
        Me.txtRoomNumber.Size = New System.Drawing.Size(52, 22)
        Me.txtRoomNumber.TabIndex = 1
        Me.txtRoomNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.txtRoomNumber.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals
        '
        'btnDelete
        '
        Me.btnDelete.BackColor = System.Drawing.Color.LightGray
        Me.btnDelete.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDelete.Location = New System.Drawing.Point(253, 43)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(86, 40)
        Me.btnDelete.TabIndex = 4
        Me.btnDelete.TabStop = False
        Me.btnDelete.Text = "Delete"
        Me.btnDelete.UseVisualStyleBackColor = False
        '
        'btnAddEdit
        '
        Me.btnAddEdit.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.btnAddEdit.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAddEdit.Location = New System.Drawing.Point(138, 43)
        Me.btnAddEdit.Name = "btnAddEdit"
        Me.btnAddEdit.Size = New System.Drawing.Size(100, 40)
        Me.btnAddEdit.TabIndex = 3
        Me.btnAddEdit.Text = "Add"
        Me.btnAddEdit.UseVisualStyleBackColor = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(18, 69)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(56, 16)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Building"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(18, 39)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(56, 16)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Number"
        '
        'Room
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(439, 443)
        Me.Controls.Add(Me.grpRoomInputs)
        Me.Controls.Add(Me.dgvRoom)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "Room"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Room"
        CType(Me.dgvRoom, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpRoomInputs.ResumeLayout(False)
        Me.grpRoomInputs.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents dgvRoom As DataGridView
    Friend WithEvents grpRoomInputs As GroupBox
    Friend WithEvents cboBuilding As ComboBox
    Friend WithEvents txtRoomNumber As MaskedTextBox
    Friend WithEvents btnAddEdit As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents btnDelete As Button
    Friend WithEvents ID As DataGridViewTextBoxColumn
    Friend WithEvents Column2 As DataGridViewTextBoxColumn
    Friend WithEvents Column3 As DataGridViewTextBoxColumn
    Friend WithEvents Column4 As DataGridViewTextBoxColumn
End Class
