﻿Imports MySql.Data.MySqlClient
Imports System.Reflection.MethodBase

Public Class Room

    Dim reader As MySqlDataReader
    Dim DBconnection As New MySqlConnection(LoginForm.ConnectionString)
    Dim cmd As MySqlCommand

    Dim roomID As Integer

    Public Sub ResetManageRoomForm()
        txtRoomNumber.Clear()
        cboBuilding.SelectedIndex = -1
    End Sub

    Private Sub Room_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadRooms()
        dgvRoom.ClearSelection()
    End Sub

    Public Sub LoadRooms()
        dgvRoom.Rows.Clear()

        Dim floorLevel As String = Nothing
        Try
            cmd = New MySqlCommand("SELECT rm_id, CONCAT(rm_bldg, '-', rm_number) AS RoomName, rm_bldg FROM room ORDER BY rm_bldg, rm_number;", DBconnection)
            DBconnection.Open()
            reader = cmd.ExecuteReader
            While reader.Read
                If reader.GetString("RoomName").Substring(2, 1) = "1" Then
                    floorLevel = "1st Floor"
                ElseIf reader.GetString("RoomName").Substring(2, 1) = "2" Then
                    floorLevel = "2nd Floor"
                ElseIf reader.GetString("RoomName").Substring(2, 1) = "3" Then
                    floorLevel = "3rd Floor"
                Else
                    floorLevel = "---"
                End If

                dgvRoom.Rows.Add(
                    reader.GetString("rm_id"),
                    reader.GetString("RoomName"),
                    reader.GetString("rm_bldg"),
                    floorLevel)
            End While
            DBconnection.Close()

            dgvRoom.ClearSelection()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod.Name)
        Finally
            DBconnection.Dispose()
        End Try
    End Sub

    Private Sub btnAddEdit_Click(sender As Object, e As EventArgs) Handles btnAddEdit.Click
        If btnAddEdit.Text = "Add" Then
            If txtRoomNumber.TextLength = 3 And cboBuilding.SelectedIndex <> -1 Then
                Try
                    Dim roomNotExist As Boolean = True
                    cmd = New MySqlCommand("SELECT COUNT(*) AS RowCount FROM room WHERE rm_number=" & txtRoomNumber.Text & " AND rm_bldg='" & cboBuilding.SelectedItem & "';", DBconnection)
                    DBconnection.Open()
                    reader = cmd.ExecuteReader
                    reader.Read()

                    If reader.GetString("RowCount") > 0 Then
                        roomNotExist = False
                    End If
                    DBconnection.Close()

                    If roomNotExist Then
                        cmd = New MySqlCommand("INSERT INTO room (rm_number, rm_bldg) VALUES (" & txtRoomNumber.Text & ", '" & cboBuilding.SelectedItem & "');", DBconnection)
                        DBconnection.Open()
                        cmd.ExecuteReader()
                        DBconnection.Close()

                        LoadRooms()

                        For i As Integer = 0 To dgvRoom.RowCount - 1
                            If dgvRoom.Rows(i).Cells(1).Value = cboBuilding.SelectedItem & "-" & txtRoomNumber.Text Then
                                dgvRoom.Rows(i).Selected = True
                                dgvRoom.FirstDisplayedScrollingRowIndex = i
                            End If
                        Next
                    Else
                        MsgBox("Sorry! " & cboBuilding.SelectedItem & "-" & txtRoomNumber.Text & " is already in the database", MsgBoxStyle.Exclamation)

                        txtRoomNumber.Select()
                        txtRoomNumber.SelectionStart = 0
                        txtRoomNumber.SelectionLength = txtRoomNumber.TextLength
                    End If

                    ResetManageRoomForm()
                Catch ex As Exception
                    MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod.Name)
                Finally
                    DBconnection.Dispose()
                End Try
            Else
                MsgBox("Invalid Input", MsgBoxStyle.Exclamation)
            End If
        ElseIf btnAddEdit.Text = "Edit" Then
            If txtRoomNumber.TextLength = 3 And cboBuilding.SelectedIndex <> -1 Then
                Try
                    Dim roomNotExist As Boolean = True
                    cmd = New MySqlCommand("SELECT COUNT(*) AS RowCount FROM room WHERE rm_number=" & txtRoomNumber.Text & " AND rm_bldg='" & cboBuilding.SelectedItem & "' AND rm_id!=" & roomID & ";", DBconnection)
                    DBconnection.Open()
                    reader = cmd.ExecuteReader
                    reader.Read()

                    If reader.GetString("RowCount") > 0 Then
                        roomNotExist = False
                    End If
                    DBconnection.Close()

                    If roomNotExist Then
                        cmd = New MySqlCommand("UPDATE room SET rm_number=" & txtRoomNumber.Text & ", rm_bldg='" & cboBuilding.SelectedItem & "' WHERE rm_id=" & roomID & ";", DBconnection)
                        DBconnection.Open()
                        cmd.ExecuteReader()
                        DBconnection.Close()

                        LoadRooms()

                        For i As Integer = 0 To dgvRoom.RowCount - 1
                            If dgvRoom.Rows(i).Cells(0).Value = roomID Then
                                dgvRoom.Rows(i).Selected = True
                                dgvRoom.FirstDisplayedScrollingRowIndex = i
                            End If
                        Next

                        btnAddEdit.Text = "Add"
                    Else
                        MsgBox("Sorry! " & cboBuilding.SelectedItem & "-" & txtRoomNumber.Text & " is already in the database", MsgBoxStyle.Exclamation)

                        txtRoomNumber.Select()
                        txtRoomNumber.SelectionStart = 0
                        txtRoomNumber.SelectionLength = txtRoomNumber.TextLength
                    End If

                    ResetManageRoomForm()
                Catch ex As Exception
                    MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod.Name)
                Finally
                    DBconnection.Dispose()
                End Try
            Else
                MsgBox("Invalid Input", MsgBoxStyle.Exclamation)
            End If
        End If
    End Sub

    Private Sub Room_Click(sender As Object, e As EventArgs) Handles MyBase.Click, grpRoomInputs.Click
        dgvRoom.ClearSelection()
        btnAddEdit.Text = "Add"
        ResetManageRoomForm()
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Try
            If dgvRoom.SelectedRows.Count > 0 Then
                If dgvRoom.CurrentRow.Cells(0).Value <> "--No Data--" Then
                    IbaPa.DeleteRow(dgvRoom, 0, 1, "room", "rm_id")
                    LoadRooms()
                    ResetManageRoomForm()
                    btnAddEdit.Text = "Add"
                End If
            Else
                    MsgBox("Please select a row")
            End If
            grpRoomInputs.Focus()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, GetCurrentMethod().Name)
        End Try
    End Sub

    Private Sub dgvRoom_RowStateChanged(sender As Object, e As DataGridViewRowStateChangedEventArgs) ' Handles dgvRoom.RowStateChanged
        If dgvRoom.SelectedRows.Count <> 1 Then
            btnAddEdit.Text = "Add"
        End If
    End Sub

    Private Sub txtRoomNumber_GotFocus(sender As Object, e As EventArgs) Handles txtRoomNumber.GotFocus
        txtRoomNumber.SelectionStart = 0
    End Sub

    Private Sub dgvRoom_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvRoom.CellDoubleClick
        RoomID = dgvRoom.Rows(e.RowIndex).Cells(0).Value

        btnAddEdit.Text = "Edit"
        txtRoomNumber.Text = dgvRoom.Rows(e.RowIndex).Cells(1).Value.ToString.Substring(2)
        cboBuilding.SelectedItem = dgvRoom.Rows(e.RowIndex).Cells(2).Value.ToString
    End Sub

    Private Sub Room_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        Me.Dispose()
    End Sub
End Class