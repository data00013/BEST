﻿Imports MySql.Data.MySqlClient
Imports System.Reflection.MethodBase

Public Class RoomSelect

    Dim reader As MySqlDataReader
    Dim DBconnection As New MySqlConnection(LoginForm.ConnectionString)
    Dim cmd As MySqlCommand

    Private Sub RefreshRoomTable()
        Dim DBconn_refreshRoomDeptCode As New MySqlConnection(LoginForm.ConnectionString)
        For i As Integer = 0 To dgvRoom.Rows.Count() - 1
            Try
                Dim cmd_refreshRoomDeptCode As New MySqlCommand("SELECT dept_code FROM room LEFT JOIN department ON room.dept_id=department.dept_id WHERE rm_id=" & dgvRoom.Rows(i).Cells(0).Value.ToString & ";", DBconn_refreshRoomDeptCode)
                DBconn_refreshRoomDeptCode.Open()
                Dim reader_deptCodeRefresh As MySqlDataReader = cmd_refreshRoomDeptCode.ExecuteReader
                reader_deptCodeRefresh.Read()
                dgvRoom.Rows(i).Cells(5).Value = If(reader_deptCodeRefresh.IsDBNull(reader_deptCodeRefresh.GetOrdinal("dept_code")), "--Unassigned--", reader_deptCodeRefresh.GetString("dept_code"))
                DBconn_refreshRoomDeptCode.Close()
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod.Name)
            Finally
                DBconn_refreshRoomDeptCode.Dispose()
            End Try
        Next
    End Sub

    Private Sub tmRefresher_Tick(sender As Object, e As EventArgs) Handles tmRefresher.Tick
        RefreshRoomTable()
    End Sub

    Private Sub LoadRoomTable(ByVal ID As Integer)
        dgvRoom.Rows.Clear()

        Dim floorLevel As String = Nothing
        Dim roomAssignmentCheck As Boolean
        Try
            cmd = New MySqlCommand(
                "SELECT 
                    rm_id, 
                    CONCAT(rm_bldg, '-', rm_number) AS RoomName, 
                    rm_bldg, 
                    dept_id 
                FROM room 
                ORDER BY 
	                CASE 
                        WHEN dept_id = " & ID & " THEN 1
                        WHEN dept_id is NULL THEN 2
                        ELSE 3
                    END;", DBconnection)
            DBconnection.Open()
            reader = cmd.ExecuteReader
            While reader.Read
                If reader.GetString("RoomName").Substring(2, 1) = "1" Then
                    floorLevel = "1st Floor"
                ElseIf reader.GetString("RoomName").Substring(2, 1) = "2" Then
                    floorLevel = "2nd Floor"
                ElseIf reader.GetString("RoomName").Substring(2, 1) = "3" Then
                    floorLevel = "3rd Floor"
                Else
                    floorLevel = "---"
                End If
                If reader.IsDBNull(reader.GetOrdinal("dept_id")) Then
                    roomAssignmentCheck = False
                Else
                    If reader.GetString("dept_id") = ID Then
                        roomAssignmentCheck = True
                    Else
                        roomAssignmentCheck = False
                    End If
                End If
                dgvRoom.Rows.Add(
                    reader.GetString("rm_id"),
                    roomAssignmentCheck,
                    reader.GetString("RoomName"),
                    reader.GetString("rm_bldg"),
                    floorLevel,
                    "Please wait...")
            End While
            DBconnection.Close()

            dgvRoom.ClearSelection()
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            DBconnection.Dispose()
        End Try
    End Sub

    Private Sub RoomSelect_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Try
            cboDept.Items.Clear()
            cmd = New MySqlCommand("SELECT dept_code FROM department;", DBconnection)
            DBconnection.Open()
            reader = cmd.ExecuteReader
            While reader.Read
                cboDept.Items.Add(reader.GetString("dept_code"))
            End While
            DBconnection.Close()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod.Name)
        Finally
            DBconnection.Dispose()
        End Try

        IbaPa.LoadCbotData(cboDept, "department", "dept_code")

        If LoginForm.accType = "Default" Then
            cboDept.Enabled = True
            cboDept.SelectedIndex = 0
        Else
            cboDept.Enabled = False
            cboDept.SelectedItem = LoginForm.dept_code
        End If
    End Sub

    Private Sub btnAssignRoom_Click(sender As Object, e As EventArgs) Handles btnAssignRoom.Click
        Dim roomIsAvailable As Boolean = True
        Dim deptID As Integer = If(LoginForm.accType = "Default", IbaPa.getTheFckinID("department", "dept_id", "dept_code", cboDept.SelectedItem), LoginForm.dept_id)

        'this checks if all checked rooms are available
        For i As Integer = 0 To dgvRoom.Rows.Count() - 1
            Try
                If dgvRoom.Rows(i).Cells(1).Value Then
                    cmd = New MySqlCommand("SELECT dept_id FROM room WHERE rm_id=" & dgvRoom.Rows(i).Cells(0).Value & ";", DBconnection)
                    DBconnection.Open()
                    reader = cmd.ExecuteReader
                    reader.Read()
                    If Not (reader.IsDBNull(reader.GetOrdinal("dept_id"))) Then
                        If reader.GetString("dept_id") <> deptID Then
                            roomIsAvailable = False
                            Exit For
                        End If
                    End If
                    DBconnection.Close()
                End If
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                DBconnection.Dispose()
            End Try
        Next
        DBconnection.Dispose()

        If roomIsAvailable Then
            For i As Integer = 0 To dgvRoom.Rows.Count() - 1
                Try
                    'cmd = New MySqlCommand("SELECT dept_code FROM room LEFT JOIN department ON room.dept_id=department.dept_id WHERE rm_id=" & dgvRoom.Rows(i).Cells(0).Value.ToString & ";", DBconnection)
                    If dgvRoom.Rows(i).Cells(1).Value Then
                        cmd = New MySqlCommand("UPDATE room SET dept_id=" & deptID & " WHERE (rm_id=" & dgvRoom.Rows(i).Cells(0).Value & ");", DBconnection)
                    Else
                        cmd = New MySqlCommand("UPDATE room SET dept_id=NULL WHERE (rm_id=" & dgvRoom.Rows(i).Cells(0).Value & " AND dept_id = " & deptID & ");", DBconnection)
                    End If
                    DBconnection.Open()
                    cmd.ExecuteReader()
                    DBconnection.Close()
                    RefreshRoomTable()
                Catch ex As Exception
                    MsgBox(ex.Message, MsgBoxStyle.Critical, GetCurrentMethod.Name)
                Finally
                    DBconnection.Dispose()
                End Try
            Next
        Else
            MsgBox("You selected room that already taken")
        End If

        LoadRoomTable(deptID)
    End Sub

    Private Sub RoomSelect_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        tmRefresher.Stop()
        Me.Dispose()
    End Sub

    Private Sub cboDept_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboDept.SelectedIndexChanged
        If cboDept.SelectedIndex > -1 Then
            LoadRoomTable(If(LoginForm.accType = "Default", IbaPa.getTheFckinID("department", "dept_id", "dept_code", cboDept.SelectedItem), LoginForm.dept_id))
            tmRefresher.Start()
        End If
    End Sub

    Private Sub dgvRoom_CurrentCellDirtyStateChanged(sender As Object, e As EventArgs) Handles dgvRoom.CurrentCellDirtyStateChanged
        If dgvRoom.IsCurrentCellDirty Then
            dgvRoom.CommitEdit(DataGridViewDataErrorContexts.Commit)
        End If
    End Sub

    Private Sub dgvRoom_CellValueChanged(sender As Object, e As DataGridViewCellEventArgs) Handles dgvRoom.CellValueChanged
        Dim count As Integer = 0
        For i As Integer = 0 To dgvRoom.RowCount - 1
            If dgvRoom.Rows(i).Cells(1).Value = True Then
                count += 1
            End If
        Next

        lblRoomCount.Text = "Room Count: " & count
    End Sub
End Class