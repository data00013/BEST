﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class StatusLogForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.btnSaveTexts = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.lstStatusLog = New System.Windows.Forms.ListBox()
        Me.SuspendLayout()
        '
        'btnSaveTexts
        '
        Me.btnSaveTexts.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.btnSaveTexts.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSaveTexts.Location = New System.Drawing.Point(161, 305)
        Me.btnSaveTexts.Name = "btnSaveTexts"
        Me.btnSaveTexts.Size = New System.Drawing.Size(100, 40)
        Me.btnSaveTexts.TabIndex = 6
        Me.btnSaveTexts.Text = "Save"
        Me.btnSaveTexts.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClose.Location = New System.Drawing.Point(267, 305)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(100, 40)
        Me.btnClose.TabIndex = 7
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'lstStatusLog
        '
        Me.lstStatusLog.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lstStatusLog.BackColor = System.Drawing.Color.FromArgb(CType(CType(12, Byte), Integer), CType(CType(12, Byte), Integer), CType(CType(12, Byte), Integer))
        Me.lstStatusLog.Font = New System.Drawing.Font("Consolas", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstStatusLog.ForeColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lstStatusLog.FormattingEnabled = True
        Me.lstStatusLog.Items.AddRange(New Object() {"Welcome to Brahman Exam Schedulling Technology (BEST)", "This is Status Log", "", "-------------------------------------------------------------------"})
        Me.lstStatusLog.Location = New System.Drawing.Point(10, 9)
        Me.lstStatusLog.Name = "lstStatusLog"
        Me.lstStatusLog.SelectionMode = System.Windows.Forms.SelectionMode.None
        Me.lstStatusLog.Size = New System.Drawing.Size(510, 290)
        Me.lstStatusLog.TabIndex = 8
        Me.lstStatusLog.TabStop = False
        '
        'StatusLogForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(529, 352)
        Me.Controls.Add(Me.lstStatusLog)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnSaveTexts)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.MaximizeBox = False
        Me.Name = "StatusLogForm"
        Me.Text = "StatusLogForm"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnSaveTexts As Button
    Friend WithEvents btnClose As Button
    Friend WithEvents lstStatusLog As ListBox
End Class
