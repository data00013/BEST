﻿Imports System.IO
Imports System.Threading

Public Class StatusLogForm

    Public Sub StatusLog(ByVal status As String)
        If status.Length > 0 Then
            lstStatusLog.Items.Add(log(status))
        Else
            lstStatusLog.Items.Add("")
        End If
    End Sub

    Private Function log(ByVal str As String) As String
        Return "[" & DateTime.Now.ToString("hh:mm:ss") & "]" & vbTab & str
    End Function

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub btnSaveTexts_Click(sender As Object, e As EventArgs) Handles btnSaveTexts.Click
        SaveLogInTxtFormat()
    End Sub

    Public Sub SaveLogInTxtFormat()
        Dim fileName As String = Nothing
        Dim folderName = "Logs"
        Try
            If (Not Directory.Exists(folderName)) Then
                Directory.CreateDirectory(folderName)
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

        fileName = LoginForm.dept_code & " Log " & DateTime.Now.ToString("yyyymmdd_hhmmss") & ".txt"

        Try
            Dim SW As StreamWriter = File.CreateText(Path.Combine(folderName, fileName))
            For Each item As String In lstStatusLog.Items
                SW.WriteLine(item)
            Next
            SW.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        Me.Close()
    End Sub

    Private Sub StatusLogForm_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        Me.Dispose()
    End Sub
End Class