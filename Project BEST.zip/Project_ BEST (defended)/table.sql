DROP SCHEMA IF EXISTS `codeblack`;

CREATE SCHEMA `codeblack`;
USE `codeblack`;

CREATE TABLE `department` (
  `dept_id` int(2) NOT NULL AUTO_INCREMENT,
  `dept_code` varchar(10) DEFAULT NULL,
  `dept_name` varchar(120) DEFAULT NULL,
  `dept_proctoringPref` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`dept_id`),
  UNIQUE KEY `dept_code_UNIQUE` (`dept_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `account` (
  `acc_id` int(2) NOT NULL AUTO_INCREMENT,
  `acc_name` varchar(15) DEFAULT NULL,
  `acc_user` varchar(15) DEFAULT NULL,
  `acc_pass` varchar(32) DEFAULT NULL,
  `acc_type` varchar(15) DEFAULT NULL,
  `dept_id` int(2) DEFAULT NULL,
  PRIMARY KEY (`acc_id`),
  KEY `accDept_id_idx` (`dept_id`),
  CONSTRAINT `accDept_id` FOREIGN KEY (`dept_id`) REFERENCES `department` (`dept_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `room` (
  `rm_id` int(2) NOT NULL AUTO_INCREMENT,
  `rm_number` int(3) DEFAULT NULL,
  `rm_bldg` char(1) DEFAULT NULL,
  `dept_id` int(2) DEFAULT NULL,
  PRIMARY KEY (`rm_id`),
  KEY `roomDept_id_idx` (`dept_id`),
  CONSTRAINT `roomDept_id` FOREIGN KEY (`dept_id`) REFERENCES `department` (`dept_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `course` (
  `crs_id` int(2) NOT NULL AUTO_INCREMENT,
  `crs_code` varchar(15) DEFAULT NULL,
  `crs_initial` varchar(10) DEFAULT NULL,
  `crs_name` varchar(120) DEFAULT NULL,
  `dept_id` int(2) DEFAULT NULL,
  PRIMARY KEY (`crs_id`),
  KEY `dept_id_idx` (`dept_id`),
  CONSTRAINT `crsDept_id` FOREIGN KEY (`dept_id`) REFERENCES `department` (`dept_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `faculty` (
  `fac_id` int(3) NOT NULL AUTO_INCREMENT,
  `fac_pic` blob,
  `fac_fullName` varchar(45) DEFAULT NULL,
  `fac_altName` varchar(30) DEFAULT NULL,
  `fac_lname` varchar(30) DEFAULT NULL,
  `fac_fname` varchar(30) DEFAULT NULL,
  `fac_mname` varchar(30) DEFAULT NULL,
  `fac_type` int(1) DEFAULT NULL,
  `fac_contact` varchar(20) DEFAULT NULL,
  `fac_email` varchar(50) DEFAULT NULL,
  `fac_proctorOK` int(1) DEFAULT NULL,
  `fac_notifRead` int(1) DEFAULT NULL,
  `dept_id` int(2) DEFAULT NULL,
  PRIMARY KEY (`fac_id`),
  KEY `facDept_id_idx` (`dept_id`),
  CONSTRAINT `facDept_id` FOREIGN KEY (`dept_id`) REFERENCES `department` (`dept_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `subject` (
  `subj_id` int(5) NOT NULL AUTO_INCREMENT,
  `subj_code` varchar(15) DEFAULT NULL,
  `subj_desc` varchar(250) DEFAULT NULL,
  `subj_year` int(1) DEFAULT NULL,
  `subj_sem` int(1) DEFAULT NULL,
  `subj_type` int(1) DEFAULT NULL,
  `subj_duration` int(3) DEFAULT NULL,
  `subj_day` int(1) DEFAULT NULL,
  `dept_id` int(2) DEFAULT NULL,
  PRIMARY KEY (`subj_id`),
  KEY `subjDept_id_idx` (`dept_id`),
  CONSTRAINT `subjDept_id` FOREIGN KEY (`dept_id`) REFERENCES `department` (`dept_id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `section` (
  `sec_id` int(3) NOT NULL AUTO_INCREMENT,
  `sec_name` varchar(10) DEFAULT NULL,
  `crs_id` int(3) DEFAULT NULL,
  PRIMARY KEY (`sec_id`),
  KEY `crs_id_idx` (`crs_id`),
  CONSTRAINT `secCrs_id` FOREIGN KEY (`crs_id`) REFERENCES `course` (`crs_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `class` (
  `class_id` int(3) NOT NULL AUTO_INCREMENT,
  `crs_id` int(2) DEFAULT NULL,
  `subj_id` int(3) DEFAULT NULL,
  `sec_id` int(3) DEFAULT NULL,
  `fac_id` int(3) DEFAULT NULL,
  PRIMARY KEY (`class_id`),
  KEY `crs_id_idx` (`crs_id`),
  KEY `subj_id_idx` (`subj_id`),
  KEY `sec_id_idx` (`sec_id`),
  KEY `classFac_id_idx` (`fac_id`),
  CONSTRAINT `classCrs_id` FOREIGN KEY (`crs_id`) REFERENCES `course` (`crs_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `classFac_id` FOREIGN KEY (`fac_id`) REFERENCES `faculty` (`fac_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `classSec_id` FOREIGN KEY (`sec_id`) REFERENCES `section` (`sec_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `classSubj_id` FOREIGN KEY (`subj_id`) REFERENCES `subject` (`subj_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `sched` (
  `sched_id` int(3) NOT NULL AUTO_INCREMENT,
  `sched_day` varchar(1) DEFAULT NULL,
  `sched_start` time DEFAULT NULL,
  `sched_end` time DEFAULT NULL,
  `proctor_id` int(3) DEFAULT NULL,
  `fac_id` int(3) DEFAULT NULL,
  `rm_id` int(2) DEFAULT NULL,
  `subj_id` int(5) DEFAULT NULL,
  `sec_id` int(3) DEFAULT NULL,
  `dept_id` int(2) DEFAULT NULL,
  PRIMARY KEY (`sched_id`),
  KEY `rm_id_idx` (`rm_id`),
  KEY `subj_id_idx` (`subj_id`),
  KEY `schedProctor_id_idx` (`proctor_id`),
  KEY `schedFac_id_idx` (`fac_id`),
  KEY `schedSec_id_idx` (`sec_id`),
  KEY `schedDept_id_idx` (`dept_id`),
  CONSTRAINT `schedDept_id` FOREIGN KEY (`dept_id`) REFERENCES `department` (`dept_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `schedFac_id` FOREIGN KEY (`fac_id`) REFERENCES `faculty` (`fac_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `schedProctor_id` FOREIGN KEY (`proctor_id`) REFERENCES `faculty` (`fac_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `schedRm_id` FOREIGN KEY (`rm_id`) REFERENCES `room` (`rm_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `schedSec_id` FOREIGN KEY (`sec_id`) REFERENCES `section` (`sec_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `schedSubj_id` FOREIGN KEY (`subj_id`) REFERENCES `subject` (`subj_id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;